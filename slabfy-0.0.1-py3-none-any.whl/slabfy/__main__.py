"""Module entrypoint for `python -m slabfy`.

Delegates to the package `main()` entry so the CLI works with `-m slabfy`.
"""
from . import main


if __name__ == "__main__":
    raise SystemExit(main())
