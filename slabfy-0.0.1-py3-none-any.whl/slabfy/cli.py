"""Command-line interface for slabfy.

Parametric CLI via ``python-fire``.  Class methods are auto-wrapped
by :func:`_cli_wrap` — e.g. adding a public method to ``Sculptor``
automatically exposes it as a CLI command with no additional code.  
Reusable argument parsers handle type coercion for non-trivial CLI 
inputs (miller tuples, filter specs, site coordinates, etc.).

``Sculptor`` commands are exposed in a **flat namespace**, while
other classes are exposed in a hierarchical namespace, so::

    slabfy join GaP.vasp Zn3P2.vasp '(1,1,0)' '(1,0,1)' --mode epitaxial
    slabfy cleave GaP.vasp '(1,1,0)' --thickness 10
    slabfy vasp relax POSCAR ./output write
    slabfy utils unique_miller GaP.vasp --max_order 3
"""

from __future__ import annotations

import inspect
import sys
from ast import literal_eval
from typing import Any

try:
    import fire  # type: ignore
except Exception:  # pragma: no cover - optional dependency
    fire = None

from .core import Sculptor
from .internals._core import _normalize_miller
from . import utils as slabfy_utils


# ── §1  Argument Parsers ─────────────────────────────────────────────
#
# Reusable, independently testable type-coercion functions.
# Each is keyed by *parameter name* in _CLI_PARSERS so the generic
# wrapper factory can apply them automatically.


def _parse_miller(value) -> tuple | int:
    """Convert CLI string ``'(1,1,0)'``, ``'110'``, or int to
    miller tuple or max-order int."""
    if isinstance(value, int):
        return value
    if isinstance(value, tuple):
        return _normalize_miller(value)
    if isinstance(value, str):
        text = value.strip()
        try:
            parsed = literal_eval(text)
        except Exception:
            try:
                return int(text)
            except Exception:
                raise ValueError(
                    f'miller must be a tuple string like "(1,1,0)" or an '
                    f"integer max order, got {value!r}"
                )
        if isinstance(parsed, int):
            return parsed
        if isinstance(parsed, tuple):
            return _normalize_miller(parsed)
    raise ValueError(f"invalid miller value: {value!r}")


def _parse_filter(value) -> tuple[str, int]:
    """Convert CLI filter string ``'spec'`` or ``'spec,5'`` to
    ``(spec, cap)`` tuple."""
    if isinstance(value, (tuple, list)) and len(value) == 2:
        return (str(value[0]), int(value[1]))
    if isinstance(value, str):
        if "," in value:
            parts = value.rsplit(",", 1)
            try:
                return (parts[0].strip(), int(parts[1].strip()))
            except ValueError:
                return (value.strip(), 0)
        return (value.strip(), 0)
    return (str(value), 0)


def _parse_literal(value) -> object:
    """Coerce string representation of bool, None, tuple, or dict
    to Python object.  Non-string values pass through unchanged."""
    if not isinstance(value, str):
        return value
    text = value.strip()
    lower = text.lower()
    if lower == "true":
        return True
    if lower == "false":
        return False
    if lower == "none":
        return None
    try:
        return literal_eval(text)
    except Exception:
        return value


def _parse_site(value) -> tuple | str:
    """Convert ``'(0.1,0.2,0.3)'`` to tuple or return site label string."""
    if isinstance(value, (tuple, list)):
        return tuple(float(v) for v in value)
    if isinstance(value, str):
        text = value.strip()
        if text.startswith("(") and text.endswith(")"):
            try:
                parsed = literal_eval(text)
                if isinstance(parsed, tuple):
                    return parsed
            except Exception:
                raise ValueError(f"invalid site coords: {value!r}")
        return text  # site label like 'o1', 'b2', 'h3'
    raise ValueError(f"invalid surface_sites value: {value!r}")


# Name → parser registry.
# When the wrapper is generated, any positional or keyword argument
# whose name appears here is passed through the corresponding parser
# instead of the generic _parse_literal fallback.
_CLI_PARSERS: dict[str, Any] = {
    "miller": _parse_miller,
    "miller1": _parse_miller,
    "miller2": _parse_miller,
    "filter": _parse_filter,
    "surface_sites": _parse_site,
}


# ── §2  Generic CLI Command Factory ─────────────────────────────────


def _make_command(
    target_cls: type,
    method_name: str,
    *,
    ctor_defaults: dict[str, Any],
    parsers: dict[str, Any],
) -> callable:
    """Build a standalone Fire-compatible callable for *one* method.

    The returned function:

    1. Extracts constructor settings from kwargs, instantiates
       *target_cls* with them.
    2. Binds positional args to named parameters (avoiding positional
       forwarding fragility).
    3. Applies registered parsers by parameter name;
       falls back to ``_parse_literal`` for unrecognised string kwargs.
    4. Calls ``instance.method_name(**bound)`` — all kwargs, no ``*args``.
    """
    method = getattr(target_cls, method_name)
    sig = inspect.signature(method)
    param_infos = [p for p in sig.parameters.values() if p.name != "self"]
    settings_keys = {
        k.replace("-", "_") for k in ctor_defaults
    }

    def command(*args, **kwargs):
        # ── 0. Normalize aliases ──────────────────────────────
        #    Handle common one-letter or shorthand flags.
        if "m" in kwargs:
            kwargs.setdefault("mode", kwargs.pop("m"))
        if "output" in kwargs:
            kwargs.setdefault("output_mode", kwargs.pop("output"))

        # ── 1. Split constructor settings from method kwargs ──
        ctor_kwargs: dict[str, Any] = {}
        for key, default in ctor_defaults.items():
            fire_key = key.replace("-", "_")
            raw = kwargs.pop(fire_key, default)
            ctor_kwargs[key] = (
                _parse_literal(raw) if isinstance(raw, str) else raw
            )
        instance = target_cls(**ctor_kwargs)

        # ── 2. Bind positional args to named params ───────────
        #    This avoids positional-order ambiguity entirely:
        #    Python handles binding via the real method signature.
        bound: dict[str, Any] = {}
        for i, arg in enumerate(args):
            if i < len(param_infos):
                name = param_infos[i].name
                if name in parsers:
                    bound[name] = parsers[name](arg)
                else:
                    bound[name] = arg
            # extra positional args are silently ignored —
            # they should not occur under normal CLI usage.

        # ── 3. Merge keyword args with parser application ─────
        for k, v in kwargs.items():
            # skip any lingering settings keys
            if k in settings_keys:
                continue
            if k in parsers:
                bound[k] = parsers[k](v)
            elif isinstance(v, str):
                bound[k] = _parse_literal(v)
            else:
                bound[k] = v

        # ── 4. Call the real method — all kwargs, no *args ────
        return getattr(instance, method_name)(**bound)

    # ── expose signature for Fire help ────────────────────────
    #    method params + constructor settings as keyword-only flags.
    #    Settings params must appear before any VAR_KEYWORD (**kwargs).
    regular = [
        p for p in param_infos
        if p.kind != inspect.Parameter.VAR_KEYWORD
    ]
    var_kw = [
        p for p in param_infos
        if p.kind == inspect.Parameter.VAR_KEYWORD
    ]
    if not var_kw:
        var_kw = [
            inspect.Parameter(
                "kwargs",
                inspect.Parameter.VAR_KEYWORD,
            )
        ]
    settings_params = []
    for key, default in ctor_defaults.items():
        fire_key = key.replace("-", "_")
        settings_params.append(
            inspect.Parameter(
                fire_key,
                inspect.Parameter.KEYWORD_ONLY,
                default=default,
            ),
        )
    help_params = regular + settings_params + var_kw
    command.__name__ = method_name
    command.__qualname__ = f"{target_cls.__name__}.{method_name}"
    command.__doc__ = method.__doc__
    command.__signature__ = inspect.Signature(help_params)
    return command


def _discover_methods(cls: type) -> list[str]:
    """Return sorted public method names on *cls*."""
    names = []
    for name in sorted(dir(cls)):
        if name.startswith("_"):
            continue
        attr = getattr(cls, name, None)
        if attr is not None and callable(attr) and not isinstance(attr, type):
            names.append(name)
    return names


# ── §3  Utils Auto-Exposure ──────────────────────────────────────────


def _build_utils_commands() -> dict[str, Any]:
    """Return callable utilities exported in ``slabfy.utils.__all__``."""
    commands: dict[str, Any] = {}
    exported = getattr(slabfy_utils, "__all__", [])
    for name in exported:
        if name.startswith("_"):
            continue
        value = getattr(slabfy_utils, name, None)
        if callable(value):
            commands[name] = value
    return commands


# ── §4  Entry Point ──────────────────────────────────────────────────


def main(argv: list[str] | None = None) -> Any:
    """CLI entrypoint.  If ``argv`` is provided it replaces
    ``sys.argv`` for tests."""
    if fire is None:
        raise ImportError(
            "python-fire is required for the CLI. "
            "Install with `pip install fire`"
        )

    if argv is not None:
        sys.argv = [sys.argv[0]] + list(argv)

    # Lazy imports so the CLI doesn't break if optional
    # dependencies for vasp/ase are absent.
    try:
        from .ase import ASETools
    except Exception:
        ASETools = None

    try:
        from .vasp import VaspTools
    except Exception:
        VaspTools = None

    try:
        from .analysis import AnalysisTree
    except Exception:
        AnalysisTree = None

    merged_parsers = dict(_CLI_PARSERS)

    # ── Build command map ─────────────────────────────────────────────────
    #    Sculptor methods → top-level commands.
    #    VaspTools / ASETools / utils → nested groups.

    command_map: dict[str, Any] = {}

    # Sculptor methods — constructor accepts settings flags.
    sculptor_settings = {
        "format": "vasp",
        "freeze": 0,
        "verbose": 1,
        "output-mode": 1,
        "output": 1,
        "m": "epitaxial",
    }
    for name in _discover_methods(Sculptor):
        command_map[name] = _make_command(
            Sculptor,
            name,
            ctor_defaults=sculptor_settings,
            parsers=merged_parsers,
        )

    # ASETools methods — nested group.
    if ASETools is not None:
        command_map["ase"] = {}
        for name in _discover_methods(ASETools):
            command_map["ase"][name] = _make_command(
                ASETools,
                name,
                ctor_defaults={},
                parsers=merged_parsers,
            )

    # VaspTools methods — nested group.
    if VaspTools is not None:
        command_map["vasp"] = {}
        for name in _discover_methods(VaspTools):
            command_map["vasp"][name] = _make_command(
                VaspTools,
                name,
                ctor_defaults={},
                parsers=merged_parsers,
            )

    # AnalysisTree methods — nested group.
    if AnalysisTree is not None:
        command_map["analysis"] = {}
        for name in _discover_methods(AnalysisTree):
            command_map["analysis"][name] = _make_command(
                AnalysisTree,
                name,
                ctor_defaults={},
                parsers=merged_parsers,
            )

    # Top-level utility group (unchanged).
    command_map["utils"] = _build_utils_commands()

    # Disable Fire's default pager view
    fire.core.Display = lambda lines, out: print(*lines, file=out, end="")
    # Disable Fire's default result printing
    fire.core._PrintResult = lambda component_trace, verbose, serialize: None
    fire.Fire(command_map)


if __name__ == "__main__":
    main()
