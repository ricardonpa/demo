"""
Utility functions for slabfy package.

This module contains helper functions and variables for the slabfy package.
"""

__all__ = [
    "SFY_SETTINGS",
    "HEADER",
    "PHYS_CONSTANTS",
    "convert_structure",
    "sort_species",
    "strain_lattice",
    "convert_coords",
    "supercell_lattice",
    "get_symmetry_structure",
    "rebase_lattice",
    "reduce_lattice",
    "freeze_coords",
    "unique_miller",
]

from slabfy.internals import _utils as internals

from pymatgen.core.structure import Structure
from pymatgen.core.surface import get_symmetrically_distinct_miller_indices
from pymatgen.io.vasp.inputs import Poscar

from typing import Literal, Any, TYPE_CHECKING

if TYPE_CHECKING:
    from slabfy.core import Surface, Interface

import importlib.resources
import tomli
import json

"""
╦  ╦┌─┐┬─┐┬┌─┐┌┐ ┬  ┌─┐┌─┐
╚╗╔╝├─┤├┬┘│├─┤├┴┐│  ├┤ └─┐
 ╚╝ ┴ ┴┴└─┴┴ ┴└─┘┴─┘└─┘└─┘
"""

try:
    with importlib.resources.files("slabfy").joinpath("pyproject.toml").open("rb") as f:
        _toml = tomli.load(f)
    _project = _toml.get("project", {})
    _urls = _project.get("urls", {})
    __version__ = _project.get("version")
    __release__ = _project.get("release")
    __authors__ = ", ".join([a.get("name", "") for a in _project.get("authors", [])])
    __doc__ = _urls.get("Documentation")
    __rep__ = _urls.get("Repository")
    __doi__ = _urls.get("DOI")

except (FileNotFoundError, ModuleNotFoundError):
    __version__ = "X.X.X"
    __release__ = "YYYY-MM"
    __authors__ = "Amaral, R. <rna5137@psu.edu>"
    __doc__ = "slabfy.readthedocs.io"
    __rep__ = "github.com/mmtgroup/slabfy"
    __doi__ = "00.00000/XXXXX.0000.00000"

try:
    # ── 1. Load slabfy.json ─────────────────────────────
    with (
        importlib.resources.files("slabfy")
        .joinpath("settings/slabfy.json")
        .open("r") as f
    ):
        _slabfy_cfg = json.load(f)

    _static = _slabfy_cfg.get("STATIC", {})
    _custom = _slabfy_cfg.get("CUSTOM", {})
    _user_dir = internals._resolve_user_dir(_custom)

    # ── 2. Load the three settings files ────────────────
    _vasp_file = _static.get("DEFAULT_VASP", "vasp6.json")
    _ase_file = _static.get("DEFAULT_ASE", "ase3.json")
    _sbatch_file = _static.get("DEFAULT_SBATCH", "sbatch.json")

    _vasp_data = internals._load_settings_json(_vasp_file, _user_dir)
    _ase_data = internals._load_settings_json(_ase_file, _user_dir)
    _sbatch_data = internals._load_settings_json(_sbatch_file, _user_dir)

    # ── 3. Assemble SFY_SETTINGS ────────────────────────
    SFY_SETTINGS: dict = {
        "STATIC": _static,
        "CUSTOM": _custom,
        "VASP": _vasp_data,
        "ASE": _ase_data,
        "SBATCH": _sbatch_data,
    }

except Exception:
    SFY_SETTINGS = {}

HEADER = f"""
   The Pennsylvania State University

          ╔╦╗┌─┐┌─┐┌┬┐┌─┐|┌─┐⠀⠀⠀
           ║║┌─┘├─┤ ││├┤  └─┐
          ═╩╝└─┘┴ ┴─┴┘└─┘ └─┘
       ╔╦╗╔╦╗╔╦╗  ╔═╗┬─┐┌─┐┬ ┬┌─┐
       ║║║║║║ ║   ║ ╦├┬┘│ ││ │├─┘
       ╩ ╩╩ ╩ ╩   ╚═╝┴└─└─┘└─┘┴

   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   | | | | |  s l a b f y  | | | | |
   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

           v{__version__} ({__release__}) 
     {__authors__} 

    DOC: {__doc__}
    REP: {__rep__}
    DOI: {__doi__}
                                 
########################################
"""

SURFACE_B64_PREFIX = "slabfy-surface-b64:"
INTERFACE_B64_PREFIX = "slabfy-interface-b64:"
BULK_B64_PREFIX = "slabfy-bulk-b64:"
ADPARTICLE_B64_PREFIX = "slabfy-adparticle-b64:"

PHYS_CONSTANTS = {
    "e_C": 1.6e-19,  # Electron charge [C]
    "A_m": 1e-10,  # Angstrom to meters [m]
    "MIN_VACUUM_SIZE": 10.0,  # Minimum vacuum for dipole corrections [Angstrom]
}

"""
╔═╗┬ ┬┌┐ ┬  ┬┌─┐  ┬ ┬┌┬┐┬┬  ┬┌┬┐┬┌─┐┌─┐
╠═╝│ │├┴┐│  ││    │ │ │ ││  │ │ │├┤ └─┐
╩  └─┘└─┘┴─┘┴└─┘  └─┘ ┴ ┴┴─┘┴ ┴ ┴└─┘└─┘
"""


def convert_structure(filename: str):
    """Convert a file (e.g. SDF) to a POSCAR Structure."""
    # TODO: implement
    pass


def sort_species(structure: Structure) -> Structure:
    """Sort species in a Structure by electronegativity."""
    # TODO: implement
    pass


def strain_lattice(
    structure: Structure,
    strain_matrix: list,
) -> Structure:
    """Apply a strain matrix to a Structure lattice."""
    # TODO: implement
    pass


def convert_coords(filename: str) -> Structure:
    """Convert coordinates between direct and Cartesian."""
    # TODO: implement
    pass


def supercell_lattice(
    structure: Structure,
    scaling_matrix: list,
) -> Structure:
    """Return a supercell-expanded copy of ``structure``.

    If ``scaling_matrix`` is equivalent to ``(1, 1, 1)``, the input structure
    is copied and returned unchanged.
    """
    expanded = structure.copy()
    if not scaling_matrix:
        return expanded

    scaling_tuple = tuple(scaling_matrix)
    if scaling_tuple == (1, 1, 1):
        return expanded

    expanded.make_supercell(scaling_tuple)
    return expanded


def get_symmetry_structure(structure: Structure) -> Poscar:
    """Return symmetry-classified version of a Structure."""
    # TODO: implement
    pass


def rebase_lattice() -> Structure:
    """Rebase the lattice of a Structure onto a new basis."""
    # TODO: implement
    print("Hello!")


def reduce_lattice(
    structure: Structure,
    type: Literal["primitive", "conventional"],
) -> Structure:
    """Reduce a Structure to primitive or conventional cell."""
    # TODO: implement
    pass


def freeze_coords(
    structure: "Structure | Surface | Interface | str",
    coord1: float,
    coord2: float = 0.0,
    axis: Literal["a", "b", "c"] = "c",
    reset: bool = True,
    mode: Literal["direct", "cartesian", "layers"] = "direct",
    output: str | None = None,
) -> "Surface | Interface | Structure":
    """Apply selective dynamics flags and return a modified structure copy.

    The ``mode`` parameter controls how ``coord1`` and ``coord2`` are interpreted:

    - **direct** (default): Fractional coordinates along ``axis``. Sites with
      fractional coords in ``[coord1, coord2]`` are frozen.

    - **cartesian**: Cartesian coordinates (Angstrom) along ``axis``. Sites with
      Cartesian coords in ``[coord1, coord2]`` are frozen.

    - **layers**: Layer-based freeze. Requires ``structure`` to be a ``Surface``
      or ``Interface`` object with layer information populated.

      - For **Surface**: ``coord1`` is the number of layers from the top to leave
        **free** (unfrozen). ``coord2`` is ignored.

      - For **Interface**: ``coord1`` is the number of layers to the **left** of
        the interface position to leave free, and ``coord2`` is the number of
        layers to the **right**.

    Parameters
    ----------
    structure : Structure | Surface | Interface | str
        Input structure, Surface, Interface object, or path to a structure file
        (POSCAR, CIF, etc.). When a file path is provided, the structure is
        loaded automatically.
    coord1 : float
        Start of coordinate range (inclusive) to freeze, or number of free
        layers (when ``mode="layers"``).
    coord2 : float, default 0.0
        End of coordinate range (inclusive) to freeze, or number of free
        layers to the right of interface (when ``mode="layers"`` with Interface).
    axis : {"a", "b", "c"}, default "c"
        Lattice axis along which to apply the freeze range.
        Ignored when ``mode="layers"``.
    reset : bool, default True
        If ``True``, set all sites outside the range to unfrozen
        (selective_dynamics = True). If ``False``, preserve existing
        selective dynamics flags for sites outside the range.
        Ignored when ``mode="layers"``.
    mode : {"direct", "cartesian", "layers"}, default "direct"
        Coordinate interpretation mode.
    output : str, optional
        If provided, write the resulting structure to this file path (POSCAR format).
        Useful for CLI usage.

    Returns
    -------
    Structure
        A copy of the input structure with selective dynamics applied.

    Raises
    ------
    TypeError
        If ``mode="layers"`` but structure is not a Surface or Interface.
    ValueError
        If layer information is not available on the Surface/Interface.
    FileNotFoundError
        If ``structure`` is a file path that does not exist.

    Examples
    --------
    Freeze bottom half (direct/fractional mode)::

        frozen = freeze_coords(structure, 0.0, 0.5)

    Freeze sites below 5 Angstrom (cartesian mode)::

        frozen = freeze_coords(structure, 0.0, 5.0, mode="cartesian")

    Freeze all but top 2 layers of a Surface::

        frozen = freeze_coords(surface, 2, mode="layers")

    Freeze interface leaving 2 layers free on each side::

        frozen = freeze_coords(interface, 2, 2, mode="layers")
    """
    from pymatgen.core.structure import Structure as PmgStructure
    from pymatgen.io.vasp import Poscar

    # Import here to avoid circular imports at module load time
    from slabfy.core import Surface, Interface
    from slabfy.internals._utils import (
        _freeze_surface_layers,
        _freeze_interface_layers,
    )

    # Handle file path input
    if isinstance(structure, str):
        import os

        if not os.path.isfile(structure):
            raise FileNotFoundError(f"Structure file not found: {structure}")
        structure = Poscar.from_file(structure).structure

    # Layer mode
    if mode == "layers":
        if isinstance(structure, Interface):
            result = _freeze_interface_layers(
                structure, int(abs(coord1)), int(abs(coord2))
            )
        elif isinstance(structure, Surface):
            result = _freeze_surface_layers(structure, int(abs(coord1)))
        else:
            raise TypeError(
                "mode='layers' requires structure to be a Surface or Interface, "
                f"got {type(structure).__name__}"
            )
        if output:
            Poscar(result).write_file(output)
        return result

    # Fractional or Cartesian coordinate range mode
    if isinstance(structure, (Surface, Interface)):
        slab = structure.slab
        if slab is None:
            raise ValueError("Surface/Interface has no slab attribute")
        frozen = slab.copy()
    else:
        frozen = structure.copy()

    # Map axis to coordinate index
    axis_map = {"a": 0, "b": 1, "c": 2}
    axis_idx = axis_map[axis]

    # Ensure coord1 <= coord2
    lo, hi = min(coord1, coord2), max(coord1, coord2)

    for site in frozen:
        if mode == "cartesian":
            coord_val = round(site.coords[axis_idx], 6)
        else:  # mode == "direct"
            coord_val = round(site.frac_coords[axis_idx], 6)

        in_range = lo <= coord_val <= hi

        if in_range:
            # Freeze sites in range
            site.properties["selective_dynamics"] = [False, False, False]
        elif reset:
            # Reset sites outside range to unfrozen
            site.properties["selective_dynamics"] = [True, True, True]
        # If not reset and not in_range, preserve existing flags (do nothing)

    if output:
        Poscar(frozen).write_file(output)

    return frozen


def unique_miller(
    structure: Structure,
    max_order: int = 10,
) -> list[tuple[int, int, int]]:
    """Return symmetry-distinct 3-index Miller tuples up to ``max_order``."""
    if int(max_order) < 1:
        raise ValueError("max_order must be >= 1")

    candidates = get_symmetrically_distinct_miller_indices(
        structure,
        max_index=int(max_order),
    )

    normalized = [
        (int(index[0]), int(index[1]), int(index[2]))
        for index in candidates
        if len(index) >= 3
    ]

    return sorted(
        normalized,
        key=lambda index: (
            index[0] ** 2 + index[1] ** 2 + index[2] ** 2,
            index[0],
            index[1],
            index[2],
        ),
    )


def bond_length_analysis(structure: Structure) -> dict[str, Any]:
    """Analyze bond lengths in a Structure."""
    # TODO: implement
    pass


def xray_analysis(structure: Structure) -> dict[str, Any]:
    """Analyze X-ray diffraction patterns for a Structure."""
    # TODO: implement
    pass


def saed_analysis(structure: Structure) -> dict[str, Any]:
    """Analyze SAED patterns for a Structure."""
    # TODO: implement
    pass


# TODO: Standardize SFY static settings without passing by Sculptor
# TODO: Move heavy logic of public utilities to internals and leanly re-export it here for clarity
# TODO: Improve `freeze_coords` to better handle masking (i.e. adparticles, etc). Also review how to remove selective dynamics completely: coord1=0?