"""
Core functionality for slabfy package.

This module provides the core data structures and utilities for representing and
manipulating surfaces and interfaces, independent of any specific calculator or
analysis routines. It includes:

- :class:`Bulk` — dataclass representing a bulk reference structure.
- :class:`Adparticle` - dataclass representing an adsorbed particle.
- :class:`Surface` — dataclass representing a single surface slab.
- :class:`Interface` — dataclass representing an interface between two slabs.

- :class:`Sculptor` — main user-facing class for creating and analyzing surfaces
    and interfaces.  Provides high-level methods that wrap the core data
    structures and delegate to calculator-specific tools for execution and parsing.
"""

__all__ = [
    "Bulk",
    "Adparticle",
    "Surface",
    "Interface",
    "Sculptor",
]

from slabfy import utils
from slabfy.internals import _core as internals

import os
import pickle
import base64
import warnings
import numpy as np

from typing import Any, Union, Literal
from collections import defaultdict

from pymatgen.io.vasp.inputs import Poscar
from pymatgen.core.structure import Structure
from pymatgen.core.surface import Slab, SlabGenerator
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer

# Re-exported so that internals._core can access it via
# ``import slabfy.core as _core_mod; _core_mod.AdsorbateSiteFinder``
# and tests can monkeypatch ``slabfy.core.AdsorbateSiteFinder``.
from pymatgen.analysis.adsorption import AdsorbateSiteFinder  # noqa: F401

"""
╔═╗┌┐  ┬┌─┐┌─┐┌┬┐┌─┐
║ ║├┴┐ │├┤ │   │ └─┐
╚═╝└─┘└┘└─┘└─┘ ┴ └─┘
"""


class Bulk:
    """Lightweight container for a bulk crystal structure.

    Wraps a :class:`~pymatgen.core.structure.Structure` with
    slabfy-native serialization (POSCAR with embedded pickle)
    and a minimal set of derived metadata.
    """

    structure = None
    energy = None
    properties_metadata = None

    def __init__(self, structure: Structure, **kwargs):
        self.structure = structure
        self.energy = kwargs.get("energy", None)
        self.properties_metadata = kwargs.get("properties_metadata", {})
        self._refresh_metadata()

    def __str__(self) -> str:
        lines: list[str] = []
        formula = "None"
        if self.structure is not None:
            full = "".join(str(self.structure.composition.formula).split(" "))
            reduced = self.structure.composition.reduced_formula
            formula = f"{full} ({reduced})"
        lines.append(f"Bulk: {formula}")
        lines.append("----------------------------------------")
        if self.structure is not None:
            a, b, c = self.structure.lattice.abc
            alpha, beta, gamma = self.structure.lattice.angles
            lines.append(f"abc   :  {a:9.5f}  {b:9.5f}  {c:9.5f}")
            lines.append(f"angles:  {alpha:9.5f}  {beta:9.5f}  {gamma:9.5f}")
            lines.append(f"sites :  {len(self.structure)}")
        energy_str = f"{self.energy:.6f}" if self.energy is not None else "None"
        lines.append(f"energy:  {energy_str}")
        lines.append("----------------------------------------")
        summary = (
            internals._symmetry_summary(self.structure)
            if self.structure is not None
            else None
        )
        if summary is not None:
            lines.append("Symmetry:")
            for key, value in summary.items():
                lines.append(f"  {key}: {value}")

        return "\n".join(lines)

    def _refresh_metadata(self) -> None:
        """Recompute derived metadata from ``self.structure``."""
        if self.structure is None:
            return
        if self.properties_metadata is None:
            self.properties_metadata = {}

    def write(
        self,
        filename: str = "POSCAR",
        *,
        direct: bool = False,
        sort_structure: bool = True,
    ) -> None:
        """Serialize this Bulk to a POSCAR with embedded pickle."""
        if self.structure is None:
            raise ValueError("No structure is associated with this Bulk")

        poscar = Poscar(self.structure, sort_structure=sort_structure)
        poscar.write_file(filename, direct=direct)

        payload = base64.b64encode(pickle.dumps(self)).decode("ascii")
        with open(filename, "r", encoding="utf-8") as fh:
            lines = fh.readlines()
        if not lines:
            raise ValueError(f"Could not read POSCAR content from {filename}")

        lines[0] = f"{utils.BULK_B64_PREFIX}{payload}\n"
        with open(filename, "w", encoding="utf-8") as fh:
            fh.writelines(lines)

    @classmethod
    def read(cls, filename: str = "POSCAR"):
        """Deserialize a Bulk from a POSCAR written by ``Bulk.write``."""
        with open(filename, "r", encoding="utf-8") as fh:
            first_line = fh.readline().strip()

        if not first_line.startswith(utils.BULK_B64_PREFIX):
            raise ValueError(
                f"File {filename} does not contain serialized Bulk metadata"
            )

        payload = first_line[len(utils.BULK_B64_PREFIX) :].strip()
        try:
            bulk_obj = pickle.loads(base64.b64decode(payload))
        except Exception as exc:
            raise ValueError(f"Invalid serialized Bulk payload in {filename}") from exc

        if not isinstance(bulk_obj, cls):
            raise ValueError(
                f"Serialized payload in {filename} is not a {cls.__name__}"
            )
        return bulk_obj


class Adparticle:
    """Lightweight container for an adsorbate / adparticle structure.

    Wraps a :class:`~pymatgen.core.structure.Structure` (molecule in
    a box) with slabfy-native POSCAR serialization and minimal
    derived metadata.
    """

    structure = None
    energy = None
    properties_metadata = None

    def __init__(self, structure: Structure, **kwargs):
        self.structure = structure
        self.energy = kwargs.get("energy", None)
        self.properties_metadata = kwargs.get("properties_metadata", {})
        self._refresh_metadata()

    def __str__(self) -> str:
        lines: list[str] = []
        formula = "None"
        if self.structure is not None:
            full = "".join(str(self.structure.composition.formula).split(" "))
            reduced = self.structure.composition.reduced_formula
            formula = f"{full} ({reduced})"
        lines.append(f"Adparticle: {formula}")
        lines.append("----------------------------------------")
        if self.structure is not None:
            lines.append(f"sites :  {len(self.structure)}")
        energy_str = f"{self.energy:.6f}" if self.energy is not None else "None"
        lines.append(f"energy:  {energy_str}")
        lines.append("----------------------------------------")
        return "\n".join(lines)

    def _refresh_metadata(self) -> None:
        """Recompute derived metadata from ``self.structure``."""
        if self.structure is None:
            return
        if self.properties_metadata is None:
            self.properties_metadata = {}

    def write(
        self,
        filename: str = "POSCAR",
        *,
        direct: bool = False,
        sort_structure: bool = True,
    ) -> None:
        """Serialize this Adparticle to a POSCAR with embedded pickle."""
        if self.structure is None:
            raise ValueError("No structure is associated with this Adparticle")

        poscar = Poscar(self.structure, sort_structure=sort_structure)
        poscar.write_file(filename, direct=direct)

        payload = base64.b64encode(pickle.dumps(self)).decode("ascii")
        with open(filename, "r", encoding="utf-8") as fh:
            lines = fh.readlines()
        if not lines:
            raise ValueError(f"Could not read POSCAR content from {filename}")

        lines[0] = f"{utils.ADPARTICLE_B64_PREFIX}{payload}\n"
        with open(filename, "w", encoding="utf-8") as fh:
            fh.writelines(lines)

    @classmethod
    def read(cls, filename: str = "POSCAR"):
        """Deserialize an Adparticle from a POSCAR written by ``Adparticle.write``."""
        with open(filename, "r", encoding="utf-8") as fh:
            first_line = fh.readline().strip()

        if not first_line.startswith(utils.ADPARTICLE_B64_PREFIX):
            raise ValueError(
                f"File {filename} does not contain serialized Adparticle metadata"
            )

        payload = first_line[len(utils.ADPARTICLE_B64_PREFIX) :].strip()
        try:
            adparticle_obj = pickle.loads(base64.b64decode(payload))
        except Exception as exc:
            raise ValueError(
                f"Invalid serialized Adparticle payload in {filename}"
            ) from exc

        if not isinstance(adparticle_obj, cls):
            raise ValueError(
                f"Serialized payload in {filename} is not a {cls.__name__}"
            )
        return adparticle_obj


class Surface:
    slab = None
    slab_index = None
    slab_termination = None
    symmetric = None
    stoichiometric = None
    bulk = None
    miller = None
    thickness = None
    vacuum = None
    surface_area = None
    surface_axis_layers = None
    surface_dipole = None
    properties_metadata = None
    surface_sites = None
    surface_directions = None
    adparticle = None
    adparticle_energy = None
    energy = None
    scaling = None

    def __init__(self, slab: Slab | Structure, **kwargs):
        self.slab = slab
        self.slab_index = kwargs.get("slab_index", None)
        self.slab_termination = kwargs.get("slab_termination", None)
        self.symmetric = kwargs.get("symmetric", None)
        self.stoichiometric = kwargs.get("stoichiometric", None)
        _bulk_raw = kwargs.get("bulk", None)
        _bulk_energy = kwargs.get("bulk_energy", None)
        if isinstance(_bulk_raw, Bulk):
            self.bulk = _bulk_raw
        elif _bulk_raw is not None:
            self.bulk = Bulk(_bulk_raw)
        else:
            self.bulk = None
        if self.bulk is not None and _bulk_energy is not None:
            self.bulk.energy = _bulk_energy
        self.miller = kwargs.get("miller", None)
        self.thickness = kwargs.get("thickness", None)
        self.vacuum = kwargs.get("vacuum", None)
        self.surface_area = kwargs.get("surface_area", None)
        self.surface_axis_layers = kwargs.get("surface_axis_layers", None)
        self.surface_dipole = kwargs.get("surface_dipole", None)
        self.properties_metadata = kwargs.get("properties_metadata", {})
        self.surface_sites = kwargs.get("surface_sites", None)
        self.surface_directions = kwargs.get("surface_directions", None)
        self.adparticle = internals._coerce_adparticle(kwargs.get("adparticle", None))
        self.adparticle_energy = kwargs.get("adparticle_energy", None)
        self.energy = kwargs.get("energy", None)
        self.scaling = internals._normalize_scaling(kwargs.get("scaling", (1, 1, 1)))

        if self.slab_termination is None:
            if bool(self.symmetric):
                self.slab_termination = "SY"
            else:
                self.slab_termination = "UP"

    def __str__(self):
        lines = []
        sym_str = "symmetric" if self.symmetric else "asymmetric"
        stoich_str = "stoichiometric" if self.stoichiometric else "non-stoichiometric"
        slab_idx = self.slab_index if self.slab_index is not None else 0
        lines.append(
            f"Slab {slab_idx:02d} {str((sym_str + ', ' + stoich_str)).rjust(32)}"
        )
        lines.append("----------------------------------------")
        composition_text = None
        if self.slab is not None:
            try:
                full_formula = "".join(str(self.slab.composition.formula).split(" "))
                reduced_formula = self.slab.composition.reduced_formula
                composition_text = f"{full_formula} ({reduced_formula})"
            except Exception:
                composition_text = None
        lines.append(f"compos:  {str(composition_text).rjust(31)}")
        dipole_value = (
            0.0 if self.surface_dipole is None else float(self.surface_dipole)
        )
        lines.append(f"dipole:  {format(dipole_value, '.4f').rjust(31)}")
        scale_a, scale_b, scale_c = internals._normalize_scaling(self.scaling)
        area = self.surface_area if self.surface_area is not None else 0.0
        thick = self.thickness if self.thickness is not None else 0.0
        vac = self.vacuum if self.vacuum is not None else 0.0
        lines.append(
            "scale :"
            f"  {format(scale_a, '.1f').rjust(9)}"
            f"  {format(scale_b, '.1f').rjust(9)}"
            f"  {format(scale_c, '.1f').rjust(9)}"
        )
        lines.append(
            f"A/t/v :  {format(area, '.5f').rjust(9)}"
            f"  {format(thick, '.5f').rjust(9)}"
            f"  {format(vac, '.5f').rjust(9)}"
        )
        if self.slab is not None:
            try:
                a_len, b_len, c_len = self.slab.lattice.abc
                alpha, beta, gamma = self.slab.lattice.angles
                lines.append(
                    f"abc   :  {format(float(a_len), '.5f').rjust(9)}"
                    f"  {format(float(b_len), '.5f').rjust(9)}"
                    f"  {format(float(c_len), '.5f').rjust(9)}"
                )
                lines.append(
                    f"angles:  {format(float(alpha), '.5f').rjust(9)}"
                    f"  {format(float(beta), '.5f').rjust(9)}"
                    f"  {format(float(gamma), '.5f').rjust(9)}"
                )
            except Exception:
                pass
        lines.append("----------------------------------------")
        lines.append("termin:    height:   atom configuration:")
        if self.surface_axis_layers:
            items = list(self.surface_axis_layers.items())
            top_height = items[0][0]
            bottom_height = items[-1][0]
            top_values = items[0][1]
            bottom_values = items[-1][1]

            if self.slab_termination == "SY":
                top_label = "SY"
                bottom_label = "SY"
            else:
                top_label = "UP"
                bottom_label = "DN"

            lines.append(
                f"   {top_label.rjust(3)}:  "
                f"{format(top_height, '.5f').rjust(9)}   "
                f"{internals._layer_formula(top_values)}"
            )
            if top_height != bottom_height:
                lines.append(
                    f"   {bottom_label.rjust(3)}:  "
                    f"{format(bottom_height, '.5f').rjust(9)}   "
                    f"{internals._layer_formula(bottom_values)}"
                )

        lines.append("----------------------------------------")
        tag = self.slab_termination or "UP"
        ads_counts = internals._count_sites(self.surface_sites)
        ontop = ads_counts["ontop"]
        bridge = ads_counts["bridge"]
        hollow = ads_counts["hollow"]
        lines.append(
            f"{tag} ads:"
            f"  {str(ontop).rjust(2)} on-top"
            f"  {str(bridge).rjust(2)} bridge"
            f"  {str(hollow).rjust(2)} hollow"
        )

        paired_ads_counts = internals._get_paired_counts(self.surface_sites)

        if (
            tag == "UP"
            and isinstance(paired_ads_counts, dict)
            and {"ontop", "bridge", "hollow"} <= set(paired_ads_counts)
        ):
            lines.append(
                f"DN ads:"
                f"  {str(paired_ads_counts['ontop']).rjust(2)} on-top"
                f"  {str(paired_ads_counts['bridge']).rjust(2)} bridge"
                f"  {str(paired_ads_counts['hollow']).rjust(2)} hollow"
            )

        return "\n".join(lines)

    def _refresh_metadata(self):
        """Refresh derived metadata fields from the current slab."""
        if self.slab is None:
            return

        try:
            self.symmetric = bool(self.slab.is_symmetric())
        except Exception:
            if self.symmetric is None:
                self.symmetric = False

        try:
            thickness, vacuum = internals._slab_geometry(self.slab)
            self.thickness = thickness
            self.vacuum = vacuum
        except Exception:
            pass

        try:
            self.surface_axis_layers = internals._axis_layers(self.slab, axis="c")
        except Exception:
            pass

        try:
            axis_vector = np.array(self.slab.lattice.matrix[2], dtype=float)
            self.surface_dipole = internals._dipole_along_axis(self.slab, axis_vector)
        except Exception:
            self.surface_dipole = 0.0

        try:
            self.surface_area = internals._area_ab(self.slab)
        except Exception:
            self.surface_area = 0.0

        if self.bulk is not None and self.miller is not None:
            try:
                self.surface_directions = internals._map_surface_directions(self)
            except Exception:
                pass

        if self.bulk is not None:
            try:
                self.stoichiometric = internals._is_stoich(
                    self.bulk.structure, self.slab
                )
            except Exception:
                pass

        if self.slab_termination is None:
            self.slab_termination = "SY" if self.symmetric else "UP"

        try:
            self.surface_sites = internals._map_surface_sites(self)
        except Exception:
            self.surface_sites = self.surface_sites or {}

    def write(
        self,
        filename: str = "POSCAR",
        *,
        direct: bool = False,
        sort_structure: bool = True,
    ) -> None:
        """Write slab to POSCAR file and serialize full Surface in line 1."""
        if self.slab is None:
            raise ValueError("No slab is associated with this Surface")

        site_properties_raw = dict(self.slab.site_properties)
        site_properties_clean: dict[str, list[object]] = {}
        for prop_name, values in site_properties_raw.items():
            if prop_name == "selective_dynamics":
                normalized: list[list[bool]] = []
                for value in values:
                    if isinstance(value, (list, tuple)) and len(value) == 3:
                        normalized.append(
                            [bool(value[0]), bool(value[1]), bool(value[2])]
                        )
                    else:
                        normalized.append([True, True, True])
                site_properties_clean[prop_name] = normalized
                continue

            if any(value is None for value in values):
                continue
            site_properties_clean[prop_name] = list(values)

        slab_for_poscar = Structure(
            self.slab.lattice,
            self.slab.species,
            self.slab.frac_coords,
            coords_are_cartesian=False,
            site_properties=site_properties_clean,
        )

        poscar = Poscar(slab_for_poscar, sort_structure=sort_structure)
        poscar.write_file(filename, direct=direct)

        pickled_bytes = pickle.dumps(self)
        payload = base64.b64encode(pickled_bytes).decode("ascii")

        with open(filename, "r", encoding="utf-8") as file_obj:
            lines = file_obj.readlines()

        if not lines:
            raise ValueError(f"Could not read POSCAR content from {filename}")

        lines[0] = f"{utils.SURFACE_B64_PREFIX}{payload}\n"
        with open(filename, "w", encoding="utf-8") as file_obj:
            file_obj.writelines(lines)

    @classmethod
    def read(
        cls,
        filename: str = "POSCAR",
        *,
        sync_from_poscar: bool = True,
    ):
        """Read a Surface from *filename*.

        Parameters
        ----------
        filename : str
            Path to the POSCAR file written by ``Surface.write``.
        sync_from_poscar : bool
            When ``True`` (default), the POSCAR body is compared
            against the embedded slab.  If coordinates or lattice
            differ but the chemical composition is the same, the
            slab is replaced by the POSCAR structure and metadata
            is refreshed.  Set to ``False`` to always return the
            embedded object unmodified.
        """
        with open(filename, "r", encoding="utf-8") as file_obj:
            first_line = file_obj.readline().strip()

        if not first_line.startswith(utils.SURFACE_B64_PREFIX):
            raise ValueError(
                f"File {filename} does not contain serialized Surface metadata"
            )

        payload = first_line[len(utils.SURFACE_B64_PREFIX) :].strip()
        try:
            surface_obj = pickle.loads(base64.b64decode(payload))
        except Exception as exc:
            raise ValueError(
                f"Invalid serialized Surface payload in {filename}"
            ) from exc

        if not isinstance(surface_obj, cls):
            raise ValueError(
                f"Serialized payload in {filename} is not a {cls.__name__}"
            )

        if not sync_from_poscar:
            return surface_obj

        # --- sync slab from POSCAR body --------------------------
        try:
            poscar_structure = Poscar.from_file(filename).structure
        except Exception:
            return surface_obj

        if surface_obj.slab is None:
            return surface_obj

        from pymatgen.analysis.structure_matcher import (
            StructureMatcher,
        )

        matcher = StructureMatcher(
            ltol=0.01,
            stol=0.01,
            angle_tol=0.5,
            primitive_cell=False,
        )
        if matcher.fit(surface_obj.slab, poscar_structure):
            return surface_obj

        if (
            surface_obj.slab.composition.get_el_amt_dict()
            != poscar_structure.composition.get_el_amt_dict()
        ):
            warnings.warn(
                f"POSCAR composition in {filename} differs from "
                "embedded object; returning embedded object "
                "without updating slab.",
                stacklevel=2,
            )
            return surface_obj

        # Composition matches — update slab and refresh
        surface_obj.slab = poscar_structure
        surface_obj.surface_sites = None
        surface_obj.surface_directions = None
        surface_obj._refresh_metadata()
        return surface_obj


class Interface(Surface):
    slab = None
    slab_index = None
    slab_termination = None
    mode = None
    thickness = None
    vacuum = None
    gap = None
    stoichiometric = None
    symmetric = None
    surface1 = None
    surface2 = None
    interface_axis = None
    interface_axis_layers = None
    interface_metadata = None
    interface_axis_position = None
    interface_area = None
    interface_dipole = None
    interface_strain = None
    interface_density = None
    miller1 = None
    miller2 = None
    interface_sites = None
    adparticle = None
    adparticle_energy = None
    energy = None

    def __init__(self, slab: Structure, **kwargs):
        super().__init__(slab, **kwargs)

        self.surface1 = kwargs.get("surface1", None)
        self.surface2 = kwargs.get("surface2", None)
        self.mode = kwargs.get("mode", None)
        self.adparticle = kwargs.get("adparticle", None)
        self.adparticle_energy = kwargs.get("adparticle_energy", None)
        self.energy = kwargs.get("energy", None)

        self.interface_axis = kwargs.get("interface_axis", None)
        self.gap = kwargs.get("gap", None)
        self.vacuum = kwargs.get("vacuum", self.vacuum)
        self.interface_strain = kwargs.get("interface_strain", None)
        self.interface_area = kwargs.get("interface_area", None)
        self.interface_dipole = kwargs.get("interface_dipole", None)
        self.interface_density = kwargs.get("interface_density", None)
        self.miller1 = kwargs.get("miller1", None)
        self.miller2 = kwargs.get("miller2", None)
        self.thickness = kwargs.get("thickness", self.thickness)
        self.interface_metadata = kwargs.get("interface_metadata", None)
        self.interface_axis_position = kwargs.get("interface_axis_position", None)
        self.interface_axis_layers = kwargs.get("interface_axis_layers", None)
        self.interface_sites = kwargs.get("interface_sites", None)
        self.slab_termination = kwargs.get("slab_termination", self.slab_termination)
        self.symmetric = kwargs.get("symmetric", self.symmetric)

        self._refresh_metadata()

    def __str__(self) -> str:
        lines: list[str] = []

        def _fmt_miller(value: Any) -> str:
            if value is None:
                return "(None)"
            try:
                normalized = internals._normalize_miller(tuple(value))
                return f"({normalized[0]},{normalized[1]},{normalized[2]})"
            except Exception:
                return str(value)

        sym_str = "symmetric" if self.symmetric else "asymmetric"
        stoich_str = "stoichiometric" if self.stoichiometric else "non-stoichiometric"
        slab_idx = int(self.slab_index or 0)
        lines.append(
            f"Slab {slab_idx:03d} {str((sym_str + ', ' + stoich_str)).rjust(31)}"
        )
        lines.append("----------------------------------------")

        composition_text = None
        if self.slab is not None:
            try:
                full_formula = "".join(str(self.slab.composition.formula).split(" "))
                reduced1 = (
                    self.surface1.slab.composition.reduced_formula
                    if self.surface1 is not None and self.surface1.slab is not None
                    else "None"
                )
                reduced2 = (
                    self.surface2.slab.composition.reduced_formula
                    if self.surface2 is not None and self.surface2.slab is not None
                    else "None"
                )
                composition_text = f"{full_formula} ({reduced1}-{reduced2})"
            except Exception:
                composition_text = None
        lines.append(f"compos:  {str(composition_text).rjust(31)}")

        scale1 = internals._normalize_scaling(
            getattr(self.surface1, "scaling", (1, 1, 1))
        )
        scale2 = internals._normalize_scaling(
            getattr(self.surface2, "scaling", (1, 1, 1))
        )
        lines.append(
            "scale1:"
            f"  {format(scale1[0], '.1f').rjust(9)}"
            f"  {format(scale1[1], '.1f').rjust(9)}"
            f"  {format(scale1[2], '.1f').rjust(9)}"
        )
        lines.append(
            "scale2:"
            f"  {format(scale2[0], '.1f').rjust(9)}"
            f"  {format(scale2[1], '.1f').rjust(9)}"
            f"  {format(scale2[2], '.1f').rjust(9)}"
        )

        surface_area = 0.0
        try:
            surface_area = float(internals._area_ab(self.slab))
        except Exception:
            pass
        interface_area = (
            0.0 if self.interface_area is None else float(self.interface_area)
        )
        thickness = 0.0 if self.thickness is None else float(self.thickness)
        vacuum = 0.0 if self.vacuum is None else float(self.vacuum)
        lines.append(
            f"A/t/v :  {format(surface_area, '.5f').rjust(9)}"
            f"  {format(thickness, '.5f').rjust(9)}"
            f"  {format(vacuum, '.5f').rjust(9)}"
        )

        if self.slab is not None:
            try:
                a_len, b_len, c_len = self.slab.lattice.abc
                alpha, beta, gamma = self.slab.lattice.angles
                lines.append(
                    f"abc   :  {format(float(a_len), '.5f').rjust(9)}"
                    f"  {format(float(b_len), '.5f').rjust(9)}"
                    f"  {format(float(c_len), '.5f').rjust(9)}"
                )
                lines.append(
                    f"angles:  {format(float(alpha), '.5f').rjust(9)}"
                    f"  {format(float(beta), '.5f').rjust(9)}"
                    f"  {format(float(gamma), '.5f').rjust(9)}"
                )
            except Exception:
                pass

        lines.append("----------------------------------------")
        if str(self.mode or "").lower() == "lateral":
            bulk1_miller = self.miller1
            bulk2_miller = self.miller2
        else:
            bulk1_miller = internals._resolve_if_miller(self, 1)
            bulk2_miller = internals._resolve_if_miller(self, 2)
        lines.append(
            f"hkl⟂  :  {_fmt_miller(bulk1_miller).rjust(20)}"
            f"  {_fmt_miller(bulk2_miller).rjust(9)}"
        )
        gap = 0.0 if self.gap is None else float(self.gap)
        mode = str(self.mode or "None")
        lines.append(
            f"A/G/M :  {format(interface_area, '.5f').rjust(9)}"
            f"   {format(gap, '.2f')} gap"
            f"  {mode.rjust(9)}"
        )
        strain = 0.0 if self.interface_strain is None else float(self.interface_strain)
        dip = 0.0 if self.interface_dipole is None else float(self.interface_dipole)
        rho = 0.0 if self.interface_density is None else float(self.interface_density)
        lines.append(
            f"ε/d/ρ :  {format(strain, '.5f').rjust(9)}"
            f"  {format(dip, '.5f').rjust(9)}"
            f"  {format(rho, '.5f').rjust(9)}"
        )

        lines.append("----------------------------------------")
        lines.append(
            f"contact:   {str(self.interface_axis or 'c')}-axis:   atom configuration:"
        )
        surface1_contact, surface2_contact = internals._pick_if_contacts(
            self.interface_axis_layers,
            self.interface_axis_position,
        )
        if surface1_contact is not None:
            lines.append(
                f"     s1: {format(surface1_contact[0], '.5f').rjust(9)}   "
                f"{internals._layer_formula(surface1_contact[1])}"
            )
        if surface2_contact is not None:
            lines.append(
                f"     s2: {format(surface2_contact[0], '.5f').rjust(9)}   "
                f"{internals._layer_formula(surface2_contact[1])}"
            )

        def _format_ads_row(label: str, counts: dict[str, int]) -> str:
            return (
                f"    {label}:  {int(counts.get('ontop', 0)):02d} on-top"
                f"  {int(counts.get('bridge', 0)):02d} bridge"
                f"  {int(counts.get('hollow', 0)):02d} hollow"
            )

        s1_counts = internals._count_sites(
            getattr(self.surface1, "surface_sites", None)
        )
        s2_counts = internals._count_sites(
            getattr(self.surface2, "surface_sites", None)
        )
        int_counts = internals._count_sites(self.interface_sites)

        lines.append("----------------------------------------")
        tag = str(self.slab_termination or "UP").upper()
        lines.append(f"{tag} ads:")
        lines.append(_format_ads_row("s1", s1_counts))
        lines.append(_format_ads_row("s2", s2_counts))
        lines.append(_format_ads_row("int", int_counts).replace("    int", "   int"))

        if tag == "UP":
            paired = {}
            if isinstance(self.interface_metadata, dict):
                paired = self.interface_metadata.get("paired_ads_counts", {})
            paired_s1 = (
                paired.get("surface1", s1_counts)
                if isinstance(paired, dict)
                else s1_counts
            )
            paired_s2 = (
                paired.get("surface2", s2_counts)
                if isinstance(paired, dict)
                else s2_counts
            )
            paired_int = (
                paired.get("interface", int_counts)
                if isinstance(paired, dict)
                else int_counts
            )
            lines.append("DN ads:")
            lines.append(_format_ads_row("s1", paired_s1))
            lines.append(_format_ads_row("s2", paired_s2))
            lines.append(
                _format_ads_row("int", paired_int).replace("    int", "   int")
            )

        return "\n".join(lines)

    def _refresh_metadata(self) -> None:
        if self.slab is None:
            return

        if self.slab_termination is None:
            self.slab_termination = "UP"

        axis_key = str(self.interface_axis or "c").lower()
        axis_index = {"a": 0, "b": 1, "c": 2}.get(axis_key, 2)
        self.interface_axis = ("a", "b", "c")[axis_index]

        lattice_rows = np.array(self.slab.lattice.matrix, dtype=float)
        axis_vector = np.array(lattice_rows[axis_index], dtype=float)
        axis_hat = internals._unit_vec(axis_vector)
        projections = np.dot(self.slab.cart_coords.astype(float), axis_hat)
        if self.interface_axis_position is None:
            self.interface_axis_position = float(np.mean(projections))
        interface_depth = 2.0

        if self.thickness is None:
            if str(self.mode or "").lower() == "lateral":
                self.thickness = max(
                    float(getattr(self.surface1, "thickness", 0.0) or 0.0),
                    float(getattr(self.surface2, "thickness", 0.0) or 0.0),
                )
            else:
                self.thickness = float(np.max(projections) - np.min(projections))

        if str(self.mode or "").lower() == "lateral":
            self.interface_area = float(
                float(self.thickness or 0.0) * float(np.linalg.norm(lattice_rows[0]))
            )
        else:
            self.interface_area = internals._area_ab(self.slab)
        self.interface_dipole = internals._dipole_along_axis(
            self.slab,
            axis_vector,
            center_position=float(self.interface_axis_position),
            window_depth=interface_depth,
        )
        self.interface_density = internals._density_near_axis(
            self.slab,
            axis_vector,
            float(self.interface_axis_position),
            interface_depth,
        )
        self.interface_axis_layers = internals._axis_layers(
            self.slab,
            axis=self.interface_axis,
        )

        if self.miller1 is None and self.surface1 is not None:
            self.miller1 = getattr(self.surface1, "miller", None)
        if self.miller2 is None and self.surface2 is not None:
            self.miller2 = getattr(self.surface2, "miller", None)

        if self.interface_sites is None:
            self.interface_sites = internals._compute_if_sites(self)

    def write(
        self,
        filename: str = "POSCAR",
        *,
        direct: bool = False,
        sort_structure: bool = True,
    ) -> None:
        if self.slab is None:
            raise ValueError("No interface structure is associated with this Interface")

        site_properties_raw = dict(self.slab.site_properties)
        site_properties_clean: dict[str, list[object]] = {}
        for prop_name, values in site_properties_raw.items():
            if prop_name == "selective_dynamics":
                normalized: list[list[bool]] = []
                for value in values:
                    if isinstance(value, (list, tuple)) and len(value) == 3:
                        normalized.append(
                            [bool(value[0]), bool(value[1]), bool(value[2])]
                        )
                    else:
                        normalized.append([True, True, True])
                site_properties_clean[prop_name] = normalized
                continue

            if any(value is None for value in values):
                continue
            site_properties_clean[prop_name] = list(values)

        structure_for_poscar = Structure(
            self.slab.lattice,
            self.slab.species,
            self.slab.frac_coords,
            coords_are_cartesian=False,
            site_properties=site_properties_clean,
        )

        poscar = Poscar(structure_for_poscar, sort_structure=sort_structure)
        poscar.write_file(filename, direct=direct)

        payload = base64.b64encode(pickle.dumps(self)).decode("ascii")
        with open(filename, "r", encoding="utf-8") as file_obj:
            lines = file_obj.readlines()
        if not lines:
            raise ValueError(f"Could not read POSCAR content from {filename}")

        lines[0] = f"{utils.INTERFACE_B64_PREFIX}{payload}\n"
        with open(filename, "w", encoding="utf-8") as file_obj:
            file_obj.writelines(lines)

    @classmethod
    def read(
        cls,
        filename: str = "POSCAR",
        *,
        sync_from_poscar: bool = True,
    ):
        """Read an Interface from *filename*.

        Parameters
        ----------
        filename : str
            Path to the POSCAR file written by ``Interface.write``.
        sync_from_poscar : bool
            When ``True`` (default), the POSCAR body is compared
            against the embedded slab.  If coordinates or lattice
            differ but the chemical composition is the same, the
            slab is replaced by the POSCAR structure and metadata
            is refreshed.  Set to ``False`` to always return the
            embedded object unmodified.
        """
        with open(filename, "r", encoding="utf-8") as file_obj:
            first_line = file_obj.readline().strip()

        if not first_line.startswith(utils.INTERFACE_B64_PREFIX):
            raise ValueError(
                f"File {filename} does not contain serialized Interface metadata"
            )

        payload = first_line[len(utils.INTERFACE_B64_PREFIX) :].strip()
        try:
            interface_obj = pickle.loads(base64.b64decode(payload))
        except Exception as exc:
            raise ValueError(
                f"Invalid serialized Interface payload in {filename}"
            ) from exc

        if not isinstance(interface_obj, cls):
            raise ValueError(
                f"Serialized payload in {filename} is not a {cls.__name__}"
            )

        if not sync_from_poscar:
            return interface_obj

        # --- sync slab from POSCAR body --------------------------
        try:
            poscar_structure = Poscar.from_file(filename).structure
        except Exception:
            return interface_obj

        if interface_obj.slab is None:
            return interface_obj

        from pymatgen.analysis.structure_matcher import (
            StructureMatcher,
        )

        matcher = StructureMatcher(
            ltol=0.01,
            stol=0.01,
            angle_tol=0.5,
            primitive_cell=False,
        )
        if matcher.fit(interface_obj.slab, poscar_structure):
            return interface_obj

        if (
            interface_obj.slab.composition.get_el_amt_dict()
            != poscar_structure.composition.get_el_amt_dict()
        ):
            warnings.warn(
                f"POSCAR composition in {filename} differs from "
                "embedded object; returning embedded object "
                "without updating slab.",
                stacklevel=2,
            )
            return interface_obj

        # Composition matches — update slab and refresh
        interface_obj.slab = poscar_structure
        interface_obj.interface_sites = None
        interface_obj._refresh_metadata()
        return interface_obj


"""
╔═╗╔═╗╦  ╔═╗┬  ┌─┐┌─┐┌─┐
╠═╣╠═╝║  ║  │  ├─┤└─┐└─┐
╩ ╩╩  ╩  ╚═╝┴─┘┴ ┴└─┘└─┘
"""


class Sculptor:
    def __init__(self, **kwargs):
        _static = utils.SFY_SETTINGS.get("STATIC", {})
        self.settings = {
            "format": _static.get("DEFAULT_FORMAT", "cartesian"),
            "freeze": _static.get("DEFAULT_FREEZE", -3),
            "output-mode": _static.get("DEFAULT_OUTPUT_MODE", 1),
            "verbose": _static.get("DEFAULT_VERBOSE", 1),
        }
        # Normalize underscore variants → canonical hyphen keys
        canonical = {k.replace("_", "-"): v for k, v in kwargs.items()}
        self.settings.update(canonical)

    @internals._recursive_sculptor_method
    def cleave(
        self,
        bulk: Union[Structure, str],
        miller: Union[tuple, int],
        thickness: float = 10,
        vacuum: float = 15,
        symmetry: bool = False,
        slab_index: int = None,
        termination_id: str = None,
        preserve_bonds: (dict[tuple[str, str], float] | None) = None,
        filter: tuple = ("surface_dipole<", 0),
        a_width: float | None = None,
        b_width: float | None = None,
        bulk_energy: int | None = None,
    ) -> list[Surface]:
        """
        Generate surfaces from a bulk material.

        """

        verbose = bool(self.settings.get("verbose", 1))

        def _vprint(message: str) -> None:
            if verbose:
                print(f"[cleave] {message}")

        if isinstance(miller, int):
            max_order = int(miller)
            if max_order <= 0:
                raise ValueError("miller integer mode requires max order > 0")

            structure_for_enum = internals._resolve_bulk(bulk)
            miller_list = internals.unique_miller(
                structure_for_enum, max_order=max_order
            )
            if not miller_list:
                return []

            all_surfaces: list[Surface] = []
            for miller_candidate in miller_list:
                miller_tuple_candidate = internals._normalize_miller(
                    tuple(miller_candidate)
                )
                _vprint(
                    f"multi-miller mode: running cleave for {miller_tuple_candidate}"
                )
                surfaces_candidate = self.cleave(
                    bulk=bulk,
                    miller=miller_tuple_candidate,
                    bulk_energy=bulk_energy,
                    thickness=thickness,
                    vacuum=vacuum,
                    symmetry=symmetry,
                    slab_index=slab_index,
                    termination_id=termination_id,
                    preserve_bonds=preserve_bonds,
                    filter=filter,
                    a_width=a_width,
                    b_width=b_width,
                )
                all_surfaces.extend(surfaces_candidate)
            return all_surfaces

        miller_tuple = internals._normalize_miller(miller)
        _vprint(
            f"start bulk={bulk} miller={miller_tuple} "
            f"thickness>={thickness} vacuum>={vacuum} symmetry={symmetry}"
        )
        _vprint(
            "using SlabGenerator with wrapper-side verbose logs "
            "(no internal SlabGenerator verbosity flag)"
        )

        structure = internals._resolve_bulk(bulk)
        structure_oxi = internals._prep_charges(structure, verbose=verbose)
        _vprint(
            f"loaded structure: {internals._format_formula(structure)} "
            f"({len(structure)} atoms)"
        )

        min_slab_size = int(thickness)
        bond_constraints = internals._parse_bonds(preserve_bonds)
        slabs = []
        for _attempt in range(6):
            _vprint(
                f"slab generation attempt {_attempt + 1}/6 "
                f"with min_slab_size={min_slab_size}"
            )
            slabgen = SlabGenerator(
                structure_oxi,
                miller_tuple,
                min_slab_size=min_slab_size,
                min_vacuum_size=vacuum,
                center_slab=True,
            )
            try:
                slabs = slabgen.get_slabs(
                    bonds=bond_constraints,
                    ftol=1e-12,
                    symmetrize=symmetry,
                )
            except Exception as exc:
                if symmetry:
                    if verbose:
                        print(
                            "Warning: symmetrized slab generation failed "
                            f"({exc}); retrying without symmetrization"
                        )
                    slabs = slabgen.get_slabs(
                        bonds=bond_constraints,
                        ftol=1e-12,
                        symmetrize=False,
                    )
                    symmetry = False
                else:
                    raise

            if not slabs:
                _vprint("no slabs generated; stopping attempts")
                break

            _vprint(f"generated {len(slabs)} candidate slabs")

            thickness_values = [
                internals._slab_geometry(slab.get_orthogonal_c_slab())[0]
                for slab in slabs
            ]
            if all(value >= float(thickness) - 1e-6 for value in thickness_values):
                _vprint("all slab candidates satisfy requested minimum thickness")
                break
            min_slab_size += 1
            _vprint("increasing min_slab_size for next attempt")

        # build a reference short-slab to obtain layer counts for scaling info
        slabgen_ref = SlabGenerator(
            structure_oxi,
            miller_tuple,
            min_slab_size=1,
            min_vacuum_size=0,
        )
        try:
            slabs_ref = slabgen_ref.get_slabs(ftol=1e-12)
        except Exception:
            slabs_ref = []
        if slabs_ref:
            sites_ref = list(slabs_ref[0].sites)
            layers_ref = len({round(site.c, 6) for site in sites_ref})
        else:
            layers_ref = 1
        _vprint(f"reference layer count={layers_ref}")

        surfaces: list[Surface] = []
        for n, slab in enumerate(slabs):
            _vprint(f"processing slab {n + 1}/{len(slabs)}")
            try:
                slab = slab.get_orthogonal_c_slab()
            except Exception as exc:
                if verbose:
                    print(f"Warning: could not orthogonalize slab {n + 1}: {exc}")
                continue

            try:
                slab = internals._set_vacuum(slab, float(vacuum))
            except Exception as exc:
                if verbose:
                    print(
                        f"Warning: could not enforce exact vacuum on slab {n + 1}: {exc}"
                    )

            slab_surfaces = internals._process_slab(
                n=n,
                slab=slab,
                miller=miller_tuple,
                symmetry=symmetry,
                layers_ref=layers_ref,
                bulk_structure=structure,
                structure_ref=structure_oxi,
                bulk_energy=bulk_energy,
                settings=self.settings,
            )
            surfaces.extend(slab_surfaces)
            _vprint(
                f"slab {n + 1}: generated {len(slab_surfaces)} surface termination(s)"
            )

        # Apply width-based in-plane scaling if requested
        for surface in surfaces:
            lattice_rows = np.array(
                surface.slab.lattice.matrix,
                dtype=float,
            )
            a_len = float(np.linalg.norm(lattice_rows[0]))
            b_len = float(np.linalg.norm(lattice_rows[1]))
            na = (
                int(np.ceil(float(a_width) / a_len))
                if a_width is not None and a_len > 0
                else 1
            )
            nb = (
                int(np.ceil(float(b_width) / b_len))
                if b_width is not None and b_len > 0
                else 1
            )
            if na > 1 or nb > 1:
                surface.slab.make_supercell(
                    [[na, 0, 0], [0, nb, 0], [0, 0, 1]],
                )
                old_a, old_b, old_c = (
                    int(surface.scaling[0]),
                    int(surface.scaling[1]),
                    int(surface.scaling[2]),
                )
                surface.scaling = (
                    old_a * na,
                    old_b * nb,
                    old_c,
                )
                surface.surface_area = internals._area_ab(
                    surface.slab,
                )
                surface.surface_sites = internals._map_surface_sites(surface)
                _vprint(f"scaled slab {na}×{nb} (a≥{a_width}, b≥{b_width})")

        # Apply filter/sort/cap and re-enumerate slab_index
        surfaces = internals._apply_filter(surfaces, filter)

        try:
            sga = SpacegroupAnalyzer(structure)
            space_group = (
                f"{sga.get_space_group_symbol()} (#{sga.get_space_group_number()})"
            )
            wyckoff_list = sga.get_symmetrized_structure().wyckoff_symbols
            wyckoff_symbols = ", ".join(sorted(set(wyckoff_list)))
        except Exception:
            space_group = "N/A"
            wyckoff_symbols = "N/A"

        output_mode: int
        try:
            output_mode = int(
                self.settings.get("output-mode", self.settings.get("output_mode", 1))
            )
        except (TypeError, ValueError):
            output_mode = 1
        report_surfaces = [
            surface
            for surface in surfaces
            if (surface.slab_termination or "UP") in ("UP", "SY")
        ]
        _vprint(
            f"report surfaces={len(report_surfaces)} total terminations={len(surfaces)}"
        )

        dn_ads_by_slab: dict[int, dict[str, int]] = {}
        for surface in surfaces:
            if (surface.slab_termination or "").upper() != "DN":
                continue
            index = int(surface.slab_index or 0)
            counts = internals._count_sites(surface.surface_sites)
            dn_ads_by_slab[index] = {
                "ontop": counts["ontop"],
                "bridge": counts["bridge"],
                "hollow": counts["hollow"],
            }

        for surface in report_surfaces:
            if (surface.slab_termination or "").upper() == "UP":
                index = int(surface.slab_index or 0)
                if index in dn_ads_by_slab:
                    internals._set_paired_counts(surface, dn_ads_by_slab[index])
        report_lines = [
            utils.HEADER,
            "input:",
            "",
            f"  bulk structure: {internals._format_formula(structure)}",
            # f'  space group: {space_group}',
            # f'  wyckoff sites: {wyckoff_symbols}',
            f"  miller indice: {miller_tuple}",
            f"  min thickness: {thickness}",
            f"  vacuum size: {vacuum}",
            f"  symmetric: {symmetry}",
            f"  filter: {filter}",
            "",
            "summary:",
            "",
            f"  slabs: {len(slabs)}",
            f"  terminations: {len(surfaces)}",
            "",
        ]
        for surface in report_surfaces:
            report_lines.append("########################################")
            report_lines.append("")
            report_lines.append(str(surface))
            report_lines.append("")

        if output_mode == 1:
            _vprint("output-mode=1: printing summary report")
            print("\n".join(report_lines).rstrip())

        if output_mode == 2:
            file_args = {
                "T": int(thickness),
                "V": int(vacuum),
                "": "symmetrized" if symmetry else "stoichiometric",
            }

            run_root = getattr(self, "_run_root", None)
            out_root = internals._resolve_output_dir(
                "cleave",
                structure1=structure,
                miller1=miller_tuple,
                file_args=file_args,
                run_root=run_root,
            )
            out_name = os.path.join(out_root, "cleave.out")

            _vprint("output-mode=2: writing POSCAR files and report")
            for surface in surfaces:
                output_prefix = internals._output_prefix(
                    structure1=structure,
                    miller1=surface.miller,
                )

                file_props = {
                    "d": abs(surface.surface_dipole),
                }
                props_suffix = internals._suffix_tokens(file_props, value_first=False)
                file_name_parts = [
                    output_prefix,
                    internals._object_id(surface, prefix="surface", zpad=2),
                    *props_suffix,
                ]
                file_name = "_".join(file_name_parts) + ".vasp"
                file_path = os.path.join(out_root, file_name)
                surface.write(
                    filename=file_path,
                    direct=self.settings.get("format", "cartesian") == "direct",
                    sort_structure=True,
                )
                _vprint(f"wrote {file_path}")
            try:
                with open(out_name, "w", encoding="utf-8") as f:
                    f.write("\n".join(report_lines).rstrip() + "\n")
                _vprint(f"wrote report {out_name}")
            except Exception:
                pass

        _vprint("cleave finished")

        return surfaces

    @internals._recursive_sculptor_method
    def join(
        self,
        bulk1: Union[Structure, str],
        bulk2: Union[Structure, str],
        miller1: Union[tuple, int],
        miller2: Union[tuple, int],
        mode: Literal["epitaxial", "lateral"] = "epitaxial",
        bulk1_thickness: float | None = None,
        bulk2_thickness: float | None = None,
        gap: float = 1.75,
        vacuum: float = 15.0,
        filter: tuple = ("interface_strain<|interface_dipole<|interface_density>", 0),
        **kwargs: Any,
    ) -> list[Interface]:
        """Build heterojunctions from two bulks.

        Common args:
        - ``bulk1``: Bulk structure or POSCAR path for the first bulk.
        - ``bulk2``: Bulk structure or POSCAR path for the second bulk.
        - ``miller1``: Miller tuple or integer max order for bulk1.
        - ``miller2``: Miller tuple or integer max order for bulk2.
        - ``bulk1_thickness``: Min bulk1 slab thickness in Å.
        - ``bulk2_thickness``: Min bulk2 slab thickness in Å.
        - ``mode``: ``'epitaxial'`` or ``'lateral'``.
        - ``gap``: Target interface gap in Angstrom.
        - ``vacuum``: Target vacuum in Angstrom.
        - ``filter``: Optional tuple of (filter string, filter cap).
        - ``enable_contact_shifts``: When True, return all contact
          terminations (epitaxial: all slab c-axis shifts; lateral: all
          b-axis contact shifts). Default False.

        > Filter string syntax is a pipe-separated list of interface
        attributes, with optional '+' or '-' suffixes to indicate greater-than or
        less-than comparisons (e.g., "interface_strain-|interface_dipole+"),
        and optional '=value' for exact matches (e.g., "slab_termination=sy").

        > Filter cap is an integer to limit the number of interfaces returned: positive
        for top N (excluding ties), negative for top N (including ties), and 0 for no cap.

        Epitaxial-specific args are passed with ``kwargs``:
        - ``zsl_max_interface_area``: Area filter in Å².
        - ``zsl_max_length_tol``: ZSL length tolerance.
        - ``zsl_max_angle_tol``: ZSL angle tolerance.
        - ``termination_ftol``: SlabGenerator ftol for slab enumeration (default 0.25).
        - ``label_index``: Prefix slab index to termination labels (default True).
        - ``filter_out_sym_slabs``: Exclude symmetric slabs (default False).

        Lateral-specific args are passed with ``kwargs``:
        - ``bulk1_width`` / ``bulk2_width``: Minimum b-axis widths after a-axis matching.
        - ``bulk1_termination`` / ``bulk2_termination``: Optional ``(slab_index, slab_termination)`` selectors.
        - ``lateral_max_a_pair_strain`` / ``lateral_max_aavg``: a-axis matching controls.

        """
        verbose = bool(self.settings.get("verbose", 1))

        def _vprint(message: str) -> None:
            if verbose:
                print(f"[join] {message}")

        output_mode: int
        try:
            output_mode = int(
                self.settings.get("output-mode", self.settings.get("output_mode", 1))
            )
        except (TypeError, ValueError):
            output_mode = 1

        direction_mode = kwargs.get("direction", None)
        if isinstance(direction_mode, str) and direction_mode.strip():
            mode = direction_mode.strip().lower()

        if mode not in ("epitaxial", "lateral"):
            raise ValueError('mode must be either "epitaxial" or "lateral"')

        def _epitaxial_mode() -> list[Interface]:
            """Dispatch epitaxial interface construction."""
            nonlocal bulk1_thickness, bulk2_thickness
            bulk1_thickness = float(bulk1_thickness or 5.0)
            bulk2_thickness = float(bulk2_thickness or 5.0)
            return internals._process_epitaxial(
                bulk1=bulk1,
                bulk2=bulk2,
                miller1=miller1,
                miller2=miller2,
                bulk1_thickness=bulk1_thickness,
                bulk2_thickness=bulk2_thickness,
                gap=gap,
                vacuum=vacuum,
                settings=self.settings,
                **kwargs,
            )

        def _lateral_mode() -> list[Interface]:
            """Dispatch lateral interface construction."""
            nonlocal bulk1_thickness, bulk2_thickness
            bulk1_thickness = float(bulk1_thickness or 10.0)
            bulk2_thickness = float(bulk2_thickness or 10.0)
            return internals._process_lateral(
                bulk1=bulk1,
                bulk2=bulk2,
                miller1=miller1,
                miller2=miller2,
                bulk1_thickness=bulk1_thickness,
                bulk2_thickness=bulk2_thickness,
                gap=gap,
                vacuum=vacuum,
                settings=self.settings,
                **kwargs,
            )

        interfaces: list[Interface] | None = None
        if mode == "epitaxial":
            interfaces = _epitaxial_mode()
        elif mode == "lateral":
            interfaces = _lateral_mode()

        if interfaces is None:
            return interfaces

        # Apply filter/sort/cap and re-enumerate slab_index
        interfaces = internals._apply_filter(interfaces, filter)

        dn_ads_by_slab: dict[int, dict[str, dict[str, int]]] = {}
        for interface in interfaces:
            if str(interface.slab_termination or "").upper() != "DN":
                continue
            index = int(interface.slab_index or 0)
            dn_ads_by_slab[index] = {
                "surface1": internals._count_sites(
                    getattr(interface.surface1, "surface_sites", None)
                ),
                "surface2": internals._count_sites(
                    getattr(interface.surface2, "surface_sites", None)
                ),
                "interface": internals._count_sites(
                    getattr(interface, "interface_sites", None)
                ),
            }

        for interface in interfaces:
            if str(interface.slab_termination or "").upper() != "UP":
                continue
            index = int(interface.slab_index or 0)
            if index not in dn_ads_by_slab:
                continue
            if interface.interface_metadata is None:
                interface.interface_metadata = {}
            if isinstance(interface.interface_metadata, dict):
                interface.interface_metadata["paired_ads_counts"] = dn_ads_by_slab[
                    index
                ]

        # Apply freeze (selective dynamics)
        freeze = self.settings.get("freeze", -3)
        for interface in interfaces:
            try:
                interface.slab = utils.freeze_coords(
                    interface.slab,
                    freeze,
                )
            except Exception:
                _vprint("Warning: could not apply freeze settings")

        report_interfaces = [
            interface
            for interface in interfaces
            if str(interface.slab_termination or "UP").upper() in ("UP", "SY")
        ]

        bulk1_structure = internals._resolve_bulk(bulk1)
        bulk2_structure = internals._resolve_bulk(bulk2)

        def _build_join_report_lines(
            report_items: list[Interface],
            all_items: list[Interface],
            report_miller1: Any,
            report_miller2: Any,
        ) -> list[str]:
            report_HEADER = [
                utils.HEADER,
                "input:",
                "",
                f"  bulk1: {internals._format_formula(bulk1_structure)}",
                f"  bulk2: {internals._format_formula(bulk2_structure)}",
                f"  miller1: {report_miller1}",
                f"  miller2: {report_miller2}",
                f"  min bulk1 thickness: {bulk1_thickness}",
                f"  min bulk2 thickness: {bulk2_thickness}",
                f"  vacuum size: {vacuum}",
                f"  gap: {gap}",
                f"  mode: {mode}",
                f"  filter: {filter}",
                "",
                "summary:",
                "",
                f"  slabs: {len({int(item.slab_index or 0) for item in report_items})}",
                f"  terminations: {len(all_items)}",
                "",
            ]

            for report_item in report_items:
                report_HEADER.append("########################################")
                report_HEADER.append("")
                report_HEADER.append(str(report_item))
                report_HEADER.append("")

            return report_HEADER

        report_lines = _build_join_report_lines(
            report_interfaces,
            interfaces,
            miller1,
            miller2,
        )

        if output_mode == 1:
            _vprint("output-mode=1: printing summary report")
            print("\n".join(report_lines).rstrip())

        if output_mode == 2:
            _vprint("output-mode=2: writing POSCAR files and report")
            file_args = {
                "T1": int(bulk1_thickness),
                "T2": int(bulk2_thickness),
                "V": int(vacuum),
                "": mode,
            }

            interfaces_to_write = interfaces

            # When miller1 or miller2 is int (multi-direction mode),
            # group interfaces by their resolved (miller1, miller2)
            # tuple pair and write each group into a separate
            # subdirectory — mirroring how cleave handles int miller.
            multi_miller = isinstance(miller1, int) or isinstance(miller2, int)

            if multi_miller:
                miller_pair_groups: dict[tuple[tuple, tuple], list[Interface]] = (
                    defaultdict(list)
                )
                for interface in interfaces_to_write:
                    # Group by *surface* hkl (the slab miller indices
                    # that were input to join), not by the pq-derived
                    # inferred miller stored in interface.miller1/2.
                    surf_m1 = (
                        tuple(interface.surface1.miller)
                        if interface.surface1
                        and getattr(interface.surface1, "miller", None) is not None
                        else tuple(interface.miller1 or miller1)
                    )
                    surf_m2 = (
                        tuple(interface.surface2.miller)
                        if interface.surface2
                        and getattr(interface.surface2, "miller", None) is not None
                        else tuple(interface.miller2 or miller2)
                    )
                    pair_key = (surf_m1, surf_m2)
                    miller_pair_groups[pair_key].append(interface)
            else:
                miller_pair_groups = {
                    (tuple(miller1), tuple(miller2)): list(interfaces_to_write),
                }

            for (
                group_miller1,
                group_miller2,
            ), group_interfaces in miller_pair_groups.items():
                run_root = getattr(self, "_run_root", None)
                output_directory = internals._resolve_output_dir(
                    "join",
                    structure1=bulk1_structure,
                    miller1=group_miller1,
                    structure2=bulk2_structure,
                    miller2=group_miller2,
                    file_args=file_args,
                    run_root=run_root,
                )

                for interface in group_interfaces:
                    if mode == "lateral":
                        file_miller1 = interface.miller1 or group_miller1
                        file_miller2 = interface.miller2 or group_miller2
                    else:
                        file_miller1 = group_miller1
                        file_miller2 = group_miller2
                    output_prefix = internals._output_prefix(
                        structure1=bulk1_structure,
                        miller1=file_miller1,
                        structure2=bulk2_structure,
                        miller2=file_miller2,
                    )

                    file_props = {
                        "str": interface.interface_strain,
                        "dip": interface.interface_dipole,
                        "rho": interface.interface_density,
                    }
                    props_suffix = internals._suffix_tokens(
                        file_props, value_first=False
                    )
                    filename = (
                        "_".join(
                            [
                                output_prefix,
                                internals._object_id(
                                    interface, prefix="interface", zpad=3
                                ),
                                *props_suffix,
                            ]
                        )
                        + ".vasp"
                    )
                    filepath = os.path.join(output_directory, filename)
                    interface.write(
                        filename=filepath,
                        direct=self.settings.get("format", "cartesian") == "direct",
                        sort_structure=True,
                    )
                    _vprint(f"wrote {filepath}")

                pair_report_interfaces = [
                    interface
                    for interface in group_interfaces
                    if str(interface.slab_termination or "UP").upper() in ("UP", "SY")
                ]
                pair_report_lines = _build_join_report_lines(
                    pair_report_interfaces,
                    group_interfaces,
                    group_miller1,
                    group_miller2,
                )
                out_path = os.path.join(output_directory, "join.out")
                with open(out_path, "w", encoding="utf-8") as file_obj:
                    file_obj.write("\n".join(pair_report_lines).rstrip() + "\n")
                _vprint(f"wrote report {out_path}")

        _vprint("join finished")

        return interfaces

    @internals._recursive_sculptor_method
    def decorate(
        self,
        surface: Union[Surface, Interface, str],
        adparticle: Union[Structure, str],
        surface_sites: Union[
            tuple[float, float, float],
            str,
        ],
        adparticle_sites: list[Union[str, int]] | None = None,
        c_distance: float = 3.0,
        lat_distance: float = 8.0,
        coverage: float | None = None,
    ) -> Union[Surface, Interface]:
        """Decorate a surface with adparticles at selected adsorption sites."""
        verbose = bool(self.settings.get("verbose", 1))

        def _vprint(message: str) -> None:
            if verbose:
                print(f"[decorate] {message}")

        target_surface, decorated_count = internals._process_decorate(
            surface=surface,
            adparticle=adparticle,
            surface_sites=surface_sites,
            adparticle_sites=adparticle_sites,
            c_distance=c_distance,
            lat_distance=lat_distance,
            coverage=coverage,
            settings=self.settings,
        )

        short = internals._check_contacts(target_surface.slab)
        if short:
            _vprint(
                f"Warning: {len(short)} short contact(s) detected (distance < 0.8 A):"
            )
            for i, j, d in short:
                si = target_surface.slab[i].species_string
                sj = target_surface.slab[j].species_string
                _vprint(f"  {si}(#{i}) -- {sj}(#{j}): {d:.3f} A")

        # Apply freeze (selective dynamics)
        freeze = self.settings.get("freeze", -3)
        try:
            target_surface.slab = utils.freeze_coords(
                target_surface.slab,
                freeze,
            )
        except Exception:
            _vprint("Warning: could not apply freeze settings")

        output_mode: int
        try:
            output_mode = int(
                self.settings.get("output-mode", self.settings.get("output_mode", 1))
            )
        except (TypeError, ValueError):
            output_mode = 1

        report_lines = [
            utils.HEADER,
            "input:",
            "",
            f"  surface: {internals._component_label(target_surface.slab, target_surface.miller)}",
            f"  adparticle: {internals._adparticle_label(target_surface.adparticle)}",
            f"  site selector: {surface_sites}",
            f"  c_distance: {float(c_distance):.4f}",
            f"  lat_distance: {float(lat_distance):.4f}",
            f"  coverage: {coverage}",
            "",
            "summary:",
            "",
            f"  decorated instances: {decorated_count}",
            "",
            "########################################",
            "",
            str(target_surface),
            "",
        ]

        if output_mode == 1:
            _vprint("output-mode=1: printing summary report")
            print("\n".join(report_lines).rstrip())

        if output_mode == 2:
            _vprint("output-mode=2: writing POSCAR files and report")
            base_structure = (
                target_surface.bulk.structure
                if target_surface.bulk is not None
                else target_surface.slab
            )
            file_args = {
                "cd": c_distance,
                "ld": lat_distance,
                "cov": coverage,
            }
            output_prefix = internals._output_prefix(
                structure1=base_structure,
                miller1=target_surface.miller,
                adparticle=target_surface.adparticle,
            )
            run_root = getattr(self, "_run_root", None)
            base_dir = internals._resolve_output_dir(
                "decorate",
                structure1=base_structure,
                miller1=target_surface.miller,
                adparticle=target_surface.adparticle,
                file_args=file_args,
                run_root=run_root,
            )

            file_props = {
                "d": target_surface.surface_dipole,
            }
            props_suffix = internals._suffix_tokens(file_props, value_first=False)
            out_filename = (
                "_".join(
                    [
                        output_prefix,
                        internals._object_id(target_surface, prefix="surface", zpad=2),
                        *props_suffix,
                    ]
                )
                + ".vasp"
            )
            out_path = os.path.join(base_dir, out_filename)
            target_surface.write(
                filename=out_path,
                direct=self.settings.get("format", "cartesian") == "direct",
                sort_structure=True,
            )
            report_path = os.path.join(base_dir, "decorate.out")
            with open(report_path, "w", encoding="utf-8") as file_obj:
                file_obj.write("\n".join(report_lines).rstrip() + "\n")
            _vprint(f"wrote {out_path}")
            _vprint(f"wrote report {report_path}")

        _vprint("decorate finished")

        return target_surface

    def restack(
        self,
        surface: Union[Surface, Interface, str],
        target_layers: list[int],
        stacking_layers: list[int] | None = None,
    ) -> Union[Surface, Interface]:
        """Restack layers in a Surface or Interface.
        
        Used for reconstructing surface/contact terminations and modelling
        planar defects (e.g. stacking fault, twin boundary, etc).

        Parameters
        ----------
        surface : Surface | Interface | str
            Target object (or POSCAR path) to restack.
        target_layers : list[int]
            Contiguous range of 0-based layer indices to replace.
            Negative indices allowed (e.g., ``-1`` for the top layer).
        stacking_layers : list[int] | None
            Layer indices whose atoms replace *target_layers*.
            ``None`` or ``[]`` removes the target range entirely.

        Returns
        -------
        Surface | Interface
            The modified object with refreshed metadata.
        """
        verbose = bool(self.settings.get("verbose", 1))

        def _vprint(message: str) -> None:
            if verbose:
                print(f"[restack] {message}")

        if stacking_layers is None:
            stacking_layers = []

        # --- resolve input ---------------------------------------
        if isinstance(surface, str):
            surface = Surface.read(surface)

        if not isinstance(surface, (Surface, Interface)):
            raise TypeError("surface must be a Surface, Interface, or POSCAR path")

        if surface.slab is None:
            raise ValueError("surface has no associated slab")

        # --- determine axis --------------------------------------
        is_interface = isinstance(surface, Interface)
        if is_interface:
            axis_key = str(
                getattr(surface, "interface_axis", "c"),
            ).lower()
        else:
            axis_key = "c"

        layer_map = internals._axis_layers(surface.slab, axis=axis_key)
        n_layers = len(layer_map)
        _vprint(
            f"start target_layers={target_layers} "
            f"stacking_layers={stacking_layers} "
            f"axis={axis_key} layers={n_layers}"
        )

        # --- call core restacking --------------------------------
        new_slab = internals._restack_layers(
            surface.slab,
            target_layers=target_layers,
            stacking_layers=stacking_layers,
            axis=axis_key,
        )

        surface.slab = new_slab

        # --- refresh metadata ------------------------------------
        if is_interface:
            # Partition restacked slab by mask → sync sub-surfaces
            mask_vals = new_slab.site_properties.get("mask", [])
            if surface.surface1 is not None:
                s1_idx = [i for i, m in enumerate(mask_vals) if m == "surface1"]
                if s1_idx:
                    s1_slab = Structure.from_sites(
                        [new_slab[i] for i in s1_idx],
                    )
                    surface.surface1.slab = s1_slab
                    surface.surface1._refresh_metadata()

            if surface.surface2 is not None:
                s2_idx = [i for i, m in enumerate(mask_vals) if m == "surface2"]
                if s2_idx:
                    s2_slab = Structure.from_sites(
                        [new_slab[i] for i in s2_idx],
                    )
                    surface.surface2.slab = s2_slab
                    surface.surface2._refresh_metadata()

            surface._refresh_metadata()
        else:
            surface._refresh_metadata()

        _vprint(
            f"restacked: {len(new_slab)} atoms, "
            f"{len(internals._axis_layers(new_slab, axis=axis_key))} layers"
        )

        short = internals._check_contacts(surface.slab)
        if short:
            _vprint(
                f"Warning: {len(short)} short contact(s) detected (distance < 0.8 A):"
            )
            for i, j, d in short:
                si = surface.slab[i].species_string
                sj = surface.slab[j].species_string
                _vprint(f"  {si}(#{i}) -- {sj}(#{j}): {d:.3f} A")

        # --- freeze (selective dynamics) -------------------------
        freeze = self.settings.get("freeze", -3)
        try:
            surface.slab = utils.freeze_coords(surface.slab, freeze)
        except Exception:
            _vprint("Warning: could not apply freeze settings")

        # --- output handling -------------------------------------
        output_mode: int
        try:
            output_mode = int(
                self.settings.get(
                    "output-mode",
                    self.settings.get("output_mode", 1),
                )
            )
        except (TypeError, ValueError):
            output_mode = 1

        report_lines = [
            utils.HEADER,
            "input:",
            "",
            f"  target_layers: {target_layers}",
            f"  stacking_layers: {stacking_layers}",
            f"  axis: {axis_key}",
            "",
            "summary:",
            "",
            f"  atoms: {len(new_slab)}",
            f"  layers: {len(internals._axis_layers(new_slab, axis=axis_key))}",
            "",
        ]

        if output_mode >= 1:
            _vprint("output-mode >= 1: printing report")
            for line in report_lines:
                print(line)

        if output_mode >= 2:
            _vprint("output-mode >= 2: writing files")
            miller_ref = getattr(surface, "miller", None)
            if miller_ref is None and is_interface:
                miller_ref = getattr(surface, "miller1", None)

            base_structure = getattr(surface, "bulk", None)
            if base_structure is None:
                base_structure = surface.slab

            run_root = getattr(self, "_run_root", None)
            base_dir = internals._resolve_output_dir(
                "restack",
                structure1=base_structure,
                miller1=miller_ref,
                file_args=None,
                run_root=run_root,
            )

            prefix = "interface" if is_interface else "surface"
            out_filename = (
                internals._object_id(surface, prefix=prefix, zpad=2) + ".vasp"
            )
            out_path = os.path.join(base_dir, out_filename)
            surface.write(
                filename=out_path,
                direct=(self.settings.get("format", "cartesian") == "direct"),
                sort_structure=True,
            )
            report_path = os.path.join(base_dir, "restack.out")
            with open(report_path, "w", encoding="utf-8") as fobj:
                fobj.write("\n".join(report_lines).rstrip() + "\n")
            _vprint(f"wrote {out_path}")
            _vprint(f"wrote report {report_path}")

        _vprint("restack finished")

        return surface

    def recollect(
        self,
        slab: Union[Structure, str],
        miller: tuple | None = None,
        bulk: Union[Structure, str, None] = None,
        stoichiometric: bool | None = None,
        scaling: tuple = (1, 1, 1),
        # ── optional overrides (None → auto-infer) ────────
        symmetric: bool | None = None,
        thickness: float | None = None,
        vacuum: float | None = None,
        slab_index: int | None = None,
        slab_termination: str | None = None,
        bulk_energy: float | None = None,
        properties_metadata: dict | None = None,
        adparticle: Union[Structure, str, None] = None,
        # ── Interface-specific (triggers Interface path) ──
        mode: str | None = None,
        miller1: tuple | None = None,
        miller2: tuple | None = None,
        gap: float | None = None,
        bulk1: Union[Structure, str, None] = None,
        bulk2: Union[Structure, str, None] = None,
        stoichiometric1: bool | None = None,
        stoichiometric2: bool | None = None,
        scaling1: tuple | None = None,
        scaling2: tuple | None = None,
        interface_strain: float | None = None,
        interface_metadata: dict | None = None,
    ) -> Union[Surface, "Interface"]:
        """Reconstruct a :class:`Surface` or :class:`Interface` from
        a raw structure and metadata.

        This is the "side-door" counterpart to :meth:`cleave` /
        :meth:`join`: it builds fully-populated Surface or Interface
        objects from an existing slab geometry (Structure or POSCAR
        path) plus user-supplied metadata, without running the
        SlabGenerator or interface-matching pipelines.

        Use-cases
        ---------
        * Importing slabs from external tools or databases.
        * Bootstrapping objects for analysis when the original
          cleave/join history is unavailable.

        Surface path (default)
        ~~~~~~~~~~~~~~~~~~~~~~
        Triggered when ``mode`` is ``None``.

        **Required**: ``miller``.

        Interface path
        ~~~~~~~~~~~~~~
        Triggered when ``mode`` is ``'epitaxial'`` or ``'lateral'``.

        **Required**: ``miller1``, ``miller2``.
        The ``slab`` must carry a ``'mask'`` site property whose values
        are ``'surface1'`` and ``'surface2'`` to identify each half.

        Parameters
        ----------
        slab : Structure | str
            Slab geometry — pymatgen Structure or POSCAR path.
        miller : tuple | None
            Miller index for the Surface path. **Required** when
            ``mode`` is ``None``.
        bulk : Structure | str | None
            Bulk structure. For Interface, used as fallback for
            ``bulk1`` / ``bulk2`` if those are not provided.
        stoichiometric : bool | None
            Override for both halves (Interface) or the surface
            (Surface). Defaults to per-surface auto-detection.
        scaling : tuple
            Default scaling ``(a, b, c)``. For Interface, used as
            fallback for ``scaling1`` / ``scaling2``.

        symmetric, thickness, vacuum : auto-inferred from geometry.
        slab_index, slab_termination : optional cleave metadata.
        bulk_energy : float | None, Surface only.
        properties_metadata : dict | None, pre-computed properties dict.
        adparticle : optional adsorbate structure or POSCAR path.

        mode : str | None
            ``'epitaxial'`` or ``'lateral'``. Triggers Interface path.
        miller1, miller2 : tuple | None
            Miller indices for each interface half. **Required** when
            ``mode`` is set.
        gap : float | None
            Interface gap. Auto-inferred from mask projections when
            ``None``.
        bulk1, bulk2 : Structure | str | None
            Per-half bulk structures. Fallback to ``bulk``.
        stoichiometric1, stoichiometric2 : bool | None
            Per-half stoichiometric overrides. Fallback to
            ``stoichiometric``.
        scaling1, scaling2 : tuple | None
            Per-half scaling. Fallback to ``scaling``.
        interface_strain : float | None
            Scalar strain override.
        interface_metadata : dict | None
            Extra metadata dict attached to the Interface.

        Returns
        -------
        Surface | Interface
        """
        tag = "[recollect]"
        verbose = bool(self.settings.get("verbose", 1))

        def _vprint(msg: str) -> None:
            if verbose:
                print(f"{tag} {msg}")

        def _output(
            obj: Union[Surface, "Interface"],
            structure1: Structure,
            miller1: tuple,
            structure2: Structure | None = None,
            miller2: tuple | None = None,
        ) -> None:
            """Handle output-mode printing and file writing."""
            output_mode: int
            try:
                output_mode = int(
                    self.settings.get(
                        "output-mode",
                        self.settings.get("output_mode", 1),
                    )
                )
            except (TypeError, ValueError):
                output_mode = 1

            if output_mode >= 1:
                print(str(obj))

            if output_mode == 2:
                is_interface = isinstance(obj, Interface)
                prefix = "interface" if is_interface else "surface"
                run_root = getattr(self, "_run_root", None)
                out_root = internals._resolve_output_dir(
                    "recollect",
                    structure1=structure1,
                    miller1=miller1,
                    structure2=structure2,
                    miller2=miller2,
                    run_root=run_root,
                )
                output_prefix = internals._output_prefix(
                    structure1=structure1,
                    miller1=miller1,
                    structure2=structure2,
                    miller2=miller2,
                )

                dipole_attr = "interface_dipole" if is_interface else "surface_dipole"
                file_props = {
                    "d": abs(
                        getattr(obj, dipole_attr, 0.0) or 0.0,
                    ),
                }
                props_suffix = internals._suffix_tokens(
                    file_props,
                    value_first=False,
                )
                file_name = (
                    "_".join(
                        [
                            output_prefix,
                            internals._object_id(obj, prefix=prefix, zpad=2),
                            *props_suffix,
                        ]
                    )
                    + ".vasp"
                )
                file_path = os.path.join(out_root, file_name)
                obj.write(
                    filename=file_path,
                    direct=(self.settings.get("format", "cartesian") == "direct"),
                    sort_structure=True,
                )
                _vprint(f"wrote {file_path}")

        def _surface_path(slab_resolved: Structure) -> Surface:
            """Surface recollect orchestrator."""
            nonlocal miller
            if miller is None:
                raise ValueError("miller is required for Surface recollect")
            miller = internals._normalize_miller(miller)
            _vprint(
                f"{slab_resolved.composition.reduced_formula}"
                f" {miller} ({len(slab_resolved)} sites)"
            )

            bulk_structure = internals._resolve_bulk(bulk) if bulk is not None else None
            if bulk_structure is not None:
                _vprint(f"bulk: {bulk_structure.composition.reduced_formula}")

            surface = internals._recollect(
                slab_resolved,
                miller,
                bulk=bulk_structure,
                stoichiometric=stoichiometric,
                scaling=scaling,
                symmetric=symmetric,
                thickness=thickness,
                vacuum=vacuum,
                slab_index=slab_index,
                slab_termination=slab_termination,
                bulk_energy=bulk_energy,
                properties_metadata=properties_metadata,
                adparticle=adparticle,
            )

            # post-init enrichment
            try:
                surface.surface_sites = internals._map_surface_sites(surface)
            except Exception:
                surface.surface_sites = {}

            if surface.bulk is not None:
                try:
                    surface.surface_directions = internals._map_surface_directions(
                        surface
                    )
                except Exception:
                    _vprint("could not map surface directions")

            _output(surface, surface.slab, miller)
            _vprint("recollect finished")
            return surface

        def _interface_path(
            slab_resolved: Structure,
        ) -> "Interface":
            """Interface recollect orchestrator."""
            nonlocal miller1, miller2, gap
            mode_lower = str(mode).lower()
            if mode_lower not in ("epitaxial", "lateral"):
                raise ValueError(f"mode must be 'epitaxial' or 'lateral', got '{mode}'")
            if miller1 is None or miller2 is None:
                raise ValueError(
                    "miller1 and miller2 are required for Interface recollect"
                )
            miller1 = internals._normalize_miller(miller1)
            miller2 = internals._normalize_miller(miller2)

            _vprint(
                f"{slab_resolved.composition.reduced_formula}"
                f" {miller1}/{miller2} mode={mode_lower}"
                f" ({len(slab_resolved)} sites)"
            )

            # ── validate / extract mask ──────────────────────
            slab_snapshot = internals._struct_snapshot(
                slab_resolved,
            )
            mask_vals = slab_snapshot.site_properties.get(
                "mask",
                [],
            )
            mask_set = set(mask_vals)
            if mask_set != {"surface1", "surface2"}:
                raise ValueError(
                    "slab must carry a 'mask' site property "
                    "with 'surface1' and 'surface2' values; "
                    f"got {mask_set or 'no mask'}"
                )

            s1_idx = [i for i, m in enumerate(mask_vals) if m == "surface1"]
            s2_idx = [i for i, m in enumerate(mask_vals) if m == "surface2"]

            # ── auto-infer gap from mask projections ─────────
            axis_index = 1 if mode_lower == "lateral" else 2
            axis_vector = np.array(
                slab_snapshot.lattice.matrix[axis_index],
                dtype=float,
            )
            axis_hat = internals._unit_vec(axis_vector)
            projections = np.dot(
                slab_snapshot.cart_coords.astype(float),
                axis_hat,
            )
            projs_s1 = projections[s1_idx]
            projs_s2 = projections[s2_idx]

            if gap is None:
                gap = float(
                    np.min(projs_s2) - np.max(projs_s1),
                )
                if gap < 0.0:
                    gap = float(
                        np.min(projs_s1) - np.max(projs_s2),
                    )
                gap = max(gap, 0.0)
                _vprint(f"auto-inferred gap={gap:.4f} A")

            # ── extract sub-structures ───────────────────────
            s1_sub = Structure.from_sites(
                [slab_snapshot[i] for i in s1_idx],
            )
            s2_sub = Structure.from_sites(
                [slab_snapshot[i] for i in s2_idx],
            )

            # ── per-half params (fallback to shared) ─────────
            _bulk1 = bulk1 or bulk
            _bulk2 = bulk2 or bulk
            bulk1_struct = (
                internals._resolve_bulk(_bulk1) if _bulk1 is not None else None
            )
            bulk2_struct = (
                internals._resolve_bulk(_bulk2) if _bulk2 is not None else None
            )
            _stoich1 = (
                stoichiometric1 if stoichiometric1 is not None else stoichiometric
            )
            _stoich2 = (
                stoichiometric2 if stoichiometric2 is not None else stoichiometric
            )
            _scaling1 = scaling1 or scaling
            _scaling2 = scaling2 or scaling

            # ── build each Surface via shared helper ─────────
            surface1 = internals._recollect(
                s1_sub,
                miller1,
                bulk=bulk1_struct,
                stoichiometric=_stoich1,
                scaling=_scaling1,
                symmetric=symmetric,
                slab_index=slab_index,
                slab_termination=slab_termination,
            )
            _vprint(
                f"surface1: "
                f"{s1_sub.composition.reduced_formula}"
                f" {miller1}"
                f" thick={surface1.thickness:.2f}"
            )

            surface2 = internals._recollect(
                s2_sub,
                miller2,
                bulk=bulk2_struct,
                stoichiometric=_stoich2,
                scaling=_scaling2,
                symmetric=symmetric,
                slab_index=slab_index,
                slab_termination=slab_termination,
            )
            _vprint(
                f"surface2: "
                f"{s2_sub.composition.reduced_formula}"
                f" {miller2}"
                f" thick={surface2.thickness:.2f}"
            )

            # ── derive combined flags ────────────────────────
            _combined_stoich = (
                bool(surface1.stoichiometric and surface2.stoichiometric)
                if (
                    surface1.stoichiometric is not None
                    and surface2.stoichiometric is not None
                )
                else None
            )
            _combined_sym = (
                bool(surface1.symmetric and surface2.symmetric)
                if (surface1.symmetric is not None and surface2.symmetric is not None)
                else None
            )

            # ── construct Interface ──────────────────────────
            interface_axis = "b" if mode_lower == "lateral" else "c"
            interface = Interface(
                slab_snapshot,
                surface1=surface1,
                surface2=surface2,
                miller1=miller1,
                miller2=miller2,
                mode=mode_lower,
                stoichiometric=_combined_stoich,
                symmetric=_combined_sym,
                interface_axis=interface_axis,
                gap=float(gap),
                thickness=thickness,
                vacuum=vacuum,
                slab_index=slab_index,
                slab_termination=slab_termination,
                interface_strain=interface_strain,
                interface_metadata=interface_metadata,
                adparticle=adparticle,
                scaling=(1, 1, 1),
            )

            _output(
                interface,
                slab_snapshot,
                miller1,
                structure2=surface2.slab,
                miller2=miller2,
            )
            _vprint("recollect finished")
            return interface

        # ── resolve composite slab ───────────────────────────
        slab_resolved = internals._resolve_bulk(slab)
        if isinstance(slab, str):
            _vprint(f"read slab from {slab}")

        # ── dispatch ─────────────────────────────────────────
        if mode is not None:
            return _interface_path(slab_resolved)
        return _surface_path(slab_resolved)


# TODO: Clean up tests to stop outputting results to the codebase root, e.g. `cleave_ZrO2(111)_10T_15V_stoichiometric` and `cleave_ZrO2(111)_10T_15V_stoichiometric`
# TODO: Review consistency of typing, e.g. single/double quotes, camelcase/snake_case, etc. All methods with consitent docstrings, etc
# TODO: Improve verbose, warning, and error statements (also make them shorter for better visualization on the terminal). Also add colorama and yaspin. Improve `Sculptor.join` SKIP  verbose statements
# TODO: Add release notes comparing release package with legacy codes
# TODO: Fix all "pre-existin failures" tests so they work as expected with the current status of the slabfy implementation

# TODO: Change pipeline to minimize abs(dipole) instead of dipole, i.e. negative dipoles first. Considering renumbering slab indexes?
# TODO: Fix filter to relabel slabs numbers (e.g. 1,2,3...)? 
# TODO: Change --output-mode to work with all public methods?
# TODO: Add filter to Sculptor methdods, e.g. dipol==0, symmetric==true, etc
