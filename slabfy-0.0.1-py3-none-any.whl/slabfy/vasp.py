"""
VASP-specific parsing and setup utilities for slabfy.

This module contains VASP-specific tools for setting up and parsing
atomistic-level simulations. It includes:

- :class:`VaspReport` — dataclass container for parsed VASP results.

- :class:`VaspTools` — high-level methods for setting up and reading
  VASP calculations.

"""

import os
import pickle
import base64
import re
import warnings
from dataclasses import dataclass, field

import numpy as np

from slabfy.core import Bulk, Adparticle, Surface, Interface
from slabfy.internals import _vasp as internals
from slabfy.internals._utils import _read_slabfy_file, _render_job_script
from slabfy import utils

from typing import Any, Union, Literal

from pymatgen.core.structure import Structure
from pymatgen.io.vasp.inputs import Kpoints, Poscar
from pymatgen.symmetry.bandstructure import HighSymmKpath
from pymatgen.io.vasp.sets import VaspInputSet
from pymatgen.electronic_structure.dos import Dos, CompleteDos
from pymatgen.electronic_structure.bandstructure import (
    BandStructureSymmLine,
)

__all__ = ["VaspReport", "VaspTools"]

"""
╔╦╗┌─┐┌┬┐┌─┐  ┌─┐┬  ┌─┐┌─┐┌─┐┌─┐┌─┐
 ║║├─┤ │ ├─┤  │  │  ├─┤└─┐└─┐├┤ └─┐
═╩╝┴ ┴ ┴ ┴ ┴  └─┘┴─┘┴ ┴└─┘└─┘└─┘└─┘
"""


# ── VaspReport dataclass ─────────────────────────────────────
@dataclass
class VaspReport:
    """Container for parsed VASP calculation results.

    Stores all extracted data using pymatgen canonical objects
    where available.  Volumetric data (CHGCAR, ELFCAR) is
    **not** loaded automatically; use
    :func:`load_volumetric` to access them on demand.

    Attributes
    ----------
    directory : str
        Absolute path to the calculation directory.
    available_files : dict[str, str]
        Mapping ``{key: abs_path}`` for every detected
        VASP output file.

    Structure
    ~~~~~~~~~
    structure : Structure | None
        Final (relaxed) geometry.
    initial_structure : Structure | None
        Starting geometry.
    trajectory : list[Structure] | None
        Full ionic-step trajectory.

    Energetics
    ~~~~~~~~~~
    energy : list[dict[str, float]] | None
        Per-ionic-step energies; ``[0]`` is the initial unrelaxed
        SCF and ``[-1]`` the final relaxed step.  Each dict carries
        ``{toten, sigma0, wo_entropy}`` keys (eV).
    energy_contribs : dict[str, float] | None
        Energy decomposition (PSCENC, TEWEN, …).

    Forces & stress
    ~~~~~~~~~~~~~~~
    forces : np.ndarray | None
        Final forces on each ion (N × 3, eV/Å).
    stress : np.ndarray | None
        Final stress tensor (3 × 3, kBar).

    Convergence
    ~~~~~~~~~~~
    converged : bool | None
        ``True`` only when *both* electronic **and**
        ionic loops satisfy tolerance.
    converged_electronic : bool | None
    converged_ionic : bool | None
    electronic_convergence : dict | None
        Per-SCF-step energies and residuals.

    Magnetism & charge
    ~~~~~~~~~~~~~~~~~~
    magnetization : list[dict] | None
        Per-ion magnetization (from OUTCAR).
    charges : list[dict] | None
        Per-ion charges (from OUTCAR / py4vasp).
    total_mag : float | None
        Net spin magnetic moment.

    Electronic structure
    ~~~~~~~~~~~~~~~~~~~~
    dos : CompleteDos | None
        Full site- and orbital-projected DOS
        (pymatgen ``CompleteDos``).
    tdos : Dos | None
        Total DOS (no projections), useful when
        only HDF5 is available.
    band_structure : BandStructureSymmLine | None
        Band structure along high-symmetry lines.
    bandgap : dict | None
        ``{fundamental, direct, kpoint_VBM, kpoint_CBM,
        fermi_energy, …}``
    eigenvalues : dict | None
        Raw eigenvalues per ``Spin`` channel.
    fermi_energy : float | None
        Fermi level (eV).

    Potential & workfunction
    ~~~~~~~~~~~~~~~~~~~~~~~~
    electrostatic_potential : list[float] | None
        On-site electrostatic potential per ion.
    workfunction : dict | None
        ``{distance, average_potential, vacuum_potential,
        fermi_energy}``

    Dielectric & optical
    ~~~~~~~~~~~~~~~~~~~~
    dielectric_function : dict | None
        Frequency-dependent ε(ω) (real + imag parts).
    dielectric_tensor : dict | None
        ε_static, ε_ionic tensors.
    optical_absorption : list | None
        Absorption coefficient α(ω).

    Vibration / phonon
    ~~~~~~~~~~~~~~~~~~
    normal_modes : dict | None
        ``{frequencies, eigenvectors}``
    force_constants : np.ndarray | None
        Interatomic force-constant matrix.
    born_effective_charges : np.ndarray | None
        Born Z* tensors per ion.

    Metadata
    ~~~~~~~~
    incar : dict | None
        INCAR parameters used.
    kpoints : Any
        K-mesh description.
    potcar_spec : list | None
        POTCAR symbols / hashes.
    calc_type : str | None
        Auto-detected: ``relaxation``, ``static``,
        ``vibration``, or ``optical``.
    run_stats : dict | None
        Walltime, CPU time, memory, cores.
    """

    directory: str
    available_files: dict[str, str] = field(
        default_factory=dict,
    )

    # ── structure ────────────────────────────────────────
    structure: Structure | None = None
    initial_structure: Structure | None = None
    trajectory: list[Structure] | None = None

    # ── energetics ───────────────────────────────────────
    energy: list[dict[str, float]] | None = None
    energy_contribs: dict[str, float] | None = None

    # ── forces & stress ──────────────────────────────────
    forces: np.ndarray | None = None
    stress: np.ndarray | None = None

    # ── convergence ──────────────────────────────────────
    converged: bool | None = None
    converged_electronic: bool | None = None
    converged_ionic: bool | None = None
    electronic_convergence: dict | None = None

    # ── magnetism & charge ───────────────────────────────
    magnetization: list | None = None
    charges: list | None = None
    total_mag: float | None = None

    # ── electronic structure ─────────────────────────────
    dos: CompleteDos | None = None
    tdos: Dos | None = None
    band_structure: BandStructureSymmLine | None = None
    bandgap: dict | None = None
    eigenvalues: dict | None = None
    fermi_energy: float | None = None

    # ── potential & workfunction ─────────────────────────
    electrostatic_potential: list | None = None
    workfunction: dict | None = None

    # ── dielectric & optical ─────────────────────────────
    dielectric_function: dict | None = None
    dielectric_tensor: dict | None = None
    optical_absorption: list | None = None

    # ── vibration / phonon ───────────────────────────────
    normal_modes: dict | None = None
    force_constants: np.ndarray | None = None
    born_effective_charges: np.ndarray | None = None

    # ── Wannier90 (MLWF post-processing) ────────────────
    wannier_data: dict | None = None
    """Pre-parsed Wannier90 output data.

    Expected schema::

        {
            "centres": list[list[float]],        # (N_wf, 3) Å
            "spreads": list[float],               # (N_wf,) Å²
            "hr": {                                # real-space Hamiltonian
                "n_wann": int,
                "n_rpts": int,
                "degeneracy": list[int],          # (n_rpts,)
                "rvec": list[list[int]],          # (n_rpts, 3)
                "hr_real": list[float],           # flat (n_rpts*n_wann*n_wann,)
                "hr_imag": list[float],           # flat (n_rpts*n_wann*n_wann,)
            },
            "bands": {                             # interpolated bands
                "kpoints": list[list[float]],     # (N_kpt, 3)
                "distances": list[float],          # (N_kpt,)
                "energies": list[list[float]],     # (N_kpt, N_band)
            },
        }
    """

    # ── NMR / NICS ───────────────────────────────────────
    nmr_data: dict | None = None
    """Pre-parsed NMR calculation output (VASP 6.6+).

    Expected schema::

        {
            "chemical_shielding": [           # Per-ion shielding data
                {
                    "element": str,           # Element symbol
                    "index": int,             # Ion index (0-based)
                    "tensor": [[float]*3]*3,  # 3x3 shielding tensor (ppm)
                    "isotropic": float,       # Isotropic shielding (ppm)
                    "anisotropy": float,      # Shielding anisotropy
                    "asymmetry": float,       # Asymmetry parameter η
                },
                ...
            ],
            "nics": {                         # POSNICS grid results (if LPOSNICS=True)
                "positions": [[float]*3],     # Fractional coordinates of probe points
                "values": [float],            # NICS values at each point (ppm)
            },
            "efg": [                          # Electric field gradients (if quadrupolar nuclei)
                {
                    "element": str,
                    "index": int,
                    "tensor": [[float]*3]*3,  # EFG tensor (V/Å²)
                    "cq": float,              # Quadrupole coupling constant (MHz)
                    "eta": float,             # Asymmetry parameter
                },
                ...
            ],
            "current_density": str | None,    # Path to NMR current density file
        }

    Reference: https://vasp.at/tutorials/latest/nmr/part3/
    """

    # ── metadata ─────────────────────────────────────────
    incar: dict | None = None
    kpoints: Any = None
    potcar_spec: list | None = None
    calc_type: str | None = None
    run_stats: dict | None = None


class VaspTools:
    """High-level VASP setup and parsing interface.

    Methods are divided in two categories:

    1. **I/O**: setting up VASP input files and parsing raw outputs
       into structured data.
    2. **Vasp-specific runs**: pre-configured settings for common
       VASP calculations.

    All properties produced here relate exclusively to the single
    system (Surface/Interface) at hand.  Even methods that
    coordinate multiple VASP runs (e.g. phonons at displaced
    geometries, QHA at different volumes) still describe that
    one system state, and their results are stored as
    ``properties_metadata`` attributes on the object.

    Cross-system workflows that compare *different* structures
    or sub-systems (e.g. Charge density difference, CNEB,
    convergence across slab thicknesses) belong in
    :class:`~slabfy.analysis.AnalysisTree` instead.
    """

    def __init__(self):
        pass

    def _setup_run(
        self,
        slabfy_obj: Union[Surface, Interface, Structure, str],
        dir_path: str | None = None,
        incar_settings: dict | None = None,
        kpoints_settings: dict | None = None,
        potcar_settings: dict | None = None,
        vasp_modifiers: Union[str, dict, None] = None,
        sbatch_config: Union[str, dict, None] = None,
        **kwargs,
    ) -> dict[str, Any]:
        """Build VASP input set for a given structure.

        Assembles POSCAR, INCAR, KPOINTS, POTCAR, and (optionally)
        a job-scheduler script.  Higher-level methods
        (``surf_relax``, ``surf_static``, …) delegate here with
        pre-merged overrides from VaspSets presets.

        Parameters
        ----------
        slabfy_obj : Surface | Interface | Structure | str
            Input geometry — slabfy object, pymatgen Structure,
            or POSCAR file path.
        dir_path : str | None
            Write VASP files to this directory.  ``None`` →
            return objects only, no files written.
        incar_settings : dict | None
            INCAR tag overrides (keys are case-insensitive,
            uppercased internally).
        kpoints_settings : dict | None
            Keys (case-insensitive): ``STYLE``
            (``"Monkhorst"`` | ``"Gamma"``), ``KPTS``
            ``[kx, ky, kz]``, ``KPOINTS_OPT`` (``0`` | ``1``).
        potcar_settings : dict | None
            Per-element POTCAR overrides, e.g. ``{"Gd": "Gd_3"}``.
        vasp_modifiers : str | dict | None
            PAW functional — ``str`` (name in slabfy.json),
            ``dict`` (``{name: path}``), or ``None`` (use
            ``DEFAULT_FUNCTIONAL``).
        sbatch_config : str | dict | None
            Scheduler config — ``str`` (preset name in
            slabfy.json ``SBATCH``), ``dict`` (merged on top of
            defaults), or ``None`` (skip job script).
        **kwargs
            Forwarded from ``Sculptor``.  Recognized key:
            ``settings`` (dict with ``"verbose"`` flag).

        Returns
        -------
        dict[str, Any]
            Keys: ``poscar``, ``incar``, ``kpoints``,
            ``kpoints_opt``, ``potcar``, ``sbatch``.
            Missing outputs are ``None``.
        """
        tag = "[VaspTools._setup_run]"
        _cfg = kwargs.get("settings", {})
        verbose = bool(_cfg.get("verbose", True)) if isinstance(_cfg, dict) else True

        # ── resolve structure ────────────────────────────────
        if isinstance(slabfy_obj, str):
            slabfy_obj = _read_slabfy_file(slabfy_obj)
            if verbose:
                print(f"{tag} Read structure from file")

        if isinstance(slabfy_obj, (Surface, Interface)):
            structure = slabfy_obj.slab

        else:
            structure = slabfy_obj

        if verbose:
            print(
                f"{tag} {structure.composition.reduced_formula}"
                f" ({len(structure)} sites)"
            )

        # ── config_dict from VASP_MODIFIERS ───────────────────
        vasp_section = utils.SFY_SETTINGS.get("VASP", {})
        default_vasp_modifiers = vasp_section.get("VASP_MODIFIERS", {})

        # User vasp_modifiers overrides
        if vasp_modifiers:
            vasp_modifiers = {k.upper(): v for k, v in vasp_modifiers.items()}
            vasp_modifiers = default_vasp_modifiers | vasp_modifiers
        else:
            vasp_modifiers = default_vasp_modifiers

        default_base_set = vasp_modifiers.get("BASE_SET", "")
        config_dict: dict[str, Any] = {
            "INCAR": dict(default_base_set.get("INCAR", {})),
            "KPOINTS": dict(default_base_set.get("KPOINTS", {})),
            "POTCAR": dict(default_base_set.get("POTCAR", {})),
        }

        # ── INCAR ─────────────────────────────────────────────

        # Apply vasp_modifiers functional
        functional = vasp_modifiers.get("FUNCTIONAL", "")
        config_dict["INCAR"].update(
            vasp_section.get("FUNCTIONALS", {}).get(functional, {})
        )
        if verbose:
            print(f"{tag} Applied default functional: {functional}")

        # Apply vasp_modifiers corrections
        corrections = vasp_modifiers.get("CORRECTIONS", [])
        for correction in corrections:
            config_dict["INCAR"].update(
                vasp_section.get("CORRECTIONS", {}).get(correction, {})
            )
            if verbose:
                print(f"{tag} Applied correction: {correction}")

        # User INCAR settings overrides (normalize keys to uppercase)
        if incar_settings:
            config_dict["INCAR"].update(
                {k.upper(): v for k, v in incar_settings.items()}
            )
            if verbose:
                print(f"{tag} INCAR overrides: {list(incar_settings.keys())}")

        if incar_settings == {}:
            raise ValueError("INCAR settings cannot be empty")

        # ── KPOINTS ──────────────────────────────────────────

        # User KPOINTS settings overrides (normalize keys to uppercase)
        if kpoints_settings:
            config_dict["KPOINTS"].update(
                {k.upper(): v for k, v in kpoints_settings.items()}
            )
            if verbose:
                print(f"{tag} KPOINTS overrides: {list(kpoints_settings.keys())}")

        if kpoints_settings is None or kpoints_settings == {}:
            raise ValueError(f"{tag} KPOINTS settings cannot be None or empty")

        kpts_cfg = {k.upper(): v for k, v in kpoints_settings.items()}
        style = str(kpts_cfg.get("STYLE", ""))
        kpts = tuple(kpts_cfg.get("KPTS", []))

        if style.lower() == "gamma":
            builder = Kpoints.gamma_automatic
            kpts_input = builder(kpts=kpts)

        elif style.lower() == "monkhorst":
            builder = Kpoints.monkhorst_automatic
            kpts_input = builder(kpts=kpts)

        elif style.lower() == "explicit":
            kpts_weights = kpts_cfg.get("KPTS_WEIGHTS", [1.0] * len(kpts))
            kpts_input = Kpoints(
                comment="Explicit k-points",
                num_kpts=len(kpts),
                style=Kpoints.supported_modes.Reciprocal,
                kpts=kpts,
                kpts_weights=kpts_weights,
            )

        else:
            raise ValueError("Invalid KPOINTS style")

        if verbose:
            print(f"{tag} KPOINTS: {style} {list(kpts)}")

        # Set KPOINTS_OPT (electronic band structure, VASP >= 6)
        kpoints_opt = kpts_cfg.get("KPOINTS_OPT", None)
        if kpoints_opt:
            try:
                kpoints_opt = Kpoints.automatic_linemode(
                    20,
                    ibz=HighSymmKpath(structure),
                )
            except Exception as exc:
                if verbose:
                    print(f"{tag} KPOINTS_OPT failed: {exc}")

        # Set QPOINTS (phonons band structure, VASP >= 6)
        qpoints = kpts_cfg.get("QPOINTS", None)
        if qpoints:
            try:
                qpoints = Kpoints.automatic_linemode(
                    qpoints["grid_divisions"],
                    ibz=HighSymmKpath(structure),
                )
            except Exception as exc:
                if verbose:
                    print(f"{tag} QPOINTS failed: {exc}")

        # Set POSNICS (NMR/NICS calculations, VASP >= 6)
        posnics = kpts_cfg.get("POSNICS", None)
        if posnics:
            try:
                kpts_list = internals._generate_posnics_grid(
                    slabfy_obj, posnics["GRID_SPACING"], posnics["PADDING"]
                )
                posnics = Kpoints(
                    comment="Explicit POSNICS grid points",
                    num_kpts=len(kpts_list),
                    style=Kpoints.supported_modes.Reciprocal,
                    kpts=kpts_list,
                    kpts_weights=[1.0] * len(kpts_list),
                )
            except Exception as exc:
                if verbose:
                    print(f"{tag} POSNICS failed: {exc}")

        # ── POTCAR ─────────────────────────────────────────

        # User POTCAR settings overrides (normalize keys to uppercase)
        if potcar_settings:
            config_dict["POTCAR"].update(
                {k.upper(): v for k, v in potcar_settings.items()}
            )
            if verbose:
                print(f"{tag} POTCAR overrides: {list(potcar_settings.keys())}")

        # Set POTCAR_PATH
        default_potcar_path = vasp_modifiers.get("POTCAR_PATH", "")
        if default_potcar_path == "":
            raise ValueError("POTCAR_PATH not defined")

        potcar_func = vasp_section.get("POTCAR_PATHS").get(default_potcar_path, "")
        if potcar_func == "":
            potcar_func = default_potcar_path

        config_dict["POTCAR_FUNCTIONAL"] = potcar_func
        if potcar_path:
            from pymatgen.core import SETTINGS

            SETTINGS["PMG_VASP_PSP_DIR"] = potcar_path
            if verbose:
                print(f"{tag} POTCAR: {potcar_func} @ {potcar_path}")
        elif verbose:
            print(
                f"{tag} Warning: no POTCAR path for "
                f"{potcar_func!r}. Configure in slabfy.json "
                f"→ VASP.POTCAR_PATH or pass "
                f"vasp_settings={{'{potcar_func}': '/path'}}"
            )

        # ── build VaspInputSet ───────────────────────────────
        vis = VaspInputSet(
            structure=structure,
            config_dict=config_dict,
            user_incar_settings=(
                {k.upper(): v for k, v in incar_settings.items()}
                if incar_settings
                else {}
            ),
            user_kpoints_settings=kpts_input,
            user_potcar_settings=potcar_settings,
            user_potcar_functional=potcar_func,
            sort_structure=False,
        )

        poscar, incar, kpoints = (
            vis.poscar,
            vis.incar,
            vis.kpoints,
        )

        potcar = None
        if potcar_path:
            try:
                potcar = vis.potcar
            except Exception as exc:
                if verbose:
                    print(f"{tag} POTCAR failed: {exc}")
        elif verbose:
            print(f"{tag} Skipping POTCAR (no PAW path)")

        # ── write files (only when dir_path is set) ────────
        if dir_path is not None:
            os.makedirs(dir_path, exist_ok=True)
            poscar_path = os.path.join(dir_path, "POSCAR")

            if isinstance(slabfy_obj, (Bulk, Adparticle, Surface, Interface)):
                slabfy_obj.write(poscar_path)
            else:
                poscar.write_file(poscar_path)
                if verbose:
                    print(
                        f"{tag} POSCAR written without "
                        f"pickle header (input was not a "
                        f"Bulk/Adparticle/Surface/Interface)"
                    )

            incar.write_file(
                os.path.join(dir_path, "INCAR"),
            )
            kpoints.write_file(
                os.path.join(dir_path, "KPOINTS"),
            )
            if potcar is not None:
                potcar.write_file(
                    os.path.join(dir_path, "POTCAR"),
                )
            if kpoints_opt is not None:
                kpoints_opt.write_file(
                    os.path.join(dir_path, "KPOINTS_OPT"),
                )
            if qpoints is not None:
                qpoints.write_file(
                    os.path.join(dir_path, "QPOINTS"),
                )
            if posnics is not None:
                posnics.write_file(
                    os.path.join(dir_path, "POSNICS"),
                )
            if verbose:
                written = ["POSCAR", "INCAR", "KPOINTS"]
                if potcar:
                    written.append("POTCAR")
                if kpoints_opt:
                    written.append("KPOINTS_OPT")
                if qpoints:
                    written.append("QPOINTS")
                if posnics:
                    written.append("POSNICS")
                print(f"{tag} Wrote {', '.join(written)} → {dir_path}/")

        # ── sbatch job script ────────────────────────────────
        sbatch = None
        if sbatch_config is not None:
            sbatch_section = utils.SFY_SETTINGS.get("SBATCH", {})
            default_sbatch_config = sbatch_section.get("SBATCH_CONFIG", {})

            if sbatch_config:
                sbatch_config = {k.upper(): v for k, v in sbatch_config.items()}
                sbatch_config = default_sbatch_config | sbatch_config
            else:
                sbatch_config = default_sbatch_config

            sbatch_preset = sbatch_config.get("DEFAULT", "")
            job_config = sbatch_section.get("SBATCH_PRESETS").get(sbatch_preset, {})

            if job_config == {}:
                raise ValueError("DEFAULT sbatch preset not found")

            job_config = job_config | sbatch_config

            sbatch = _render_job_script(
                job_config,
                output_file=(
                    os.path.join(dir_path, "run.sbatch") if dir_path else None
                ),
            )
            if verbose and dir_path:
                print(f"{tag} Wrote job script → {dir_path}/run.sbatch")

        setup_set = {
            "poscar": poscar,
            "incar": incar,
            "kpoints": kpoints,
            "kpoints_opt": kpoints_opt,
            "qpoints": qpoints,
            "posnics": posnics,
            "potcar": potcar,
            "sbatch": sbatch,
        }

        return {k: v for k, v in setup_set.items() if v is not None}

    def _parse_run(
        self,
        slabfy_obj: Union[Surface, Interface, Structure, str],
        dir_path: str,
        method_tag: str,
        parse_dos: bool = True,
        parse_eigen: bool = True,
        parse_projected: bool = True,
        **kwargs,
    ) -> VaspReport:
        """Parse a VASP calculation directory into a
        :class:`VaspReport` container.

        Probes the directory for all recognized VASP output
        files and extracts every available quantity.  When
        both ``vaspout.h5`` and legacy files exist, results
        are merged — pymatgen (from XML/OUTCAR) takes
        precedence for rich canonical objects (``CompleteDos``,
        ``BandStructureSymmLine``); py4vasp fills in
        HDF5-exclusive quantities (workfunction,
        electronic_convergence).

        Parameters
        ----------
        slabfy_obj : Surface | Interface | Structure | str
            Input geometry — slabfy object, pymatgen Structure,
            or POSCAR file path.
        dir_path : str
            Path to the VASP calculation directory.
        method_tag : str
            Tag identifying the VASP calculation method.
        parse_dos : bool
            Parse DOS from vasprun.xml (can be slow for
            large systems).
        parse_eigen : bool
            Parse eigenvalues from vasprun.xml.
        parse_projected : bool
            Parse projected eigenvalues (LORBIT).
        **kwargs
            Recognized key: ``settings`` (dict with
            ``"verbose"`` flag).

        Returns
        -------
        VaspReport
            Fully populated results container.
        """
        tag = "[VaspTools._parse_run]"
        _cfg = kwargs.get("settings", {})
        verbose = bool(_cfg.get("verbose", True)) if isinstance(_cfg, dict) else True

        directory = os.path.abspath(dir_path)
        if not os.path.isdir(directory):
            raise FileNotFoundError(f"Directory not found: {directory}")

        # ── probe available files ────────────────────
        available = internals._probe_vasp_outputs(directory)
        if verbose:
            names = [os.path.basename(p) for p in available.values()]
            print(f"{tag} Found {len(available)} output file(s): {', '.join(names)}")

        if not available:
            raise FileNotFoundError(f"No VASP output files found in {directory}")

        # ── parse each source independently ──────────
        parts: list[dict[str, Any]] = []

        # 1. vasprun.xml  (richest canonical objects)
        if "vasprun_xml" in available:
            if verbose:
                print(f"{tag} Parsing vasprun.xml …")
            parts.append(
                internals._parse_vasprun_xml(
                    available["vasprun_xml"],
                    parse_dos=parse_dos,
                    parse_eigen=parse_eigen,
                    parse_projected=parse_projected,
                ),
            )

        # 2. OUTCAR  (per-ion, energy decomp, run stats)
        if "outcar" in available:
            if verbose:
                print(f"{tag} Parsing OUTCAR …")
            parts.append(
                internals._parse_outcar(available["outcar"]),
            )

        # 3. vaspout.h5  (HDF5 backend via py4vasp)
        if "vaspout_h5" in available:
            if verbose:
                print(f"{tag} Parsing vaspout.h5 …")
            parts.append(
                internals._parse_vaspout_h5(available["vaspout_h5"]),
            )

        # ── merge: earlier sources take precedence ───
        # vasprun.xml first  →  OUTCAR  →  vaspout.h5
        merged: dict[str, Any] = {}
        for part in parts:
            for key, val in part.items():
                if key not in merged:
                    merged[key] = val

        merged["directory"] = directory
        merged["available_files"] = available

        # ── parse LOCPOT (optional) ───────────────────
        if "locpot" in available and "workfunction" not in merged:
            if verbose:
                print(f"{tag} Parsing LOCPOT …")
            locpot_data = internals._parse_locpot(
                available["locpot"],
                fermi_energy=merged.get("fermi_energy"),
            )
            for key, val in locpot_data.items():
                if key not in merged:
                    merged[key] = val

        # ── build VaspReport ─────────────────────────
        field_names = {f.name for f in VaspReport.__dataclass_fields__.values()}
        init_kwargs = {k: v for k, v in merged.items() if k in field_names}
        results = VaspReport(**init_kwargs)

        if verbose:
            formula = (
                results.structure.composition.reduced_formula
                if results.structure
                else "unknown"
            )
            print(
                f"{tag} {formula} | "
                f"calc_type={results.calc_type} | "
                f"converged={results.converged} | "
                f"E={results.energy}"
            )

        # ── bind VaspReport to slabfy object ─────────
        internals._bind_report(results, slabfy_obj, method_tag)

        return results

    def relax(
        self,
        structure: Union[Surface, Interface, Structure, str],
        dir_path: str,
        method: Literal["write", "read"],
        auto_freeze: bool = True,
        **kwargs,
    ):
        """Write/read a surface relaxation VASP calculation.

        Parameters
        ----------
        structure : Surface | Interface | Structure | str
            Input geometry — slabfy ``Surface``, pymatgen
            ``Structure``, or path to a POSCAR file.
            If a path is provided, the structure will be
            read/written from the file.
        dir_path : str
            Output (write) or input (read) directory.
        method : ``"write"`` | ``"read"``
            Operation mode.
        auto_freeze : bool
            Whether to freeze/unfreeze the layers next to
            the surface and interface regions.
        **kwargs
            Additional keyword arguments to be passed to the
            ``VaspInputSet`` constructor.

        Example of properties to return:
        - CONTCAR → XRD
        - Total E
        - Forces
        - Bond distances, Dipole, etc
        - LOCPOT: WF, VL → AFM-Hartree
        """
        tag = "[VaspTools.relax]"
        _cfg = kwargs.get("settings", {})
        verbose = bool(_cfg.get("verbose", True)) if isinstance(_cfg, dict) else True

        structure_path = None
        if isinstance(structure, str):
            structure_path = structure
            structure = _read_slabfy_file(structure_path)
            if verbose:
                print(f"{tag} Read structure from file")

        if method == "write":
            # Import VASP set from `utils.SFY_SETTINGS`
            vasp_section = utils.SFY_SETTINGS.get("VASP", {})
            vasp_modifiers = vasp_section.get("VASP_MODIFIERS", {})
            relax_set = vasp_section.get("SETS", {}).get("RelaxSet", {})

            incar_settings = relax_set.get("INCAR", {})
            kpoints_settings = relax_set.get("KPOINTS", {})
            potcar_settings = relax_set.get("POTCAR", {})

            # Optimize `relax_set` for Bulk calculation:
            if isinstance(structure, Bulk):
                if auto_freeze:
                    structure = utils.freeze_coords(structure, coord1=0)

            # Optimize `relax_set` for Adparticle calculation:
            elif isinstance(structure, Adparticle):
                if auto_freeze:
                    structure = utils.freeze_coords(structure, coord1=0)

                incar_settings["ISIF"] = 2  # Only ions move
                kpoints_settings["KPTS"] = [1, 1, 1]

            # Optimize `relax_set` for Surface calculation:
            elif isinstance(structure, Surface):
                if auto_freeze:
                    structure = utils.freeze_coords(
                        structure, coord1=3, axis="c", mode="layers"
                    )

                incar_settings["ISIF"] = 2  # Only ions move
                kpoints_settings["KPTS"] = [3, 3, 1]

                if structure.vacuum > utils.PHYS_CONSTANTS["MIN_VACUUM_SIZE"]:
                    vasp_modifiers["CORRECTIONS"] += ["Net-dipole"]
                    incar_settings["NELMDL"] = 2  # Improve slabs SCF-convergence

                else:
                    warnings.warn(
                        f"{tag} Vacuum is less than {utils.PHYS_CONSTANTS['MIN_VACUUM_SIZE']} Angstrom. "
                        f"No corrections for the vacuum region applied."
                    )

            # Optimize `relax_set` for Interface calculation:
            elif isinstance(structure, Interface):
                if not structure.adparticle:
                    if auto_freeze:
                        structure = utils.freeze_coords(
                            structure, coord1=3, coord2=3, axis="b", mode="layers"
                        )

                    incar_settings["ISIF"] = 8  # Ions and cell shape can change
                    kpoints_settings["KPTS"] = [3, 3, 1]

                else:
                    if auto_freeze:
                        structure = utils.freeze_coords(
                            structure, coord1=3, axis="c", mode="layers"
                        )

                    incar_settings["ISIF"] = 2  # Only ions move
                    kpoints_settings["KPTS"] = [3, 3, 1]

                if structure.vacuum > utils.PHYS_CONSTANTS["MIN_VACUUM_SIZE"]:
                    vasp_modifiers["CORRECTIONS"] += ["Net-dipole"]
                    incar_settings["NELMDL"] = 2  # Improve slabs SCF-convergence

                else:
                    warnings.warn(
                        f"{tag} Vacuum is less than {utils.PHYS_CONSTANTS['MIN_VACUUM_SIZE']} Angstrom. "
                        f"No corrections for the vacuum region applied."
                    )

            # Honor custom settings, if provided in **kwargs
            incar_settings = incar_settings | kwargs.get("incar_settings", {})
            kpoints_settings = kpoints_settings | kwargs.get("kpoints_settings", {})
            potcar_settings = potcar_settings | kwargs.get("potcar_settings", {})
            vasp_modifiers = vasp_modifiers | kwargs.get("vasp_modifiers", {})
            sbatch_config = kwargs.get("sbatch_config", {})

            # Call `_setup_run` with the merged settings
            vasp_setup = self._setup_run(
                structure=structure,
                incar_settings=incar_settings,
                kpoints_settings=kpoints_settings,
                potcar_settings=potcar_settings,
                vasp_modifiers=vasp_modifiers,
                sbatch_config=sbatch_config,
                dir_path=dir_path,
                settings={"verbose": verbose},
            )

            return vasp_setup

        elif method == "read":
            # Update the slabfy structure with the relaxed structure
            structure = _read_slabfy_file(os.path.join(dir_path, "CONTCAR"))

            # Parse the VASP calculation and update the slabfy structure
            vasp_results = self._parse_run(
                slabfy_obj=structure,
                dir_path=dir_path,
                method_tag=tag,
                parse_dos=False,
                parse_eigen=False,
                parse_projected=False,
                settings={"verbose": verbose},
            )

            # Write/update the slabfy structure, if a file path is provided
            if structure_path:
                structure.write(structure_path)

            return vasp_results

        else:
            raise ValueError(
                f"{tag} Invalid method: {method!r}. Expected 'write' or 'read'."
            )

    def static(
        self,
        structure: Union[Surface, Interface, Structure, str],
        method: Literal["write", "read"],
        dir_path: str | None = None,
        **kwargs,
    ):
        """Write/read a surface static VASP calculation.

        Example of properties to return:
        - DOS, DIS
        - COHP (Lobster)
        - UPS/XPS/HAXPES (Galore)
        - Band Structure
        - d-band center (&_d)
        - CBM, VBM, IP, EF
        - ELF
        - Bader charges

        The **write** path loads ``StaticSet`` from
        ``SFY_SETTINGS``, applies default corrections,
        adds surface-specific INCAR tags (``LVHAR``,
        ``LORBIT``, ``LWAVE``), honours user overrides
        from *vasp_set*, and delegates to
        :meth:`_setup_run`.

        The **read** path calls :meth:`_parse_run` with full
        DOS / eigenvalue / projected-DOS parsing, reconstructs
        the :class:`Surface` from the CONTCAR pickle header,
        and derives all available surface properties (surface
        energy, work function, band gap, DOS, band structure,
        etc.).

        Parameters
        ----------
        surface : Surface | Structure | str
            Input geometry — slabfy ``Surface``, pymatgen
            ``Structure``, or path to a POSCAR file.
        dir_path : str
            Output (write) or input (read) directory.
        method : ``"write"`` | ``"read"``
            Operation mode.
        vasp_set : dict | None
            User INCAR / KPOINTS overrides merged on top of
            the static preset (deep-merged for nested dicts).
        **kwargs
            Forwarded to ``_setup_run`` / ``_parse_run``.
            Recognized key: ``settings`` (dict with
            ``"verbose"`` flag).

        Returns
        -------
        dict (write)
            ``_setup_run`` result dict (poscar, incar, …).
        Surface | VaspReport (read)
            Reconstructed ``Surface`` with
            ``properties_metadata`` and ``vasp_results``
            attached, or a plain ``VaspReport`` if the
            CONTCAR does not carry a serialised ``Surface``.
        """
        tag = "[VaspTools.static]"
        _cfg = kwargs.get("settings", {})
        verbose = bool(_cfg.get("verbose", True)) if isinstance(_cfg, dict) else True

        structure_path = None
        if isinstance(structure, str):
            structure_path = structure
            structure = _read_slabfy_file(structure_path)
            if verbose:
                print(f"{tag} Read structure from file")

        if method == "write":
            # Import VASP set from `utils.SFY_SETTINGS`
            vasp_section = utils.SFY_SETTINGS.get("VASP", {})
            vasp_modifiers = vasp_section.get("VASP_MODIFIERS", {})
            static_set = vasp_section.get("SETS", {}).get("StaticSet", {})

            incar_settings = static_set.get("INCAR", {})
            kpoints_settings = static_set.get("KPOINTS", {})
            potcar_settings = static_set.get("POTCAR", {})

            # Optimize `static_set` for Adparticle calculations:
            if isinstance(structure, (Adparticle)):
                kpoints_settings["KPTS"] = [1, 1, 1]

            # Optimize `static_set` for Surface and Interface calculations:
            if isinstance(structure, (Surface, Interface)):
                kpoints_settings["KPTS"] = [5, 5, 1]

                if structure.vacuum > utils.PHYS_CONSTANTS["MIN_VACUUM_SIZE"]:
                    vasp_modifiers["CORRECTIONS"] += ["Net-dipole"]
                    incar_settings["NELMDL"] = 2  # Improve slabs SCF-convergence

                else:
                    warnings.warn(
                        f"{tag} Vacuum is less than {utils.PHYS_CONSTANTS['MIN_VACUUM_SIZE']} Angstrom. "
                        f"No corrections for the vacuum region applied."
                    )

            # Honor custom settings, if provided in **kwargs
            incar_settings = incar_settings | kwargs.get("incar_settings", {})
            kpoints_settings = kpoints_settings | kwargs.get("kpoints_settings", {})
            potcar_settings = potcar_settings | kwargs.get("potcar_settings", {})
            vasp_modifiers = vasp_modifiers | kwargs.get("vasp_modifiers", {})
            sbatch_config = kwargs.get("sbatch_config", {})

            # Call `_setup_run` with the merged settings
            vasp_setup = self._setup_run(
                structure=structure,
                incar_settings=incar_settings,
                kpoints_settings=kpoints_settings,
                potcar_settings=potcar_settings,
                vasp_modifiers=vasp_modifiers,
                sbatch_config=sbatch_config,
                dir_path=dir_path,
                settings={"verbose": verbose},
            )

            return vasp_setup

        elif method == "read":
            # Update the slabfy structure with the relaxed structure
            structure = _read_slabfy_file(os.path.join(dir_path, "CONTCAR"))

            # Parse the VASP calculation and update the slabfy structure
            vasp_results = self._parse_run(
                slabfy_obj=structure,
                dir_path=dir_path,
                method_tag=tag,
                parse_dos=True,
                parse_eigen=True,
                parse_projected=True,
                settings={"verbose": verbose},
            )

            # Write/update the slabfy structure, if a file path is provided
            if structure_path:
                structure.write(structure_path)

            return vasp_results

        else:
            raise ValueError(
                f"{tag} Invalid method: {method!r}. Expected 'write' or 'read'."
            )

    def phonons(
        self,
        structure: Union[Surface, Interface, Structure, str],
        method: Literal["write", "read"],
        dir_path: str | None = None,
        dispersion: Literal["gamma", "full"] = "gamma",
        **kwargs,
    ):
        """Write or read a phonon VASP calculation.

        Example of properties to return:
        - ZPE
        - Vibration modes
        - Force Constants
        - PDOS, PDIS

        """
        tag = "[VaspTools.phonons]"
        _cfg = kwargs.get("settings", {})
        verbose = bool(_cfg.get("verbose", True)) if isinstance(_cfg, dict) else True

        structure_path = None
        if isinstance(structure, str):
            structure_path = structure
            structure = _read_slabfy_file(structure_path)
            if verbose:
                print(f"{tag} Read structure from file")

        if method == "write":
            # Import VASP set from `utils.SFY_SETTINGS`
            vasp_section = utils.SFY_SETTINGS.get("VASP", {})
            vasp_modifiers = vasp_section.get("VASP_MODIFIERS", {})
            vibration_set = vasp_section.get("SETS", {}).get("PhononSet", {})

            incar_settings = vibration_set.get("INCAR", {})
            kpoints_settings = vibration_set.get("KPOINTS", {})
            potcar_settings = vibration_set.get("POTCAR", {})

            if dispersion == "full":
                structure = utils.freeze_coords(structure, coord1=0)
                incar_settings["LPHON_DISPERSION"] = True
                kpoints_settings["QPOINTS"] = {"grid_divisions": 20}
                if isinstance(structure, Bulk):
                    structure = structure.make_supercell([3, 3, 3])
                elif isinstance(structure, (Surface, Interface)):
                    structure.slab = structure.slab.make_supercell([2, 2, 1])

            elif dispersion != "gamma":
                raise ValueError(
                    f"{tag} Invalid dispersion mode: {dispersion!r}. Expected 'gamma' or 'full'."
                )

            # Optimize `vibration_set` for Adparticle calculations:
            if isinstance(structure, (Adparticle)):
                kpoints_settings["KPTS"] = [1, 1, 1]

            # Optimize `vibration_set` for Surface and Interface calculations:
            if isinstance(structure, (Surface, Interface)):
                kpoints_settings["KPTS"] = [3, 3, 1]

                if structure.vacuum > utils.PHYS_CONSTANTS["MIN_VACUUM_SIZE"]:
                    vasp_modifiers["CORRECTIONS"] += ["Net-dipole"]
                    incar_settings["NELMDL"] = 2  # Improve slabs SCF-convergence

                else:
                    warnings.warn(
                        f"{tag} Vacuum is less than {utils.PHYS_CONSTANTS['MIN_VACUUM_SIZE']} Angstrom. "
                        f"No corrections for the vacuum region applied."
                    )

            # Honor custom settings, if provided in **kwargs
            incar_settings = incar_settings | kwargs.get("incar_settings", {})
            kpoints_settings = kpoints_settings | kwargs.get("kpoints_settings", {})
            potcar_settings = potcar_settings | kwargs.get("potcar_settings", {})
            vasp_modifiers = vasp_modifiers | kwargs.get("vasp_modifiers", {})
            sbatch_config = kwargs.get("sbatch_config", {})

            # Call `_setup_run` with the merged settings
            vasp_setup = self._setup_run(
                structure=structure,
                incar_settings=incar_settings,
                kpoints_settings=kpoints_settings,
                potcar_settings=potcar_settings,
                vasp_modifiers=vasp_modifiers,
                sbatch_config=sbatch_config,
                dir_path=dir_path,
                settings={"verbose": verbose},
            )

            return vasp_setup

        elif method == "read":
            # Update the slabfy structure with the relaxed structure
            structure = _read_slabfy_file(os.path.join(dir_path, "CONTCAR"))

            # Parse the VASP calculation and update the slabfy structure
            vasp_results = self._parse_run(
                slabfy_obj=structure,
                dir_path=dir_path,
                method_tag=tag,
                parse_dos=True,
                parse_eigen=True,
                parse_projected=True,
                settings={"verbose": verbose},
            )

            # Write/update the slabfy structure, if a file path is provided
            if structure_path:
                structure.write(structure_path)

            return vasp_results

        else:
            raise ValueError(
                f"{tag} Invalid method: {method!r}. Expected 'write' or 'read'."
            )

    def optical(
        self,
        structure: Union[Surface, Interface, Structure, str],
        method: Literal["write", "read"],
        dir_path: str | None = None,
        **kwargs,
    ):
        """Write or read an optical VASP calculation.

        REQUIRES: CHGCAR in ``dir_path`` from a previous static calculation.

        Example of properties to return:
        - Absorbance
        - Dieletric Constants
        - Plasmons
        """
        tag = "[VaspTools.optical]"
        _cfg = kwargs.get("settings", {})
        verbose = bool(_cfg.get("verbose", True)) if isinstance(_cfg, dict) else True

        # Check if CHGCAR exists in ``dir_path``
        if not os.path.exists(os.path.join(dir_path, "CHGCAR")):
            raise ValueError(
                f"{tag} Requires CHGCAR in ``dir_path`` from a previous static calculation."
            )

        structure_path = None
        if isinstance(structure, str):
            structure_path = structure
            structure = _read_slabfy_file(structure_path)
            if verbose:
                print(f"{tag} Read structure from file")

        if method == "write":
            # Import VASP set from `utils.SFY_SETTINGS`
            vasp_section = utils.SFY_SETTINGS.get("VASP", {})
            vasp_modifiers = vasp_section.get("VASP_MODIFIERS", {})
            nscf_set = vasp_section.get("SETS", {}).get("NSCFSet", {})

            incar_settings = nscf_set.get("INCAR", {})
            kpoints_settings = nscf_set.get("KPOINTS", {})
            potcar_settings = nscf_set.get("POTCAR", {})

            # Activate optical properties calculation
            incar_settings["LOPTICS"] = True

            # Optimize `nscf_set` for Adparticle calculations:
            if isinstance(structure, (Adparticle)):
                kpoints_settings["KPTS"] = [1, 1, 1]

            # Optimize `nscf_set` for Surface and Interface calculations:
            if isinstance(structure, (Surface, Interface)):
                kpoints_settings["KPTS"] = [9, 9, 1]

                if structure.vacuum > utils.PHYS_CONSTANTS["MIN_VACUUM_SIZE"]:
                    vasp_modifiers["CORRECTIONS"] += ["Net-dipole"]
                    incar_settings["NELMDL"] = 2  # Improve slabs SCF-convergence

                else:
                    warnings.warn(
                        f"{tag} Vacuum is less than {utils.PHYS_CONSTANTS['MIN_VACUUM_SIZE']} Angstrom. "
                        f"No corrections for the vacuum region applied."
                    )

            # Honor custom settings, if provided in **kwargs
            incar_settings = incar_settings | kwargs.get("incar_settings", {})
            kpoints_settings = kpoints_settings | kwargs.get("kpoints_settings", {})
            potcar_settings = potcar_settings | kwargs.get("potcar_settings", {})
            vasp_modifiers = vasp_modifiers | kwargs.get("vasp_modifiers", {})
            sbatch_config = kwargs.get("sbatch_config", {})

            # Call `_setup_run` with the merged settings
            vasp_setup = self._setup_run(
                structure=structure,
                incar_settings=incar_settings,
                kpoints_settings=kpoints_settings,
                potcar_settings=potcar_settings,
                vasp_modifiers=vasp_modifiers,
                sbatch_config=sbatch_config,
                dir_path=dir_path,
                settings={"verbose": verbose},
            )

            return vasp_setup

        elif method == "read":
            # Update the slabfy structure with the relaxed structure
            structure = _read_slabfy_file(os.path.join(dir_path, "CONTCAR"))

            # Parse the VASP calculation and update the slabfy structure
            vasp_results = self._parse_run(
                slabfy_obj=structure,
                dir_path=dir_path,
                method_tag=tag,
                parse_dos=True,
                parse_eigen=True,
                parse_projected=True,
                settings={"verbose": verbose},
            )

            # Write/update the slabfy structure, if a file path is provided
            if structure_path:
                structure.write(structure_path)

            return vasp_results

        else:
            raise ValueError(
                f"{tag} Invalid method: {method!r}. Expected 'write' or 'read'."
            )

    def wannier(
        self,
        structure: Union[Surface, Interface, Structure, str],
        method: Literal["write", "read"],
        dir_path: str | None = None,
        **kwargs,
    ):
        """Write or read a Wannier VASP calculation.

        REQUIRES: CHGCAR in ``dir_path`` from a previous static calculation.

        Example of properties to return:
        - Wannier functions
        """
        tag = "[VaspTools.wannier]"
        _cfg = kwargs.get("settings", {})
        verbose = bool(_cfg.get("verbose", True)) if isinstance(_cfg, dict) else True

        # Check if CHGCAR exists in ``dir_path``
        if not os.path.exists(os.path.join(dir_path, "CHGCAR")):
            raise ValueError(
                f"{tag} Requires CHGCAR in ``dir_path`` from a previous static calculation."
            )

        structure_path = None
        if isinstance(structure, str):
            structure_path = structure
            structure = _read_slabfy_file(structure_path)
            if verbose:
                print(f"{tag} Read structure from file")

        if method == "write":
            # Import VASP set from `utils.SFY_SETTINGS`
            vasp_section = utils.SFY_SETTINGS.get("VASP", {})
            vasp_modifiers = vasp_section.get("VASP_MODIFIERS", {})
            nscf_set = vasp_section.get("SETS", {}).get("NSCFSet", {})

            incar_settings = nscf_set.get("INCAR", {})
            kpoints_settings = nscf_set.get("KPOINTS", {})
            potcar_settings = nscf_set.get("POTCAR", {})

            # Activate wannier properties calculation
            incar_settings["LWANNIER90"] = True
            incar_settings["LWRITE_WANPROJ"] = True

            # Optimize `nscf_set` for Adparticle calculations:
            if isinstance(structure, (Adparticle)):
                kpoints_settings["KPTS"] = [1, 1, 1]

            # Optimize `nscf_set` for Surface and Interface calculations:
            if isinstance(structure, (Surface, Interface)):
                kpoints_settings["KPTS"] = [9, 9, 1]

                if structure.vacuum > utils.PHYS_CONSTANTS["MIN_VACUUM_SIZE"]:
                    vasp_modifiers["CORRECTIONS"] += ["Net-dipole"]
                    incar_settings["NELMDL"] = 2  # Improve slabs SCF-convergence

                else:
                    warnings.warn(
                        f"{tag} Vacuum is less than {utils.PHYS_CONSTANTS['MIN_VACUUM_SIZE']} Angstrom. "
                        f"No corrections for the vacuum region applied."
                    )

            # Honor custom settings, if provided in **kwargs
            incar_settings = incar_settings | kwargs.get("incar_settings", {})
            kpoints_settings = kpoints_settings | kwargs.get("kpoints_settings", {})
            potcar_settings = potcar_settings | kwargs.get("potcar_settings", {})
            vasp_modifiers = vasp_modifiers | kwargs.get("vasp_modifiers", {})
            sbatch_config = kwargs.get("sbatch_config", {})

            # Call `_setup_run` with the merged settings
            vasp_setup = self._setup_run(
                structure=structure,
                incar_settings=incar_settings,
                kpoints_settings=kpoints_settings,
                potcar_settings=potcar_settings,
                vasp_modifiers=vasp_modifiers,
                sbatch_config=sbatch_config,
                dir_path=dir_path,
                settings={"verbose": verbose},
            )

            return vasp_setup

        elif method == "read":
            # Update the slabfy structure with the relaxed structure
            structure = _read_slabfy_file(os.path.join(dir_path, "CONTCAR"))

            # Parse the VASP calculation and update the slabfy structure
            vasp_results = self._parse_run(
                slabfy_obj=structure,
                dir_path=dir_path,
                method_tag=tag,
                parse_dos=True,
                parse_eigen=True,
                parse_projected=True,
                settings={"verbose": verbose},
            )

            # Write/update the slabfy structure, if a file path is provided
            if structure_path:
                structure.write(structure_path)

            return vasp_results

        else:
            raise ValueError(
                f"{tag} Invalid method: {method!r}. Expected 'write' or 'read'."
            )

    def carriers(
        self,
        structure: Union[Surface, Interface, Structure, str],
        method: Literal["write", "read"],
        dir_path: str | None = None,
        **kwargs,
    ):
        """Write or read a charge carriers VASP calculation.

        REQUIRES: CHGCAR in ``dir_path`` from a previous static calculation.

        Example of properties to return:
        - Effective masses
        """
        tag = "[VaspTools.carriers]"
        _cfg = kwargs.get("settings", {})
        verbose = bool(_cfg.get("verbose", True)) if isinstance(_cfg, dict) else True

        # Check if CHGCAR exists in ``dir_path``
        if not os.path.exists(os.path.join(dir_path, "CHGCAR")):
            raise ValueError(
                f"{tag} Requires CHGCAR in ``dir_path`` from a previous static calculation."
            )

        structure_path = None
        if isinstance(structure, str):
            structure_path = structure
            structure = _read_slabfy_file(structure_path)
            if verbose:
                print(f"{tag} Read structure from file")

        if method == "write":
            # Import VASP set from `utils.SFY_SETTINGS`
            vasp_section = utils.SFY_SETTINGS.get("VASP", {})
            vasp_modifiers = vasp_section.get("VASP_MODIFIERS", {})
            nscf_set = vasp_section.get("SETS", {}).get("NSCFSet", {})

            incar_settings = nscf_set.get("INCAR", {})
            kpoints_settings = nscf_set.get("KPOINTS", {})
            potcar_settings = nscf_set.get("POTCAR", {})

            # Activate charge carriers calculation
            incar_settings["ISYM"] = 0
            incar_settings["ISMEAR"] = 0
            incar_settings["SIGMA"] = 0.01

            # Get vbm/cbm fractional coordinates from static run
            static_bands = structure.properties_metadata.get("static/band_edges", {})
            vbm_coords = static_bands.get("vbm", {}).get("kpoint_coords", [])
            cbm_coords = static_bands.get("cbm", {}).get("kpoint_coords", [])

            if vbm_coords and cbm_coords:
                kpts, weights = internals._generate_carrier_kpoints(
                    vbm_coords, cbm_coords, dk=0.015
                )
                kpoints_settings["STYLE"] = "Explicit"
                kpoints_settings["KPTS"] = kpts
                kpoints_settings["KPTS_WEIGHTS"] = weights

            else:
                raise ValueError(
                    "VBM and CBM coordinates not found in ``static_bands``."
                )

            # Optimize `nscf_set` for Adparticle calculations:
            if isinstance(structure, (Adparticle)):
                kpoints_settings["KPTS"] = [1, 1, 1]

            # Optimize `nscf_set` for Surface and Interface calculations:
            if isinstance(structure, (Surface, Interface)):
                kpoints_settings["KPTS"] = [9, 9, 1]

                if structure.vacuum > utils.PHYS_CONSTANTS["MIN_VACUUM_SIZE"]:
                    vasp_modifiers["CORRECTIONS"] += ["Net-dipole"]
                    incar_settings["NELMDL"] = 2  # Improve slabs SCF-convergence

                else:
                    warnings.warn(
                        f"{tag} Vacuum is less than {utils.PHYS_CONSTANTS['MIN_VACUUM_SIZE']} Angstrom. "
                        f"No corrections for the vacuum region applied."
                    )

            # Honor custom settings, if provided in **kwargs
            incar_settings = incar_settings | kwargs.get("incar_settings", {})
            kpoints_settings = kpoints_settings | kwargs.get("kpoints_settings", {})
            potcar_settings = potcar_settings | kwargs.get("potcar_settings", {})
            vasp_modifiers = vasp_modifiers | kwargs.get("vasp_modifiers", {})
            sbatch_config = kwargs.get("sbatch_config", {})

            # Call `_setup_run` with the merged settings
            vasp_setup = self._setup_run(
                structure=structure,
                incar_settings=incar_settings,
                kpoints_settings=kpoints_settings,
                potcar_settings=potcar_settings,
                vasp_modifiers=vasp_modifiers,
                sbatch_config=sbatch_config,
                dir_path=dir_path,
                settings={"verbose": verbose},
            )

            return vasp_setup

        elif method == "read":
            # Update the slabfy structure with the relaxed structure
            structure = _read_slabfy_file(os.path.join(dir_path, "CONTCAR"))

            # Parse the VASP calculation and update the slabfy structure
            vasp_results = self._parse_run(
                slabfy_obj=structure,
                dir_path=dir_path,
                method_tag=tag,
                parse_dos=True,
                parse_eigen=True,
                parse_projected=True,
                settings={"verbose": verbose},
            )

            # Write/update the slabfy structure, if a file path is provided
            if structure_path:
                structure.write(structure_path)

            return vasp_results

        else:
            raise ValueError(
                f"{tag} Invalid method: {method!r}. Expected 'write' or 'read'."
            )

    def stm(
        self,
        structure: Union[Surface, Interface, Structure, str],
        method: Literal["write", "read"],
        dir_path: str | None = None,
        **kwargs,
    ):
        """Write or read a STM VASP calculation.

        REQUIRES: WAVECAR from a previous static calculation.

        Example of properties to return:
        - Simulated STM images
        """
        tag = "[VaspTools.stm]"
        _cfg = kwargs.get("settings", {})
        verbose = bool(_cfg.get("verbose", True)) if isinstance(_cfg, dict) else True

        # Check if WAVECAR exists in ``dir_path``
        if not os.path.exists(os.path.join(dir_path, "WAVECAR")):
            raise ValueError(
                f"{tag} Requires WAVECAR in ``dir_path`` from a previous static calculation."
            )

        structure_path = None
        if isinstance(structure, str):
            structure_path = structure
            structure = _read_slabfy_file(structure_path)
            if verbose:
                print(f"{tag} Read structure from file")

        if method == "write":
            # Import VASP set from `utils.SFY_SETTINGS`
            vasp_section = utils.SFY_SETTINGS.get("VASP", {})
            vasp_modifiers = vasp_section.get("VASP_MODIFIERS", {})
            stm_set = vasp_section.get("SETS", {}).get("STMSet", {})

            incar_settings = stm_set.get("INCAR", {})
            kpoints_settings = stm_set.get("KPOINTS", {})
            potcar_settings = stm_set.get("POTCAR", {})

            # Optimize `stm_set` for Surface and Interface calculations:
            if isinstance(structure, (Surface, Interface)):
                if structure.vacuum > utils.PHYS_CONSTANTS["MIN_VACUUM_SIZE"]:
                    vasp_modifiers["CORRECTIONS"] += ["Net-dipole"]
                    incar_settings["NELMDL"] = 2  # Improve slabs SCF-convergence
                else:
                    raise ValueError(
                        f"{tag} STM calculations require a minimum vacuum size."
                    )

            else:
                raise ValueError(
                    f"{tag} STM calculations support only Surface and Interface structures."
                )

            # Honor custom settings, if provided in **kwargs
            incar_settings = incar_settings | kwargs.get("incar_settings", {})
            kpoints_settings = kpoints_settings | kwargs.get("kpoints_settings", {})
            potcar_settings = potcar_settings | kwargs.get("potcar_settings", {})
            vasp_modifiers = vasp_modifiers | kwargs.get("vasp_modifiers", {})
            sbatch_config = kwargs.get("sbatch_config", {})

            # Call `_setup_run` with the merged settings
            vasp_setup = self._setup_run(
                structure=structure,
                incar_settings=incar_settings,
                kpoints_settings=kpoints_settings,
                potcar_settings=potcar_settings,
                vasp_modifiers=vasp_modifiers,
                sbatch_config=sbatch_config,
                dir_path=dir_path,
                settings={"verbose": verbose},
            )

            return vasp_setup

        elif method == "read":
            # Update the slabfy structure with the relaxed structure
            structure = _read_slabfy_file(os.path.join(dir_path, "CONTCAR"))

            # Parse the VASP calculation and update the slabfy structure
            vasp_results = self._parse_run(
                slabfy_obj=structure,
                dir_path=dir_path,
                method_tag=tag,
                parse_dos=True,
                parse_eigen=True,
                parse_projected=True,
                settings={"verbose": verbose},
            )

            # Write/update the slabfy structure, if a file path is provided
            if structure_path:
                structure.write(structure_path)

            return vasp_results

        else:
            raise ValueError(
                f"{tag} Invalid method: {method!r}. Expected 'write' or 'read'."
            )

    def nmr(
        self,
        structure: Union[Surface, Interface, Structure, str],
        method: Literal["write", "read"],
        dir_path: str | None = None,
        **kwargs,
    ):
        """Write or read a NMR VASP calculation.

        Example of properties to return:
        - NMR shifts
        - NRM shielding plot
        - NMR current plot
        """
        tag = "[VaspTools.nmr]"
        _cfg = kwargs.get("settings", {})
        verbose = bool(_cfg.get("verbose", True)) if isinstance(_cfg, dict) else True

        structure_path = None
        if isinstance(structure, str):
            structure_path = structure
            structure = _read_slabfy_file(structure_path)
            if verbose:
                print(f"{tag} Read structure from file")

        if method == "write":
            # Import VASP set from `utils.SFY_SETTINGS`
            vasp_section = utils.SFY_SETTINGS.get("VASP", {})
            vasp_modifiers = vasp_section.get("VASP_MODIFIERS", {})
            nmr_set = vasp_section.get("SETS", {}).get("NMRSet", {})

            incar_settings = nmr_set.get("INCAR", {})
            kpoints_settings = nmr_set.get("KPOINTS", {})
            potcar_settings = nmr_set.get("POTCAR", {})

            # Optimize `nmr_set` for Surface and Interface calculations:
            if isinstance(structure, (Surface, Interface)):
                incar_settings["LNICSALL"] = False
                incar_settings["LPOSNICS"] = True
                kpoints_settings["POSNICS"] = {
                    "GRID_SPACING": 0.2,
                    "PADDING": 1.5,
                }

                if structure.vacuum > utils.PHYS_CONSTANTS["MIN_VACUUM_SIZE"]:
                    vasp_modifiers["CORRECTIONS"] += ["Net-dipole"]
                    incar_settings["NELMDL"] = 2  # Improve slabs SCF-convergence

                else:
                    warnings.warn(
                        f"{tag} Vacuum is less than {utils.PHYS_CONSTANTS['MIN_VACUUM_SIZE']} Angstrom. "
                        f"No corrections for the vacuum region applied."
                    )

            # Honor custom settings, if provided in **kwargs
            incar_settings = incar_settings | kwargs.get("incar_settings", {})
            kpoints_settings = kpoints_settings | kwargs.get("kpoints_settings", {})
            potcar_settings = potcar_settings | kwargs.get("potcar_settings", {})
            vasp_modifiers = vasp_modifiers | kwargs.get("vasp_modifiers", {})
            sbatch_config = kwargs.get("sbatch_config", {})

            # Call `_setup_run` with the merged settings
            vasp_setup = self._setup_run(
                structure=structure,
                incar_settings=incar_settings,
                kpoints_settings=kpoints_settings,
                potcar_settings=potcar_settings,
                vasp_modifiers=vasp_modifiers,
                sbatch_config=sbatch_config,
                dir_path=dir_path,
                settings={"verbose": verbose},
            )

            return vasp_setup

        elif method == "read":
            # Update the slabfy structure with the relaxed structure
            structure = _read_slabfy_file(os.path.join(dir_path, "CONTCAR"))

            # Parse the VASP calculation - NMR doesn't need DOS/eigenvalue parsing
            vasp_results = self._parse_run(
                slabfy_obj=structure,
                dir_path=dir_path,
                method_tag=tag,
                parse_dos=False,
                parse_eigen=False,
                parse_projected=False,
                settings={"verbose": verbose},
            )

            # Bind NMR-specific properties
            internals._bind_report(
                vasp_results,
                structure,
                methods=["nmr"],
                _method_tag="nmr",
            )

            # Write/update the slabfy structure, if a file path is provided
            if structure_path:
                structure.write(structure_path)

            return vasp_results

        else:
            raise ValueError(
                f"{tag} Invalid method: {method!r}. Expected 'write' or 'read'."
            )


# TODO: LELF does not support KPAR parallelization -> Make it a custom dictionary that is read at the end of `_setup_run` to warn the user about conflicting INCAR flags
# TODO: Improve how `_bind_report` binds each VaspReport using a different key (`{method_tag}/{property_name}`?), so that we can easily track and gate methods that require previous calculations, e.g. `static` -> `carriers`
# TODO: Use py4vasp for plotting DOS, band structures, phonons, and optical properties.
# TODO: double check code related to thermal() and raman() methods in main slabfy so they can all moved to slabfy-addons. Needs to check how to integrate methods into `VaspReport` "on-the-fly"
