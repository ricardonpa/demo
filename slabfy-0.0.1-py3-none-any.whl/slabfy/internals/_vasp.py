"""
slabfy.internals._vasp
======================
Internal toolbox for slabfy.vasp — DO NOT import directly in user code.
Use ``from slabfy.vasp import ...`` instead.

Functions here may change without notice.

FUNCTION MAP
────────────
§1  Constants
    _VASP_OUTPUT_FILES, _PROPERTY_REGISTRY, _EV_ANG2_TO_J_M2,
    _CM1_TO_EV, _KB_EV, _EPS0_SI, _EV_TO_RADS, _HBAR2_OVER_ME

§2  Volumetric loader
    _load_volumetric

§3  Parsing helpers
    _probe_vasp_outputs, _detect_calc_type

§4  vasprun.xml parser
    _parse_vasprun_xml

§5  OUTCAR parser
    _parse_outcar

§6  LOCPOT parser
    _parse_locpot

§7  vaspout.h5 parser
    _parse_vaspout_h5, _h5_dict_to_structure

§8  Property-guard infrastructure
    _property_guard, _bind_report

§9  Derive helpers — Relax phase
    _derive_planar_potential,
    _derive_work_function, _derive_macroscopic_potential,
    _derive_vacuum_gradient, _derive_surface_dipole,
    _derive_band_gap, _derive_cart_displacements,
    _derive_layer_displacements, _derive_xrd, _derive_surface_bonds

§10 Derive helpers — Static phase (core)
    _has_d_block, _d_block_species, _derive_bader_charges,
    _derive_dband_moments, _derive_spband_center, _derive_layer_dos,
    _derive_band_structure_2d, _derive_ip_ea, _derive_local_moment,
    _derive_fermi_surface, _derive_xps

§11 Derive helpers — Static phase (extended)
    _is_spin_polarized, _derive_spin_polarization,
    _derive_magnetic_ordering, _derive_dos_fingerprint,
    _derive_hilbert_transform, _derive_core_level_energy,
    _derive_direct_band_gap, _derive_band_edges

§12 Derive helpers — Phonon phase
    _derive_zpe, _derive_vibrational_thermodynamics,
    _derive_surface_phonon_dos, _derive_mode_localisation

§13 Derive helpers — Optical phase
    _extract_dielectric_components, _derive_optical_spectra

§14 Derive helpers — Carrier phase
    _parabolic_effective_mass, _effective_mass_at_extremum,
    _derive_effective_mass

§15 Derive helpers — STM phase
    _tersoff_hamann_stm, _derive_stm_image

§16 Wannier90 parsers
    _parse_wannier90_wout, _parse_wannier90_hr, _parse_wannier90_band

§17 Wannier90 TB utilities
    _wannier_ham_k, _compute_wannier_dos, _compute_cohp

§18 Wannier90 derive helpers
    _derive_wannier_functions, _derive_wannier_bands,
    _derive_wannier_dos, _derive_wannier_cohp

NOTE: Thermal/QHA (phonopy) and Raman functions have been moved to
      slabfy-addons package. See: slabfy-addons/phonopy/ and slabfy-addons/raman_sc/
"""

from __future__ import annotations

import os
import warnings
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Union, Literal

import numpy as np

from pymatgen.core.structure import Structure
from pymatgen.io.vasp.inputs import Kpoints, Incar, Poscar
from pymatgen.io.vasp.outputs import Vasprun, Outcar
from pymatgen.symmetry.bandstructure import HighSymmKpath
from pymatgen.io.vasp.sets import VaspInputSet
from pymatgen.electronic_structure.dos import Dos, CompleteDos
from pymatgen.electronic_structure.bandstructure import (
    BandStructure,
    BandStructureSymmLine,
)
from pymatgen.electronic_structure.core import Spin

from slabfy.core import Surface, Interface

if TYPE_CHECKING:
    from slabfy.vasp import VaspReport

# ═══════════════════════════════════════════════════════════════
# §1  Constants
# ═══════════════════════════════════════════════════════════════

# ── VASP output file names ───────────────────────────────────
_VASP_OUTPUT_FILES: dict[str, str] = {
    "vaspout_h5": "vaspout.h5",
    "vasprun_xml": "vasprun.xml",
    "outcar": "OUTCAR",
    "chgcar": "CHGCAR",
    "aeccar0": "AECCAR0",
    "aeccar2": "AECCAR2",
    "elfcar": "ELFCAR",
    "locpot": "LOCPOT",
    "procar": "PROCAR",
    "eigenval": "EIGENVAL",
    "contcar": "CONTCAR",
    "doscar": "DOSCAR",
    "oszicar": "OSZICAR",
    "wavecar": "WAVECAR",
    "parchg": "PARCHG",
    "bxsf": "FERMISURFACE.bxsf",
    "wannier90_wout": "wannier90.wout",
    "wannier90_hr": "wannier90_hr.dat",
    "wannier90_band": "wannier90_band.dat",
    "wannier90_win": "wannier90.win",
    # NMR-related output files (VASP 6.6+)
    "nmr_current": "CURRENT",
    "nmr_chi": "CHI",
}

# ═══════════════════════════════════════════════════════════════
# §2  Volumetric loader
# ═══════════════════════════════════════════════════════════════

# ── Volumetric loader ────────────────────────────────────────


def _load_volumetric(
    results: VaspReport,
    quantity: Literal["charge_density", "elf"],
) -> Any:
    """Load volumetric data on demand from the calc directory.

    Parameters
    ----------
    results : VaspReport
        A previously parsed results object whose
        ``available_files`` tracks file paths.
    quantity : ``"charge_density"`` | ``"elf"``
        Which volumetric dataset to load.

    Returns
    -------
    Chgcar | Elfcar | None
        The parsed pymatgen volumetric object, or ``None``
        if the corresponding file was not found.
    """
    file_map = {
        "charge_density": "chgcar",
        "elf": "elfcar",
    }
    key = file_map.get(quantity)
    if key is None:
        raise ValueError(
            f"Unknown volumetric quantity: {quantity!r}. Choose from {list(file_map)}"
        )
    path = results.available_files.get(key)
    if not path or not os.path.isfile(path):
        return None

    from pymatgen.io.vasp.outputs import Chgcar, Elfcar

    loaders = {
        "chgcar": Chgcar.from_file,
        "elfcar": Elfcar.from_file,
    }
    return loaders[key](path)


# ═══════════════════════════════════════════════════════════════
# §3  Parsing helpers
# ═══════════════════════════════════════════════════════════════

# ═════════════════════════════════════════════════════════════
#  Module-level parsing helpers (organized per output file)
# ═════════════════════════════════════════════════════════════


def _probe_vasp_outputs(directory: str) -> dict[str, str]:
    """Detect which VASP output files exist in *directory*.

    Returns
    -------
    dict[str, str]
        ``{key: absolute_path}`` for every file found.
    """
    found: dict[str, str] = {}
    for key, fname in _VASP_OUTPUT_FILES.items():
        fpath = os.path.join(directory, fname)
        if os.path.isfile(fpath):
            found[key] = fpath
    return found


def _detect_calc_type(incar: dict) -> str:
    """Infer calculation type from INCAR parameters.

    Logic
    -----
    * NMR flags present          → ``"nmr"``
    * ``IBRION ∈ {5,6,7,8}``     → ``"vibration"``
    * ``LOPTICS = True``         → ``"optical"``
    * ``NSW > 0``  and
      ``IBRION ∈ {1,2,3,44}``    → ``"relaxation"``
    * otherwise                  → ``"static"``
    """
    ibrion = int(incar.get("IBRION", -1))
    nsw = int(incar.get("NSW", 0))
    loptics = incar.get("LOPTICS", False)

    # NMR detection (VASP 6.6+)
    if (
        incar.get("LNMR_SYM_RED")
        or incar.get("LNICSALL")
        or incar.get("LPOSNICS")
        or incar.get("LCHIMAG")
    ):
        return "nmr"

    if ibrion in {5, 6, 7, 8}:
        return "vibration"
    if loptics:
        return "optical"
    if nsw > 0 and ibrion in {1, 2, 3, 44}:
        return "relaxation"
    return "static"


# ═══════════════════════════════════════════════════════════════
# §4  vasprun.xml parser
# ═══════════════════════════════════════════════════════════════

# ── vasprun.xml ──────────────────────────────────────────────


def _parse_vasprun_xml(
    filepath: str,
    parse_dos: bool = True,
    parse_eigen: bool = True,
    parse_projected: bool = True,
) -> dict[str, Any]:
    """Extract all available data from *vasprun.xml*.

    Each key in the returned dict maps directly to a
    ``VaspReport`` field name.  Only keys with non-None
    values are included.
    """
    tag = "[_parse_vasprun_xml]"
    data: dict[str, Any] = {}

    try:
        with warnings.catch_warnings():
            warnings.filterwarnings(
                "ignore",
                category=UserWarning,
            )
            vr = Vasprun(
                filepath,
                parse_dos=parse_dos,
                parse_eigen=parse_eigen,
                parse_projected_eigen=parse_projected,
                exception_on_bad_xml=False,
            )
    except Exception as exc:
        warnings.warn(
            f"{tag} Failed to parse {filepath}: {exc}",
            stacklevel=2,
        )
        return data

    # ── structure ────────────────────────────────────
    data["structure"] = vr.final_structure
    data["initial_structure"] = vr.initial_structure
    if vr.nionic_steps > 1:
        data["trajectory"] = list(vr.structures)

    # ── energetics ───────────────────────────────────
    # Build a per-ionic-step list; [0] = initial, [-1] = final.
    energy_list: list[dict[str, float]] = []
    for ionic_step in vr.ionic_steps or []:
        e_sub = ionic_step.get("electronic_steps", [{}])[-1]
        entry: dict[str, float] = {}
        for vr_key, out_key in (
            ("e_fr_energy", "toten"),
            ("e_wo_entrp", "wo_entropy"),
            ("e_0_energy", "sigma0"),
        ):
            val = e_sub.get(vr_key)
            if val is not None:
                entry[out_key] = float(val)
        energy_list.append(entry)
    if energy_list:
        data["energy"] = energy_list

    last_step = vr.ionic_steps[-1] if vr.ionic_steps else {}
    # ── forces & stress (final step) ─────────────────
    if last_step.get("forces") is not None:
        data["forces"] = np.array(last_step["forces"])
    if last_step.get("stress") is not None:
        data["stress"] = np.array(last_step["stress"])

    # ── convergence ──────────────────────────────────
    data["converged_electronic"] = vr.converged_electronic
    data["converged_ionic"] = vr.converged_ionic
    data["converged"] = vr.converged_electronic and vr.converged_ionic

    # ── eigenvalues ──────────────────────────────────
    if vr.eigenvalues:
        data["eigenvalues"] = vr.eigenvalues

    # ── fermi energy ─────────────────────────────────
    data["fermi_energy"] = vr.efermi

    # ── DOS ──────────────────────────────────────────
    if parse_dos:
        try:
            cdos = vr.complete_dos
            if cdos is not None and not vr.dos_has_errors:
                data["dos"] = cdos
                data["tdos"] = vr.tdos
        except Exception:
            # Partial DOS may fail; fall back to total
            try:
                data["tdos"] = vr.tdos
            except Exception:
                pass

    # ── band structure ───────────────────────────────
    #    line-mode k-path → BandStructureSymmLine
    try:
        bs = vr.get_band_structure(line_mode=True)
        if bs is not None:
            data["band_structure"] = bs
    except Exception:
        # Not a line-mode run – try uniform mesh bandgap
        pass

    # ── bandgap from eigenvalue_band_properties ──────
    try:
        props = vr.eigenvalue_band_properties
        if props:
            data["bandgap"] = {
                "gap": props[0],
                "cbm": props[1],
                "vbm": props[2],
                "is_direct": props[3],
                "fermi_energy": vr.efermi,
            }
    except Exception:
        pass

    # ── dielectric & optical ─────────────────────────
    if vr.dielectric_data:
        data["dielectric_function"] = dict(vr.dielectric_data)
    eps_static = vr.epsilon_static
    eps_ionic = vr.epsilon_ionic
    if eps_static or eps_ionic:
        data["dielectric_tensor"] = {
            "epsilon_static": eps_static or None,
            "epsilon_ionic": eps_ionic or None,
            "epsilon_static_wolfe": (vr.epsilon_static_wolfe or None),
        }
    try:
        oac = vr.optical_absorption_coeff
        if oac:
            data["optical_absorption"] = oac
    except Exception:
        pass

    # ── vibration / phonon ───────────────────────────
    try:
        eigenvals = vr.normalmode_eigenvals
        eigenvecs = vr.normalmode_eigenvecs
        if eigenvals is not None:
            # Convert eigenvalues → frequencies (cm⁻¹)
            # pymatgen stores eigenvalues of the dynamical
            # matrix; some may be negative (imaginary modes).
            freqs = np.where(
                eigenvals >= 0,
                np.sqrt(np.abs(eigenvals)),
                -np.sqrt(np.abs(eigenvals)),
            )
            data["normal_modes"] = {
                "eigenvalues": eigenvals,
                "frequencies_cm-1": freqs,
                "eigenvectors": eigenvecs,
            }
    except Exception:
        pass

    try:
        fc = vr.force_constants
        if fc is not None:
            data["force_constants"] = np.array(fc)
    except Exception:
        pass

    # ── metadata ─────────────────────────────────────
    data["incar"] = dict(vr.incar)
    data["kpoints"] = vr.kpoints
    data["potcar_spec"] = vr.potcar_spec
    data["calc_type"] = _detect_calc_type(data["incar"])

    return {k: v for k, v in data.items() if v is not None}


# ═══════════════════════════════════════════════════════════════
# §5  OUTCAR parser
# ═══════════════════════════════════════════════════════════════

# ── OUTCAR ───────────────────────────────────────────────────


def _parse_outcar(filepath: str) -> dict[str, Any]:
    """Extract all available data from *OUTCAR*.

    Focuses on quantities not reliably available from
    vasprun.xml: per-ion magnetization/charge,
    electrostatic potential, energy decomposition, and
    run statistics.
    """
    tag = "[_parse_outcar]"
    data: dict[str, Any] = {}

    try:
        oc = Outcar(filepath)
    except Exception as exc:
        warnings.warn(
            f"{tag} Failed to parse {filepath}: {exc}",
            stacklevel=2,
        )
        return data

    # ── per-ion magnetization & charge ───────────────
    if oc.magnetization:
        data["magnetization"] = list(oc.magnetization)
    if oc.charge:
        data["charges"] = list(oc.charge)
    if hasattr(oc, "total_mag") and oc.total_mag is not None:
        data["total_mag"] = float(oc.total_mag)

    # ── electrostatic potential ──────────────────────
    if oc.electrostatic_potential:
        data["electrostatic_potential"] = list(
            oc.electrostatic_potential,
        )

    # ── energy decomposition ─────────────────────────
    if oc.final_energy_contribs:
        data["energy_contribs"] = dict(
            oc.final_energy_contribs,
        )

    # ── run statistics ───────────────────────────────
    if oc.run_stats:
        data["run_stats"] = dict(oc.run_stats)

    # ── Born effective charges (LEPSILON) ────────────
    try:
        lepsilon_data = oc.read_lepsilon()
        if lepsilon_data and "born" in lepsilon_data:
            data["born_effective_charges"] = np.array(lepsilon_data["born"])
    except Exception:
        pass

    return {k: v for k, v in data.items() if v is not None}


# ═══════════════════════════════════════════════════════════════
# §6  LOCPOT parser
# ═══════════════════════════════════════════════════════════════


def _parse_locpot(
    filepath: str,
    fermi_energy: float | None = None,
    lattice_vector: float | None = None,
) -> dict[str, Any]:
    """Parse LOCPOT for planar-averaged potential and work function.

    Parameters
    ----------
    filepath:
        Absolute path to the LOCPOT file.
    fermi_energy:
        Fermi energy (eV) from a companion vasprun.xml / OUTCAR.  When
        provided, the result dict also stores ``fermi_energy`` so that
        :func:`_derive_work_function` can compute Φ = V_vac − E_F.
    lattice_vector:
        Periodicity length (Å) along the c-axis corresponding to one
        bulk-like repeat unit.  Used as the rolling-mean window width
        when computing the macroscopic potential.  When *None* the value
        is estimated as ``lattice_c / n_formula_units``.

    Returns
    -------
    dict
        ``{"workfunction": {"distance": [...], "average_potential": [...],
        "vacuum_potential": float, "fermi_energy": float,
        "macroscopic_potential": [...], "gradient": [...]}}``
        The outer dict is empty on parse failure.
    """
    from pymatgen.io.vasp.outputs import Locpot  # lightweight lazy import

    data: dict[str, Any] = {}
    try:
        locpot = Locpot.from_file(filepath)
    except Exception as exc:
        warnings.warn(
            f"[_parse_locpot] Failed to read {filepath!r}: {exc}",
            stacklevel=2,
        )
        return data

    avg: np.ndarray = np.asarray(locpot.get_average_along_axis(2))
    lattice_c: float = locpot.structure.lattice.c
    distances: np.ndarray = np.linspace(
        0.0,
        lattice_c,
        len(avg),
        endpoint=False,
    )
    result: dict[str, Any] = {
        "distance": distances.tolist(),
        "average_potential": avg.tolist(),
        "vacuum_potential": float(np.max(avg)),
    }
    if fermi_energy is not None:
        result["fermi_energy"] = float(fermi_energy)

    # ── macroscopic potential (PBC rolling mean) ─────────────────────
    try:
        if lattice_vector is None:
            _, n_fu = locpot.structure.composition.get_reduced_composition_and_factor()
            lattice_vector = lattice_c / max(1.0, float(n_fu))
        dx = lattice_c / len(avg)
        window = max(1, round(lattice_vector / dx))
        # PBC wrap: pad `window` points on each side, then convolve
        padded = np.concatenate([avg[-window:], avg, avg[:window]])
        kernel = np.ones(window) / window
        macro_full = np.convolve(padded, kernel, mode="same")
        macro: np.ndarray = macro_full[window:-window]
        result["macroscopic_potential"] = macro.tolist()
        # ── gradient of planar potential (central difference, eV/Å) ──
        result["gradient"] = np.gradient(avg, dx).tolist()
    except Exception:
        pass  # non-fatal; macroscopic / gradient remain absent

    data["workfunction"] = result
    return data


# ═══════════════════════════════════════════════════════════════
# §7  vaspout.h5 parser
# ═══════════════════════════════════════════════════════════════

# ── vaspout.h5 (via py4vasp) ────────────────────────────────


def _parse_vaspout_h5(filepath: str) -> dict[str, Any]:
    """Extract all available data from *vaspout.h5*.

    Uses **py4vasp** as the HDF5 backend.  Each quantity
    is probed independently; failures are silently skipped
    so partial results are always returned.

    Returns
    -------
    dict[str, Any]
        Keys map to ``VaspReport`` field names.
    """
    tag = "[_parse_vaspout_h5]"
    data: dict[str, Any] = {}

    try:
        import py4vasp  # noqa: F811 — lazy optional dep
    except ImportError:
        warnings.warn(
            f"{tag} py4vasp not installed; skipping "
            f"HDF5 parsing.  Install with: "
            f"pip install py4vasp",
            stacklevel=2,
        )
        return data

    directory = os.path.dirname(filepath)
    try:
        calc = py4vasp.Calculation.from_path(directory)
    except Exception as exc:
        warnings.warn(
            f"{tag} Failed to open {filepath}: {exc}",
            stacklevel=2,
        )
        return data

    # ── helper: safe read ────────────────────────────
    def _read(attr: str) -> Any:
        """Try ``calc.<attr>.read()``, return None on fail."""
        try:
            return getattr(calc, attr).read()
        except Exception:
            return None

    # ── structure ────────────────────────────────────
    struct_raw = _read("structure")
    if struct_raw is not None:
        try:
            from pymatgen.io.ase import AseAtomsAdaptor

            atoms = calc.structure.to_ase()
            data["structure"] = AseAtomsAdaptor.get_structure(atoms)
        except Exception:
            # Fallback: build Structure from raw dict
            data["structure"] = _h5_dict_to_structure(
                struct_raw,
            )

    # ── energy ───────────────────────────────────────
    # vaspout.h5 stores only the final state; wrap as single-element list
    # so the schema matches vasprun.xml ([0]=initial, [-1]=final).
    energy_raw = _read("energy")
    if energy_raw and isinstance(energy_raw, dict):
        data["energy"] = [
            {
                "toten": float(
                    energy_raw.get(
                        "free energy    TOTEN",
                        energy_raw.get("toten", 0.0),
                    ),
                ),
                "wo_entropy": float(
                    energy_raw.get(
                        "energy without entropy",
                        0.0,
                    ),
                ),
                "sigma0": float(
                    energy_raw.get(
                        "energy(sigma->0)",
                        0.0,
                    ),
                ),
            }
        ]

    # ── forces ───────────────────────────────────────
    force_raw = _read("force")
    if force_raw and isinstance(force_raw, dict):
        forces = force_raw.get("forces")
        if forces is not None:
            data["forces"] = np.array(forces)

    # ── stress ───────────────────────────────────────
    stress_raw = _read("stress")
    if stress_raw and isinstance(stress_raw, dict):
        sv = stress_raw.get("stress")
        if sv is not None:
            data["stress"] = np.array(sv)

    # ── electronic convergence ───────────────────────
    em_raw = _read("electronic_minimization")
    if em_raw and isinstance(em_raw, dict):
        data["electronic_convergence"] = dict(em_raw)

    # ── bandgap ──────────────────────────────────────
    bg_raw = _read("bandgap")
    if bg_raw and isinstance(bg_raw, dict):
        data["bandgap"] = dict(bg_raw)

    # ── DOS (total only from HDF5) ───────────────────
    dos_raw = _read("dos")
    if dos_raw and isinstance(dos_raw, dict):
        try:
            energies = np.array(dos_raw["energies"])
            densities: dict[Spin, np.ndarray] = {}
            if "up" in dos_raw:
                densities[Spin.up] = np.array(
                    dos_raw["up"],
                )
            if "down" in dos_raw:
                densities[Spin.down] = np.array(
                    dos_raw["down"],
                )
            efermi = float(dos_raw.get("fermi_energy", 0.0))
            data["tdos"] = Dos(
                efermi=efermi,
                energies=energies,
                densities=densities,
            )
            data["fermi_energy"] = efermi
        except Exception:
            pass

    # ── workfunction ─────────────────────────────────
    wf_raw = _read("workfunction")
    if wf_raw and isinstance(wf_raw, dict):
        data["workfunction"] = dict(wf_raw)

    # ── magnetism ────────────────────────────────────
    mag_raw = _read("magnetism")
    if mag_raw and isinstance(mag_raw, dict):
        if "charges" in mag_raw:
            data["charges"] = mag_raw["charges"]
        if "moments" in mag_raw:
            data["magnetization"] = mag_raw["moments"]

    # ── dielectric function ──────────────────────────
    diel_fn = _read("dielectric_function")
    if diel_fn and isinstance(diel_fn, dict):
        data["dielectric_function"] = dict(diel_fn)

    # ── dielectric tensor ────────────────────────────
    diel_t = _read("dielectric_tensor")
    if diel_t and isinstance(diel_t, dict):
        data["dielectric_tensor"] = dict(diel_t)

    # ── Born effective charges ───────────────────────
    bec = _read("born_effective_charge")
    if bec is not None:
        if isinstance(bec, dict):
            data["born_effective_charges"] = bec
        else:
            data["born_effective_charges"] = np.array(bec)

    # ── force constants ──────────────────────────────
    fc = _read("force_constant")
    if fc is not None:
        if isinstance(fc, dict):
            data["force_constants"] = fc
        else:
            data["force_constants"] = np.array(fc)

    # ── polarization ─────────────────────────────────
    #    (stored if available, but no canonical field yet)

    # ── INCAR from HDF5 (for calc-type detection) ───
    try:
        import h5py

        with h5py.File(filepath, "r") as hf:
            incar_grp = hf.get("input/incar")
            if incar_grp is not None:
                incar_dict: dict[str, Any] = {}
                for key in incar_grp:
                    val = incar_grp[key][()]
                    if isinstance(val, bytes):
                        val = val.decode("utf-8").strip()
                    elif hasattr(val, "shape"):
                        if val.shape == ():
                            val = val.item()
                        else:
                            val = val.tolist()
                    incar_dict[key.upper()] = val
                data["incar"] = incar_dict
                data["calc_type"] = _detect_calc_type(
                    incar_dict,
                )
    except Exception:
        pass

    return {k: v for k, v in data.items() if v is not None}


def _h5_dict_to_structure(raw: dict) -> Structure:
    """Convert a py4vasp structure dict to pymatgen Structure.

    Parameters
    ----------
    raw : dict
        Output of ``calc.structure.read()`` with keys
        ``lattice_vectors``, ``positions``, ``elements``.

    Returns
    -------
    Structure
        pymatgen ``Structure`` built from fractional
        coordinates and lattice vectors.
    """
    from pymatgen.core.lattice import Lattice

    latt = Lattice(np.array(raw["lattice_vectors"]))
    coords = np.array(raw["positions"])
    species = raw["elements"]
    return Structure(
        lattice=latt,
        species=species,
        coords=coords,
        coords_are_cartesian=False,
    )


# ═══════════════════════════════════════════════════════════════
# §8  Property-guard infrastructure
# ═══════════════════════════════════════════════════════════════


# ── Property-guard infrastructure ────────────────────────────

_PROPERTY_REGISTRY: list[
    tuple[Callable, str, list[str], list[type] | None, list[Callable]]
] = []
"""Global registry: ``(helper, key, methods, object_types, requires)``."""


def _property_guard(
    key: str,
    methods: list[str],
    object_types: list[type] | None = None,
    requires: list[Callable] | None = None,
) -> Callable:
    """Register a ``_derive_*`` helper for :func:`_bind_report`.

    Parameters
    ----------
    key : str
        Property name (without method prefix).  Stored as
        ``f"{method_tag}/{key}"`` in ``slabfy_obj.properties_metadata``.
    methods : list[str]
        ``VaspTools`` method tags this helper fires for
        (e.g. ``["relax"]``, ``["relax", "static"]``).
    object_types : list[type] | None
        When set, the helper runs only for matching object
        types.  ``None`` → all types.
    requires : list[Callable] | None
        Predicate callables ``(slabfy_obj) -> bool``.  All must
        return truthy for the helper to run.
    """

    def decorator(fn: Callable) -> Callable:
        _PROPERTY_REGISTRY.append(
            (
                fn,
                key,
                methods,
                object_types,
                requires or [],
            )
        )
        return fn

    return decorator


def _bind_report(
    report: "VaspReport",
    slabfy_obj: Any,
    method_tag: str,
    **kwargs: Any,
) -> None:
    """Run all ``_derive_*`` helpers registered for *method_tag*.

    Iterates :data:`_PROPERTY_REGISTRY`, checks guards, calls
    each qualifying helper, and stores non-``None`` results in
    ``slabfy_obj.properties_metadata[f"{method_tag}/{key}"]``.

    Parameters
    ----------
    report : VaspReport
        Parsed VASP output data.
    slabfy_obj : Bulk | Adparticle | Surface | Interface
        Target object whose ``properties_metadata`` dict
        receives derived values.
    method_tag : str
        Identifies the calling ``VaspTools`` method
        (``"relax"``, ``"static"``, …).
    **kwargs
        Forwarded to each helper.
    """
    for fn, key, methods, obj_types, reqs in _PROPERTY_REGISTRY:
        if method_tag not in methods:
            continue
        if obj_types and not isinstance(slabfy_obj, tuple(obj_types)):
            continue
        if any(not req(slabfy_obj) for req in reqs):
            continue
        try:
            result = fn(
                report,
                slabfy_obj,
                _method_tag=method_tag,
                **kwargs,
            )
        except Exception:
            continue
        if result is not None:
            slabfy_obj.properties_metadata[f"{method_tag}/{key}"] = result


# ═══════════════════════════════════════════════════════════════
# §9  Derive helpers — Relax phase
# ═══════════════════════════════════════════════════════════════

# ── Derive helpers ───────────────────────────────────────────

# NOTE: _derive_surface_energy has been moved to slabfy.internals._analysis
# Surface energy computation is now calculator-agnostic and should be called
# via slabfy.internals._analysis.compute_surface_energy()


@_property_guard(
    key="planar_potential",
    methods=["relax", "static"],
)
def _derive_planar_potential(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> list[float] | None:
    """Return planar-averaged electrostatic potential along c.

    Returns a plain Python list (eV) or *None* if the
    workfunction data is absent from *report*.
    """
    wf = getattr(report, "workfunction", None)
    if not isinstance(wf, dict):
        return None
    avg = wf.get("average_potential")
    if avg is None:
        return None
    return avg if isinstance(avg, list) else list(avg)


@_property_guard(
    key="work_function_eV",
    methods=["relax", "static"],
    object_types=[Surface],
)
def _derive_work_function(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> float | None:
    """Φ = V_vac − E_F (eV), or *None* if data is unavailable."""
    wf = getattr(report, "workfunction", None)
    if not isinstance(wf, dict):
        return None
    vacuum_potential = wf.get("vacuum_potential")
    if vacuum_potential is None:
        return None
    fermi_energy = wf.get("fermi_energy") or getattr(
        report,
        "fermi_energy",
        None,
    )
    if fermi_energy is None:
        return None
    return float(vacuum_potential) - float(fermi_energy)


@_property_guard(
    key="macroscopic_potential",
    methods=["relax", "static"],
)
def _derive_macroscopic_potential(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> list[float] | None:
    """Return macroscopic-averaged potential (eV) along c.

    Stored in ``report.workfunction["macroscopic_potential"]``
    by :func:`_parse_locpot` (requires ``LVHAR = True``).
    """
    wf = getattr(report, "workfunction", None)
    if not isinstance(wf, dict):
        return None
    m = wf.get("macroscopic_potential")
    if m is None:
        return None
    return m if isinstance(m, list) else list(m)


@_property_guard(
    key="vacuum_gradient",
    methods=["relax"],
    object_types=[Surface],
)
def _derive_vacuum_gradient(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> float | None:
    """Mean |∂V/∂z| over the vacuum region (meV Å⁻¹).

    Identifies vacuum grid points as those where the planar-
    averaged potential is within 0.5 eV of the vacuum plateau
    value, then returns the average absolute gradient magnitude
    in meV Å⁻¹.  Returns *None* if required data are absent.
    """
    wf = getattr(report, "workfunction", None)
    if not isinstance(wf, dict):
        return None
    grad_raw = wf.get("gradient")
    avg_raw = wf.get("average_potential")
    vac = wf.get("vacuum_potential")
    if grad_raw is None or avg_raw is None or vac is None:
        return None
    grad_arr = np.asarray(grad_raw)
    avg_arr = np.asarray(avg_raw)
    mask = avg_arr >= (float(vac) - 0.5)
    if not np.any(mask):
        return None
    return float(
        np.mean(np.abs(grad_arr[mask])) * 1000.0,
    )  # meV/Å


@_property_guard(
    key="surface_dipole",
    methods=["relax"],
    object_types=[Surface],
)
def _derive_surface_dipole(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> float | None:
    """Δ macroscopic potential (eV) between vacuum plateaux.

    Estimates the lower vacuum level as the inter-quartile
    mean of the below-median values of the macroscopic
    potential and returns ``max(macro) − lower_mean``.
    Returns *None* if macroscopic potential data are absent.
    """
    wf = getattr(report, "workfunction", None)
    if not isinstance(wf, dict):
        return None
    m_raw = wf.get("macroscopic_potential")
    if m_raw is None:
        return None
    m = np.asarray(m_raw)
    median = float(np.median(m))
    lower = m[m < median]
    if len(lower) < 4:
        q25, q75 = np.quantile(m, [0.25, 0.75])
        lower_mean = float(
            np.mean(m[(m >= q25) & (m <= q75)]),
        )
    else:
        q25, q75 = np.quantile(lower, [0.25, 0.75])
        lower_mean = float(
            np.mean(lower[(lower >= q25) & (lower <= q75)]),
        )
    return round(float(np.max(m)) - lower_mean, 4)


@_property_guard(
    key="band_gap",
    methods=["relax", "static"],
)
def _derive_band_gap(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> float | None:
    """Fundamental band gap (eV) from eigenvalue analysis.

    Reads ``report.bandgap["gap"]`` populated by
    :func:`_parse_vasprun_xml`.  Returns *None* if
    unavailable.
    """
    bg = getattr(report, "bandgap", None)
    if not isinstance(bg, dict):
        return None
    val = bg.get("gap")
    return float(val) if val is not None else None


@_property_guard(
    key="cart_displacements",
    methods=["relax"],
)
def _derive_cart_displacements(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> list[dict[str, Any]] | None:
    """Per-atom Cartesian displacement (Å), initial → final.

    Returns a list of dicts with keys ``site_index`` (1-based),
    ``species``, ``c_frac``, ``displacement_ang``.
    Returns *None* if either structure is missing or atom
    counts differ.
    """
    start = getattr(report, "initial_structure", None)
    end = getattr(report, "structure", None)
    if start is None or end is None:
        return None
    if len(start) != len(end):
        return None
    out: list[dict[str, Any]] = []
    for i, (s_i, s_f) in enumerate(zip(start, end)):
        d = float(np.linalg.norm(s_f.coords - s_i.coords))
        out.append(
            {
                "site_index": i + 1,
                "species": str(s_i.specie),
                "c_frac": round(
                    float(s_i.frac_coords[2]),
                    6,
                ),
                "displacement_ang": round(d, 6),
            }
        )
    return out


@_property_guard(
    key="layer_displacements",
    methods=["relax"],
)
def _derive_layer_displacements(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> list[dict[str, Any]] | None:
    """Per-layer mean Cartesian displacement (Å) after relaxation.

    Groups atoms by their ``surface_axis_layers`` membership and
    returns one entry per layer (ordered top → bottom) with keys:
    ``layer_z``, ``species``, ``mean_displacement_ang``,
    ``max_displacement_ang``, ``n_atoms``.

    Requires ``slabfy_obj.surface_axis_layers`` and both initial/final
    structures on *report*.  Returns *None* if any are absent.
    """
    layers_map = getattr(slabfy_obj, "surface_axis_layers", None)
    if not layers_map or not isinstance(layers_map, dict):
        return None
    start = getattr(report, "initial_structure", None)
    end = getattr(report, "structure", None)
    if start is None or end is None:
        return None
    if len(start) != len(end):
        return None

    # Pre-compute per-atom displacements
    disp = np.array(
        [np.linalg.norm(s_f.coords - s_i.coords) for s_i, s_f in zip(start, end)]
    )

    # Build layer-z → site-index mapping using the same
    # projection logic as _axis_layers (c-axis).
    lattice_c = np.array(start.lattice.matrix[2], dtype=float)
    c_hat = lattice_c / np.linalg.norm(lattice_c)
    c_len = float(np.linalg.norm(lattice_c))
    projs = np.dot(
        start.cart_coords.astype(float),
        c_hat,
    )
    projs_shifted = projs - projs.min()
    projs_norm = np.mod(projs_shifted, c_len)
    tol = 1e-6
    projs_norm[np.abs(projs_norm - c_len) <= tol] = 0.0
    projs_norm[np.abs(projs_norm) <= tol] = 0.0

    # Match each atom to the nearest layer key
    layer_keys = sorted(layers_map.keys(), reverse=True)
    results: list[dict[str, Any]] = []
    for lz in layer_keys:
        indices = [
            i
            for i in range(len(start))
            if abs(round(float(projs_norm[i]), 6) - lz) < 0.01
        ]
        if not indices:
            continue
        d_layer = disp[indices]
        results.append(
            {
                "layer_z": lz,
                "species": layers_map[lz],
                "mean_displacement_ang": round(
                    float(np.mean(d_layer)),
                    6,
                ),
                "max_displacement_ang": round(
                    float(np.max(d_layer)),
                    6,
                ),
                "n_atoms": len(indices),
            }
        )
    return results if results else None


@_property_guard(
    key="xrd",
    methods=["relax", "static"],
)
def _derive_xrd(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> dict[str, Any] | None:
    """Simulated powder XRD pattern from the final structure.

    Uses ``pymatgen.analysis.diffraction.xrd.XRDCalculator``
    (Cu Kα, 2θ range 10°–90°).  Returns a dict with keys
    ``two_theta``, ``intensity``, ``hkls`` or *None* if the
    final structure is absent.
    """
    struct = getattr(report, "structure", None)
    if struct is None:
        struct = getattr(slabfy_obj, "slab", None)
    if struct is None:
        return None
    try:
        from pymatgen.analysis.diffraction.xrd import (
            XRDCalculator,
        )

        calc = XRDCalculator(wavelength="CuKa")
        pattern = calc.get_pattern(struct)
        return {
            "two_theta": [round(x, 4) for x in pattern.x],
            "intensity": [round(float(y), 4) for y in pattern.y],
            "hkls": [
                [
                    {
                        "hkl": h["hkl"],
                        "multiplicity": h["multiplicity"],
                    }
                    for h in group
                ]
                for group in pattern.hkls
            ],
        }
    except Exception:
        return None


@_property_guard(
    key="surface_bonds",
    methods=["relax"],
    object_types=[Surface],
)
def _derive_surface_bonds(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> list[dict[str, Any]] | None:
    """Nearest-neighbour bond distances for top-layer atoms.

    Uses ``CrystalNN`` to identify coordination environments
    for atoms in the topmost layer (highest c-fractional
    coordinate layer).  Returns a list of dicts with keys
    ``site_index``, ``species``, ``neighbors`` (list of
    ``{species, distance_ang}``).

    Returns *None* if the structure or layer data is absent.
    """
    struct = getattr(report, "structure", None)
    if struct is None:
        struct = getattr(slabfy_obj, "slab", None)
    if struct is None:
        return None
    layers_map = getattr(slabfy_obj, "surface_axis_layers", None)
    if not layers_map or not isinstance(layers_map, dict):
        return None

    # Top layer = highest z key in ordered dict
    top_z = max(layers_map.keys())

    # Identify sites in the top layer by c-frac proximity
    top_indices: list[int] = []
    lattice_c = np.array(struct.lattice.matrix[2], dtype=float)
    c_hat = lattice_c / np.linalg.norm(lattice_c)
    c_len = float(np.linalg.norm(lattice_c))
    projs = np.dot(struct.cart_coords.astype(float), c_hat)
    projs_shifted = projs - projs.min()
    projs_norm = np.mod(projs_shifted, c_len)
    tol = 1e-6
    projs_norm[np.abs(projs_norm - c_len) <= tol] = 0.0
    projs_norm[np.abs(projs_norm) <= tol] = 0.0
    for i in range(len(struct)):
        if abs(round(float(projs_norm[i]), 6) - top_z) < 0.01:
            top_indices.append(i)

    if not top_indices:
        return None

    try:
        from pymatgen.analysis.local_env import CrystalNN

        cnn = CrystalNN()
        results: list[dict[str, Any]] = []
        for idx in top_indices:
            info = cnn.get_nn_info(struct, idx)
            neighbors = [
                {
                    "species": str(nn["site"].specie),
                    "distance_ang": round(
                        float(
                            nn["site"].distance(
                                struct[idx],
                            )
                        ),
                        4,
                    ),
                }
                for nn in info
            ]
            results.append(
                {
                    "site_index": idx + 1,
                    "species": str(struct[idx].specie),
                    "neighbors": neighbors,
                }
            )
        return results if results else None
    except Exception:
        return None


# ═══════════════════════════════════════════════════════════════
# §10  Derive helpers — Static phase (core)
# ═══════════════════════════════════════════════════════════════

# ── Phase 2: static-core helpers (S6–S26) ────────────────────


def _has_d_block(slabfy_obj: Any) -> bool:
    """Return *True* if the slab contains d-block elements."""
    from pymatgen.core.periodic_table import Element

    slab = getattr(slabfy_obj, "slab", None)
    if slab is None:
        return False
    return any(Element(str(sp)).block == "d" for sp in slab.composition.elements)


def _d_block_species(struct: Structure) -> list[str]:
    """Return d-block species symbols present in *struct*."""
    from pymatgen.core.periodic_table import Element

    return [
        str(sp) for sp in struct.composition.elements if Element(str(sp)).block == "d"
    ]


@_property_guard(
    key="bader_charges",
    methods=["static"],
)
def _derive_bader_charges(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> list[dict[str, Any]] | None:
    """Per-atom Bader charges from CHGCAR + AECCAR0/2.

    Requires the ``bader`` binary in PATH and AECCAR
    files from a ``LAECHG=.TRUE.`` run.  Returns a list
    of ``{site_index, species, charge}`` dicts or *None*.
    """
    avail = getattr(report, "available_files", {})
    chgcar = avail.get("chgcar")
    aeccar0 = avail.get("aeccar0")
    aeccar2 = avail.get("aeccar2")
    if not all([chgcar, aeccar0, aeccar2]):
        return None
    try:
        from pymatgen.command_line.bader_caller import (
            BaderAnalysis,
        )

        ba = BaderAnalysis(
            chgcar_filename=chgcar,
            potcar_filename=None,
            chgref_filename=aeccar0,
        )
        struct = getattr(report, "structure", None)
        if struct is None:
            struct = getattr(slabfy_obj, "slab", None)
        if struct is None:
            return None
        results: list[dict[str, Any]] = []
        for i, chg in enumerate(ba.charges):
            results.append(
                {
                    "site_index": i + 1,
                    "species": str(struct[i].specie),
                    "charge": round(float(chg), 6),
                }
            )
        return results if results else None
    except Exception:
        return None


@_property_guard(
    key="dband_center_eV",
    methods=["static"],
    requires=[_has_d_block],
)
def _derive_dband_moments(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> float | None:
    """D-band statistical moments (center, width, skew, kurt, fill).

    Computes first four central moments of the d-projected DOS
    for each d-block species and stores per-species dicts in
    ``properties_metadata`` under five keys.  The primary
    return value is the composition-weighted d-band center (eV).

    Stores additional keys via direct assignment:
    ``dband_width_eV``, ``dband_skewness``, ``dband_kurtosis``,
    ``dband_filling``.
    """
    dos = getattr(report, "dos", None)
    if dos is None:
        return None
    struct = getattr(report, "structure", None)
    if struct is None:
        struct = getattr(slabfy_obj, "slab", None)
    if struct is None:
        return None

    from pymatgen.electronic_structure.core import (
        OrbitalType,
        Spin,
    )

    d_species = _d_block_species(struct)
    if not d_species:
        return None

    energies = np.array(dos.energies) - dos.efermi
    centers: dict[str, float] = {}
    widths: dict[str, float] = {}
    skewnesses: dict[str, float] = {}
    kurtoses: dict[str, float] = {}
    fillings: dict[str, float] = {}

    for sp_str in d_species:
        # Sum d-DOS over all sites of this species
        d_dos_arr = np.zeros_like(energies, dtype=float)
        for site in struct:
            if str(site.specie) != sp_str:
                continue
            try:
                spd = dos.get_site_spd_dos(site)
            except Exception:
                continue
            d_dos_obj = spd.get(OrbitalType.d)
            if d_dos_obj is None:
                continue
            for spin_key in d_dos_obj.densities:
                d_dos_arr += np.array(
                    d_dos_obj.densities[spin_key],
                    dtype=float,
                )
        total = np.trapezoid(d_dos_arr, energies)
        if total < 1e-12:
            continue
        # Moments
        norm = d_dos_arr / total
        mu1 = float(np.trapezoid(norm * energies, energies))
        var = float(
            np.trapezoid(norm * (energies - mu1) ** 2, energies),
        )
        sigma = max(np.sqrt(var), 1e-12)
        skew = float(
            np.trapezoid(
                norm * ((energies - mu1) / sigma) ** 3,
                energies,
            ),
        )
        kurt = float(
            np.trapezoid(
                norm * ((energies - mu1) / sigma) ** 4,
                energies,
            ),
        )
        # Filling: integral up to E_F (energy=0)
        mask = energies <= 0.0
        fill = (
            float(
                np.trapezoid(d_dos_arr[mask], energies[mask]),
            )
            / total
        )

        centers[sp_str] = round(mu1, 6)
        widths[sp_str] = round(sigma, 6)
        skewnesses[sp_str] = round(skew, 6)
        kurtoses[sp_str] = round(kurt, 6)
        fillings[sp_str] = round(fill, 6)

    if not centers:
        return None

    # Store extra keys on obj directly
    method_tag = kw.get("_method_tag", "static")
    slabfy_obj.properties_metadata[f"{method_tag}/dband_width_eV"] = widths
    slabfy_obj.properties_metadata[f"{method_tag}/dband_skewness"] = skewnesses
    slabfy_obj.properties_metadata[f"{method_tag}/dband_kurtosis"] = kurtoses
    slabfy_obj.properties_metadata[f"{method_tag}/dband_filling"] = fillings

    return centers


@_property_guard(
    key="spband_center_eV",
    methods=["static"],
)
def _derive_spband_center(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> dict[str, float] | None:
    """Composition-weighted s/p-band center (eV) per element.

    Computes the first moment of the combined s+p projected
    DOS for each element.  Useful for oxide/nitride surfaces
    where the anion p-band position matters.
    """
    dos = getattr(report, "dos", None)
    if dos is None:
        return None
    struct = getattr(report, "structure", None)
    if struct is None:
        struct = getattr(slabfy_obj, "slab", None)
    if struct is None:
        return None

    from pymatgen.electronic_structure.core import OrbitalType

    energies = np.array(dos.energies) - dos.efermi
    results: dict[str, float] = {}

    for sp in struct.composition.elements:
        sp_str = str(sp)
        sp_dos = np.zeros_like(energies, dtype=float)
        for site in struct:
            if str(site.specie) != sp_str:
                continue
            try:
                spd = dos.get_site_spd_dos(site)
            except Exception:
                continue
            for orb_type in (OrbitalType.s, OrbitalType.p):
                orb_dos = spd.get(orb_type)
                if orb_dos is None:
                    continue
                for spin_key in orb_dos.densities:
                    sp_dos += np.array(
                        orb_dos.densities[spin_key],
                        dtype=float,
                    )
        total = np.trapezoid(sp_dos, energies)
        if total < 1e-12:
            continue
        norm = sp_dos / total
        mu = float(np.trapezoid(norm * energies, energies))
        results[sp_str] = round(mu, 6)

    return results if results else None


@_property_guard(
    key="layer_dos",
    methods=["static"],
)
def _derive_layer_dos(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> dict[str, Any] | None:
    """Layer-resolved DOS: site-projected DOS summed per layer.

    Groups sites by ``slabfy_obj.surface_axis_layers`` and sums
    per-site DOS within each layer.  Returns a dict keyed
    by layer z-value (as string) with sub-keys ``energies``
    and ``densities`` (spin-resolved arrays).
    """
    dos = getattr(report, "dos", None)
    if dos is None:
        return None
    layers_map = getattr(slabfy_obj, "surface_axis_layers", None)
    if not layers_map or not isinstance(layers_map, dict):
        return None
    struct = getattr(report, "structure", None)
    if struct is None:
        struct = getattr(slabfy_obj, "slab", None)
    if struct is None:
        return None
    if len(struct) == 0:
        return None

    energies = np.array(dos.energies) - dos.efermi

    # Map each atom to its layer key
    lattice_c = np.array(struct.lattice.matrix[2], dtype=float)
    c_hat = lattice_c / np.linalg.norm(lattice_c)
    c_len = float(np.linalg.norm(lattice_c))
    projs = np.dot(struct.cart_coords.astype(float), c_hat)
    projs_shifted = projs - projs.min()
    projs_norm = np.mod(projs_shifted, c_len)
    tol = 1e-6
    projs_norm[np.abs(projs_norm - c_len) <= tol] = 0.0
    projs_norm[np.abs(projs_norm) <= tol] = 0.0

    layer_keys = sorted(layers_map.keys(), reverse=True)
    result: dict[str, Any] = {}

    for lz in layer_keys:
        indices = [
            i
            for i in range(len(struct))
            if abs(round(float(projs_norm[i]), 6) - lz) < 0.01
        ]
        if not indices:
            continue
        # Sum site DOS over this layer
        layer_dens: dict[str, list[float]] = {}
        for idx in indices:
            try:
                site_dos = dos.get_site_dos(struct[idx])
            except Exception:
                continue
            for spin_key in site_dos.densities:
                sk = str(spin_key)
                arr = np.array(
                    site_dos.densities[spin_key],
                    dtype=float,
                )
                if sk not in layer_dens:
                    layer_dens[sk] = arr.tolist()
                else:
                    layer_dens[sk] = (np.array(layer_dens[sk]) + arr).tolist()
        if layer_dens:
            result[str(lz)] = {
                "energies": [round(float(e), 6) for e in energies],
                "densities": layer_dens,
            }

    return result if result else None


@_property_guard(
    key="band_structure_2d",
    methods=["static"],
    object_types=[Surface],
)
def _derive_band_structure_2d(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> dict[str, Any] | None:
    """2D band structure info from the standard BS object.

    Extracts in-plane high-symmetry labels and eigenvalue
    data from the existing ``report.band_structure``.
    Returns a dict with ``kpoints``, ``eigenvalues``,
    ``efermi``, ``labels`` or *None*.
    """
    bs = getattr(report, "band_structure", None)
    if bs is None:
        return None
    try:
        kpts = [[round(float(c), 6) for c in k.frac_coords] for k in bs.kpoints]
        eigs: dict[str, list] = {}
        for spin_key, bands in bs.bands.items():
            eigs[str(spin_key)] = [[round(float(e), 6) for e in band] for band in bands]
        labels: list[dict[str, Any]] = []
        for i, lbl in enumerate(bs.kpoints):
            if lbl.label:
                labels.append(
                    {
                        "index": i,
                        "label": lbl.label,
                    }
                )
        return {
            "kpoints": kpts,
            "eigenvalues": eigs,
            "efermi": round(float(bs.efermi), 6),
            "labels": labels,
        }
    except Exception:
        return None


@_property_guard(
    key="ionisation_potential_eV",
    methods=["static"],
    object_types=[Surface],
)
def _derive_ip_ea(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> float | None:
    """Ionisation potential and electron affinity (eV).

    IP = E_vac − VBM, EA = E_vac − CBM.
    Requires ``report.workfunction`` (vacuum potential)
    and ``report.bandgap`` (VBM/CBM).

    The primary return stores IP; EA is assigned to
    ``electron_affinity_eV`` via direct metadata write.
    """
    wf = getattr(report, "workfunction", None)
    bg = getattr(report, "bandgap", None)
    if wf is None or bg is None:
        return None
    e_vac = wf.get("vacuum_potential")
    if e_vac is None:
        return None
    # VBM and CBM from bandgap dict
    vbm = bg.get("vbm")
    cbm = bg.get("cbm")
    if vbm is None:
        return None
    ip = round(float(e_vac) - float(vbm), 6)
    # Store EA if CBM available
    if cbm is not None:
        ea = round(float(e_vac) - float(cbm), 6)
        method_tag = kw.get("_method_tag", "static")
        slabfy_obj.properties_metadata[f"{method_tag}/electron_affinity_eV"] = ea
    return ip


@_property_guard(
    key="local_moment",
    methods=["static"],
)
def _derive_local_moment(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> list[dict[str, Any]] | None:
    """Per-atom local magnetic moment from magnetization data.

    Extracts the total local magnetic moment for each ion
    from ``report.magnetization``.  Returns a list of
    ``{site_index, species, moment}`` dicts.
    """
    mag = getattr(report, "magnetization", None)
    if not mag:
        return None
    struct = getattr(report, "structure", None)
    if struct is None:
        struct = getattr(slabfy_obj, "slab", None)
    if struct is None:
        return None
    results: list[dict[str, Any]] = []
    for i, m in enumerate(mag):
        if i >= len(struct):
            break
        # magnetization entries are dicts with orbital keys
        if isinstance(m, dict):
            tot = m.get("tot", 0.0)
        else:
            tot = float(m)
        results.append(
            {
                "site_index": i + 1,
                "species": str(struct[i].specie),
                "moment": round(float(tot), 6),
            }
        )
    return results if results else None


@_property_guard(
    key="fermi_surface_file",
    methods=["static"],
)
def _derive_fermi_surface(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> str | None:
    """Path to FermiSurfer-compatible .bxsf file (metals only).

    Returns the path if a BXSF file exists in the calc
    directory or *None*.  Only meaningful for metals
    (zero band gap).
    """
    bg = getattr(report, "bandgap", None)
    if isinstance(bg, dict):
        gap_val = bg.get("gap", 1.0)
        if gap_val is not None and float(gap_val) > 0.01:
            return None
    avail = getattr(report, "available_files", {})
    bxsf = avail.get("bxsf")
    if bxsf and os.path.isfile(bxsf):
        return bxsf
    return None


@_property_guard(
    key="xps_spectrum",
    methods=["static"],
)
def _derive_xps(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> dict[str, Any] | None:
    """Simulated XPS spectrum via galore (optional dep).

    Requires ``galore`` to be installed and a
    ``CompleteDos`` on the report.  Returns a dict with
    ``energies`` and ``intensity`` arrays.
    """
    dos = getattr(report, "dos", None)
    if dos is None:
        return None
    try:
        import galore
        import galore.process

        tdos = dos
        energies = np.array(tdos.energies) - tdos.efermi
        # Sum all spin channels for total DOS
        total_dens = np.zeros_like(energies, dtype=float)
        for spin_key in tdos.densities:
            total_dens += np.array(
                tdos.densities[spin_key],
                dtype=float,
            )
        xps_data = galore.process.process_pdos(
            input_data=np.column_stack([energies, total_dens]),
            gaussian=0.3,
            lorentzian=0.2,
            xmin=float(energies.min()),
            xmax=0.0,
        )
        return {
            "energies": [round(float(x), 4) for x in xps_data[:, 0]],
            "intensity": [round(float(y), 4) for y in xps_data[:, 1]],
        }
    except Exception:
        return None


# ═══════════════════════════════════════════════════════════════
# §11  Derive helpers — Static phase (extended)
# ═══════════════════════════════════════════════════════════════


def _is_spin_polarized(slabfy_obj: Any) -> bool:
    """Check if ISPIN=2 by inspecting typical spin markers."""
    # The guard is checked at runtime by _bind_report
    return True  # actual ISPIN check is in helper body


@_property_guard(
    key="spin_polarization",
    methods=["static"],
)
def _derive_spin_polarization(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> float | None:
    """Spin polarisation at the Fermi level.

    Uses ``CompleteDos.spin_polarization`` property.
    Returns *None* for non-spin-polarised calculations.
    """
    dos = getattr(report, "dos", None)
    if dos is None:
        return None
    incar = getattr(report, "incar", None)
    if isinstance(incar, dict):
        ispin = incar.get("ISPIN", 1)
        if int(ispin) < 2:
            return None
    try:
        sp = dos.spin_polarization
        if sp is None:
            return None
        return round(float(sp), 6)
    except Exception:
        return None


@_property_guard(
    key="magnetic_ordering",
    methods=["static"],
)
def _derive_magnetic_ordering(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> dict[str, Any] | None:
    """Magnetic ordering analysis from CollinearMagneticStructureAnalyzer.

    Identifies FM, AFM, FiM, or NM ordering.  Only runs
    for ISPIN=2 calculations.  Returns a dict with
    ``ordering``, ``total_magnetization``,
    ``magnetic_species``.
    """
    incar = getattr(report, "incar", None)
    if isinstance(incar, dict):
        ispin = incar.get("ISPIN", 1)
        if int(ispin) < 2:
            return None
    struct = getattr(report, "structure", None)
    if struct is None:
        struct = getattr(slabfy_obj, "slab", None)
    if struct is None:
        return None
    mag = getattr(report, "magnetization", None)
    if not mag:
        return None
    try:
        from pymatgen.analysis.magnetism.analyzer import (
            CollinearMagneticStructureAnalyzer,
        )

        # Build a structure with magnetic moments
        moments = []
        for m in mag:
            if isinstance(m, dict):
                moments.append(float(m.get("tot", 0.0)))
            else:
                moments.append(float(m))
        mag_struct = struct.copy()
        mag_struct.add_site_property("magmom", moments)
        analyzer = CollinearMagneticStructureAnalyzer(
            mag_struct,
        )
        ordering = str(analyzer.ordering.value)
        mag_species = [str(sp) for sp in analyzer.types_of_magnetic_species]
        total_mag = getattr(report, "total_mag", None)
        return {
            "ordering": ordering,
            "total_magnetization": (
                round(float(total_mag), 6) if total_mag is not None else None
            ),
            "magnetic_species": mag_species,
        }
    except Exception:
        return None


@_property_guard(
    key="dos_fingerprint",
    methods=["static"],
)
def _derive_dos_fingerprint(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> dict[str, Any] | None:
    """DOS fingerprint via ``CompleteDos.get_dos_fp()``.

    Returns a dict with ``type``, ``n_bins``, ``energies``,
    ``densities`` for the summed pDOS fingerprint.
    """
    dos = getattr(report, "dos", None)
    if dos is None:
        return None
    try:
        fp = dos.get_dos_fp(
            fp_type="summed_pdos",
            binning=True,
            n_bins=256,
            normalize=True,
        )
        return {
            "type": "summed_pdos",
            "n_bins": fp.n_bins,
            "energies": [round(float(e), 6) for e in fp.energies],
            "densities": [round(float(d), 6) for d in fp.densities],
        }
    except Exception:
        return None


@_property_guard(
    key="hilbert_transform",
    methods=["static"],
    requires=[_has_d_block],
)
def _derive_hilbert_transform(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> dict[str, Any] | None:
    """Hilbert transform of d-band DOS (Newns–Anderson model).

    Computes the chemisorption function Δ(ε) = −Im[Σ(ε)]
    and the upper band edge from the d-projected DOS.
    Stores ``upper_band_edge_eV`` as extra key.
    """
    dos = getattr(report, "dos", None)
    if dos is None:
        return None
    struct = getattr(report, "structure", None)
    if struct is None:
        struct = getattr(slabfy_obj, "slab", None)
    if struct is None:
        return None

    from pymatgen.electronic_structure.core import OrbitalType

    d_species = _d_block_species(struct)
    if not d_species:
        return None

    energies = np.array(dos.energies) - dos.efermi
    d_dos_total = np.zeros_like(energies, dtype=float)

    for sp_str in d_species:
        for site in struct:
            if str(site.specie) != sp_str:
                continue
            try:
                spd = dos.get_site_spd_dos(site)
            except Exception:
                continue
            d_dos_obj = spd.get(OrbitalType.d)
            if d_dos_obj is None:
                continue
            for spin_key in d_dos_obj.densities:
                d_dos_total += np.array(
                    d_dos_obj.densities[spin_key],
                    dtype=float,
                )

    total = np.trapezoid(d_dos_total, energies)
    if total < 1e-12:
        return None

    try:
        from scipy.signal import hilbert as sp_hilbert

        analytic = sp_hilbert(d_dos_total)
        ht_imag = np.imag(analytic)

        # Upper band edge: highest energy where d-DOS > 5%
        threshold = 0.05 * d_dos_total.max()
        above = np.where(d_dos_total > threshold)[0]
        upper_edge = round(float(energies[above[-1]]), 6) if len(above) > 0 else None

        method_tag = kw.get("_method_tag", "static")
        if upper_edge is not None:
            slabfy_obj.properties_metadata[f"{method_tag}/upper_band_edge_eV"] = (
                upper_edge
            )

        return {
            "energies": [round(float(e), 6) for e in energies],
            "chemisorption_function": [round(float(v), 6) for v in (-ht_imag)],
            "d_dos": [round(float(v), 6) for v in d_dos_total],
        }
    except Exception:
        return None


@_property_guard(
    key="core_level_eV",
    methods=["static"],
)
def _derive_core_level_energy(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> list[dict[str, Any]] | None:
    """Core-level eigenvalues from OUTCAR (ICORELEVEL=1).

    Uses ``Outcar.read_core_state_eigen()`` when the
    OUTCAR is available.  Returns a list of per-atom dicts
    with core state energies.
    """
    avail = getattr(report, "available_files", {})
    outcar_path = avail.get("outcar")
    if not outcar_path:
        return None
    try:
        oc = Outcar(outcar_path)
        core_eigen = oc.read_core_state_eigen()
        if not core_eigen:
            return None
        struct = getattr(report, "structure", None)
        if struct is None:
            struct = getattr(slabfy_obj, "slab", None)
        results: list[dict[str, Any]] = []
        for i, atom_data in enumerate(core_eigen):
            species = (
                str(struct[i].specie)
                if struct is not None and i < len(struct)
                else f"atom_{i}"
            )
            results.append(
                {
                    "site_index": i + 1,
                    "species": species,
                    "core_states": atom_data,
                }
            )
        return results if results else None
    except Exception:
        return None


@_property_guard(
    key="direct_band_gap_eV",
    methods=["static"],
)
def _derive_direct_band_gap(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> float | None:
    """Direct band gap (eV) from band structure.

    Uses ``BandStructure.get_direct_band_gap()`` if a
    band structure object is available.
    """
    bs = getattr(report, "band_structure", None)
    if bs is None:
        return None
    try:
        gap = bs.get_direct_band_gap()
        if gap is None:
            return None
        return round(float(gap), 6)
    except Exception:
        return None


@_property_guard(
    key="band_edges",
    methods=["static"],
)
def _derive_band_edges(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> dict[str, Any] | None:
    """VBM/CBM k-points and metal detection from band structure.

    Uses ``BandStructure.get_vbm()``, ``get_cbm()``,
    and ``is_metal()``.
    """
    bs = getattr(report, "band_structure", None)
    if bs is None:
        return None
    try:
        is_metal = bs.is_metal()
        vbm_data = bs.get_vbm()
        cbm_data = bs.get_cbm()

        # Extract frac_coords for VBM if available
        vbm_kpt = vbm_data.get("kpoint")
        vbm_coords = vbm_kpt.frac_coords.tolist() if vbm_kpt else []

        # Extract frac_coords for CBM if available
        cbm_kpt = cbm_data.get("kpoint")
        cbm_coords = cbm_kpt.frac_coords.tolist() if cbm_kpt else []

        return {
            "is_metal": is_metal,
            "vbm": {
                "energy": round(
                    float(vbm_data["energy"]),
                    6,
                ),
                "kpoint_index": vbm_data.get(
                    "kpoint_index",
                    [],
                ),
                "kpoint_coords": vbm_coords,
                "band_index": vbm_data.get(
                    "band_index",
                    {},
                ),
            },
            "cbm": {
                "energy": round(
                    float(cbm_data["energy"]),
                    6,
                ),
                "kpoint_index": cbm_data.get(
                    "kpoint_index",
                    [],
                ),
                "kpoint_coords": cbm_coords,
                "band_index": cbm_data.get(
                    "band_index",
                    {},
                ),
            },
        }
    except Exception:
        return None


# ═══════════════════════════════════════════════════════════════
# §12  Derive helpers — Phonon phase
# ═══════════════════════════════════════════════════════════════

# ── Phase 4: phonon helpers (Ph4–Ph9) ────────────────────────

# cm⁻¹ → eV conversion factor: h·c·(100 cm/m) / e
_CM1_TO_EV: float = 1.2398419843320026e-4
"""1 cm⁻¹ expressed in eV."""

# Boltzmann constant in eV/K
_KB_EV: float = 8.617333262145179e-5
"""Boltzmann constant k_B in eV K⁻¹."""


@_property_guard(
    key="zpe_eV",
    methods=["phonons"],
)
def _derive_zpe(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> float | None:
    """Zero-point energy (eV): ZPE = Σ ½ℏω_i over real modes.

    Only real-frequency modes (positive frequencies) contribute.
    Imaginary modes (negative frequencies from the sign convention
    in ``_parse_vasprun_xml``) are excluded.
    """
    nm = getattr(report, "normal_modes", None)
    if not isinstance(nm, dict):
        return None
    freqs = nm.get("frequencies_cm-1")
    if freqs is None:
        return None
    freqs_arr = np.asarray(freqs, dtype=float)
    real_mask = freqs_arr > 0.0
    if not np.any(real_mask):
        return None
    real_freqs_eV = freqs_arr[real_mask] * _CM1_TO_EV
    zpe = float(0.5 * np.sum(real_freqs_eV))
    return round(zpe, 6)


@_property_guard(
    key="vib_entropy",
    methods=["phonons"],
)
def _derive_vibrational_thermodynamics(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> dict[str, list[float]] | None:
    """Vibrational thermodynamics: S_vib(T), F_vib(T), C_v(T).

    Evaluated at T = 100, 200, 300, 400, 500, 600, 700, 800,
    900, 1000 K using the quantum harmonic oscillator partition
    function.  Only real-frequency modes contribute.

    Primary return is the entropy dict (stored as
    ``phonons/vib_entropy``).  ``vib_free_energy`` and
    ``vib_Cv`` are stored as extra keys.

    Each value is a dict ``{temperatures: [...], values: [...]}``.
    Entropy in eV/K, free energy in eV, heat capacity in eV/K.
    """
    nm = getattr(report, "normal_modes", None)
    if not isinstance(nm, dict):
        return None
    freqs = nm.get("frequencies_cm-1")
    if freqs is None:
        return None
    freqs_arr = np.asarray(freqs, dtype=float)
    real_mask = freqs_arr > 0.0
    if not np.any(real_mask):
        return None
    real_eV = freqs_arr[real_mask] * _CM1_TO_EV

    temps = [100, 200, 300, 400, 500, 600, 700, 800, 900, 1000]
    s_vals: list[float] = []
    f_vals: list[float] = []
    cv_vals: list[float] = []

    for T in temps:
        kT = _KB_EV * T
        s_total = 0.0
        f_total = 0.0
        cv_total = 0.0
        for hw in real_eV:
            x = hw / kT
            # Avoid overflow for very large x
            if x > 500.0:
                f_total += 0.5 * hw
                continue
            exp_x = np.exp(x)
            bose = 1.0 / (exp_x - 1.0)
            # Entropy per mode: k_B [x/(e^x-1) - ln(1-e^{-x})]
            s_total += _KB_EV * (x * bose - np.log(1.0 - np.exp(-x)))
            # Free energy per mode: ½ℏω + k_B T ln(1-e^{-x})
            f_total += 0.5 * hw + kT * np.log(1.0 - np.exp(-x))
            # Heat capacity per mode: k_B x² e^x / (e^x-1)²
            cv_total += _KB_EV * x**2 * exp_x / (exp_x - 1.0) ** 2
        s_vals.append(round(s_total, 8))
        f_vals.append(round(f_total, 6))
        cv_vals.append(round(cv_total, 8))

    method_tag = kw.get("_method_tag", "phonons")
    slabfy_obj.properties_metadata[f"{method_tag}/vib_free_energy"] = {
        "temperatures_K": temps,
        "values_eV": f_vals,
    }
    slabfy_obj.properties_metadata[f"{method_tag}/vib_Cv"] = {
        "temperatures_K": temps,
        "values_eV_per_K": cv_vals,
    }

    return {
        "temperatures_K": temps,
        "values_eV_per_K": s_vals,
    }


@_property_guard(
    key="surface_phonon_dos",
    methods=["phonons"],
)
def _derive_surface_phonon_dos(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> dict[str, Any] | None:
    """Gaussian-broadened phonon DOS from Γ-point frequencies.

    Broadens the discrete normal-mode frequencies with a
    Gaussian kernel (σ = 5 cm⁻¹) on a 0–max_freq grid.
    Returns ``{frequencies_cm1: [...], dos: [...]}``.
    """
    nm = getattr(report, "normal_modes", None)
    if not isinstance(nm, dict):
        return None
    freqs = nm.get("frequencies_cm-1")
    if freqs is None:
        return None
    freqs_arr = np.asarray(freqs, dtype=float)
    real_mask = freqs_arr > 0.0
    if not np.any(real_mask):
        return None
    real_freqs = freqs_arr[real_mask]

    sigma = 5.0  # cm⁻¹ broadening
    f_max = float(np.max(real_freqs)) + 10.0 * sigma
    grid = np.linspace(0.0, f_max, 500)
    dos = np.zeros_like(grid)
    for f in real_freqs:
        dos += np.exp(-0.5 * ((grid - f) / sigma) ** 2)
    dos /= sigma * np.sqrt(2.0 * np.pi)

    return {
        "frequencies_cm-1": [round(float(g), 2) for g in grid],
        "dos": [round(float(d), 6) for d in dos],
    }


@_property_guard(
    key="surface_modes",
    methods=["phonons"],
    object_types=[Surface],
)
def _derive_mode_localisation(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> list[dict[str, Any]] | None:
    """Identify surface-localised vibrational modes.

    A mode is surface-localised when > 50 % of its squared
    displacement is concentrated in the top N layers (default
    N = 2).  Uses ``slabfy_obj.surface_axis_layers`` to identify
    top-layer atoms.

    Returns a list of dicts ``{mode_index, frequency_cm1,
    surface_fraction}`` for qualifying modes.
    """
    nm = getattr(report, "normal_modes", None)
    if not isinstance(nm, dict):
        return None
    freqs = nm.get("frequencies_cm-1")
    eigvecs = nm.get("eigenvectors")
    if freqs is None or eigvecs is None:
        return None
    freqs_arr = np.asarray(freqs, dtype=float)
    eigvecs_arr = np.asarray(eigvecs, dtype=float)

    # Need structure and layer map to identify surface atoms
    struct = getattr(report, "structure", None)
    if struct is None:
        struct = getattr(slabfy_obj, "slab", None)
    if struct is None:
        return None
    layers_map = getattr(slabfy_obj, "surface_axis_layers", None)
    if not layers_map or not isinstance(layers_map, dict):
        return None

    # Top 2 layers by z-value
    n_top_layers = 2
    layer_keys = sorted(layers_map.keys(), reverse=True)
    top_keys = layer_keys[:n_top_layers]

    # Map atom indices to surface membership
    lattice_c = np.array(
        struct.lattice.matrix[2],
        dtype=float,
    )
    c_hat = lattice_c / np.linalg.norm(lattice_c)
    c_len = float(np.linalg.norm(lattice_c))
    projs = np.dot(struct.cart_coords.astype(float), c_hat)
    projs_shifted = projs - projs.min()
    projs_norm = np.mod(projs_shifted, c_len)
    tol = 1e-6
    projs_norm[np.abs(projs_norm - c_len) <= tol] = 0.0
    projs_norm[np.abs(projs_norm) <= tol] = 0.0

    surface_idx = set()
    for i in range(len(struct)):
        z_val = round(float(projs_norm[i]), 6)
        for tk in top_keys:
            if abs(z_val - tk) < 0.01:
                surface_idx.add(i)
                break

    if not surface_idx:
        return None

    # Analyse each mode
    threshold = 0.5
    results: list[dict[str, Any]] = []
    n_modes = len(freqs_arr)
    for m in range(n_modes):
        if freqs_arr[m] <= 0.0:
            continue
        # eigvecs shape: (n_modes, n_atoms, 3) or flat
        if eigvecs_arr.ndim == 3:
            mode_disp = eigvecs_arr[m]
        elif eigvecs_arr.ndim == 2:
            n_atoms = len(struct)
            mode_disp = eigvecs_arr[m].reshape(n_atoms, 3)
        else:
            continue
        sq_disp = np.sum(mode_disp**2, axis=1)
        total_sq = float(np.sum(sq_disp))
        if total_sq < 1e-12:
            continue
        surf_sq = float(
            sum(sq_disp[i] for i in surface_idx),
        )
        frac = surf_sq / total_sq
        if frac >= threshold:
            results.append(
                {
                    "mode_index": m,
                    "frequency_cm-1": round(
                        float(freqs_arr[m]),
                        2,
                    ),
                    "surface_fraction": round(frac, 4),
                }
            )

    return results if results else None


# ═══════════════════════════════════════════════════════════════
# §13  Derive helpers — Optical phase
# ═══════════════════════════════════════════════════════════════

# ── Phase 5: optical helpers (O4–O10) ────────────────────────

# Vacuum permittivity in C²·s²/(kg·m³) – only used for σ(ω)
_EPS0_SI: float = 8.8541878128e-12
"""ε₀ in F m⁻¹."""

# eV → angular frequency (rad/s): ω = E / ℏ
_EV_TO_RADS: float = 1.519267447e15
"""1 eV / ℏ in rad s⁻¹."""


def _extract_dielectric_components(
    diel_fn: dict,
) -> tuple[np.ndarray, np.ndarray, np.ndarray] | None:
    """Return ``(energies, eps1_avg, eps2_avg)`` from VaspReport.

    The dielectric_function field is
    ``{tag: (energies, real_tensor, imag_tensor), ...}``.
    Each tensor row is ``[xx, yy, zz, xy, yz, xz]``.
    We average diagonal components (xx, yy, zz) at each
    energy point.  Returns ``None`` if data is unusable.
    """
    if not isinstance(diel_fn, dict) or not diel_fn:
        return None
    # Prefer 'freq_dependent', fall back to 'density'
    key = "freq_dependent" if "freq_dependent" in diel_fn else next(iter(diel_fn))
    entry = diel_fn[key]
    if not isinstance(entry, (list, tuple)) or len(entry) < 3:
        return None
    energies_, real_, imag_ = entry[0], entry[1], entry[2]
    energies = np.asarray(energies_, dtype=float)
    real_arr = np.asarray(real_, dtype=float)
    imag_arr = np.asarray(imag_, dtype=float)
    if real_arr.ndim != 2 or imag_arr.ndim != 2:
        return None
    # Diagonal average: columns 0 (xx), 1 (yy), 2 (zz)
    eps1 = np.mean(real_arr[:, :3], axis=1)
    eps2 = np.mean(imag_arr[:, :3], axis=1)
    return energies, eps1, eps2


@_property_guard(
    key="refractive_index",
    methods=["optical"],
)
def _derive_optical_spectra(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> dict[str, list[float]] | None:
    """Optical spectra from dielectric function ε(ω).

    Derives n(ω), k(ω), R(ω), σ(ω), EELS, optical gap,
    and static dielectric constant.  The primary key is
    ``refractive_index``; the remaining 6 keys are stored
    as extra keys via ``_method_tag``.

    Formulas
    --------
    ε₁, ε₂ are the real/imaginary parts of ε averaged over
    diagonal tensor components (xx, yy, zz).

    n  = √(½(√(ε₁² + ε₂²) + ε₁))
    k  = √(½(√(ε₁² + ε₂²) − ε₁))
    R  = ((n − 1)² + k²) / ((n + 1)² + k²)
    σ  = ε₂ · ω · ε₀   (SI: S/m)
    EELS = ε₂ / (ε₁² + ε₂²)
    """
    diel_fn = getattr(report, "dielectric_function", None)
    result = _extract_dielectric_components(diel_fn)
    if result is None:
        return None
    energies, eps1, eps2 = result
    if len(energies) < 2:
        return None

    # ── n(ω), k(ω) ──────────────────────────────────
    mod_eps = np.sqrt(eps1**2 + eps2**2)
    n_real = np.sqrt(
        np.clip(0.5 * (mod_eps + eps1), 0.0, None),
    )
    k_ext = np.sqrt(
        np.clip(0.5 * (mod_eps - eps1), 0.0, None),
    )

    # ── R(ω) ─────────────────────────────────────────
    reflectivity = ((n_real - 1.0) ** 2 + k_ext**2) / ((n_real + 1.0) ** 2 + k_ext**2)

    # ── σ(ω) (optical conductivity, S/m) ────────────
    omega_rad = energies * _EV_TO_RADS
    sigma_opt = eps2 * omega_rad * _EPS0_SI

    # ── EELS = Im(-1/ε) = ε₂/(ε₁² + ε₂²) ──────────
    denom = eps1**2 + eps2**2
    safe_denom = np.where(denom > 1e-20, denom, 1e-20)
    eels = eps2 / safe_denom

    # ── Optical gap: first energy where ε₂ > threshold
    optical_gap: float | None = None
    threshold = 0.1  # ε₂ threshold for gap onset
    above = np.where(
        (eps2 > threshold) & (energies > 0.1),
    )[0]
    if len(above) > 0:
        optical_gap = round(float(energies[above[0]]), 4)

    # ── Static dielectric constant: ε₁(ω → 0) ──────
    static_eps: float | None = None
    if len(eps1) > 0:
        static_eps = round(float(eps1[0]), 4)

    # Build rounded lists for storage
    def _to_list(arr: np.ndarray) -> list[float]:
        return [round(float(v), 6) for v in arr]

    energy_list = _to_list(energies)
    method_tag = kw.get("_method_tag", "optical")

    # Store extra keys
    slabfy_obj.properties_metadata[f"{method_tag}/extinction_coefficient"] = {
        "energies_eV": energy_list,
        "values": _to_list(k_ext),
    }

    slabfy_obj.properties_metadata[f"{method_tag}/reflectivity"] = {
        "energies_eV": energy_list,
        "values": _to_list(reflectivity),
    }

    slabfy_obj.properties_metadata[f"{method_tag}/optical_conductivity"] = {
        "energies_eV": energy_list,
        "values_S_per_m": _to_list(sigma_opt),
    }

    slabfy_obj.properties_metadata[f"{method_tag}/eels"] = {
        "energies_eV": energy_list,
        "values": _to_list(eels),
    }

    slabfy_obj.properties_metadata[f"{method_tag}/optical_gap_eV"] = optical_gap

    slabfy_obj.properties_metadata[f"{method_tag}/static_dielectric_constant"] = (
        static_eps
    )

    # Primary return: refractive index
    return {
        "energies_eV": energy_list,
        "values": _to_list(n_real),
    }


# ═══════════════════════════════════════════════════════════════
# §14  Derive helpers — Carrier phase
# ═══════════════════════════════════════════════════════════════

# ── Phase 6: carrier helpers (C1–C4) ────────────────────────

# ℏ² / mₑ in eV·Å² (k in Å⁻¹, E in eV → m*/mₑ)
_HBAR2_OVER_ME: float = 7.619964221937169
"""ℏ²/mₑ in eV·Å².  m* = _HBAR2_OVER_ME / (d²E/dk²)."""


def _parabolic_effective_mass(
    k_cart: np.ndarray,
    energies: np.ndarray,
    extremum_idx: int,
) -> np.ndarray | None:
    """3-point parabolic ∂²E/∂k² along each Cartesian axis.

    Given a set of k-points (Cartesian, Å⁻¹) and energies (eV)
    along a band, estimate the curvature tensor at *extremum_idx*
    using finite central differences on the nearest neighbours
    in each Cartesian direction.

    Returns a (3,) array of effective masses in electron-mass
    units (one per Cartesian axis), or ``None`` if there are
    too few k-points.
    """
    n_kpts = len(k_cart)
    if n_kpts < 3 or extremum_idx < 1 or extremum_idx >= n_kpts - 1:
        return None

    masses = np.zeros(3)
    k0 = k_cart[extremum_idx]
    e0 = energies[extremum_idx]

    for ax in range(3):
        # Neighbours in k-space along axis `ax`
        dk_fwd = k_cart[extremum_idx + 1, ax] - k0[ax]
        dk_bwd = k_cart[extremum_idx - 1, ax] - k0[ax]
        e_fwd = energies[extremum_idx + 1]
        e_bwd = energies[extremum_idx - 1]

        # Central difference: d²E/dk² ≈ (E₊ - 2E₀ + E₋) / (Δk)²
        dk = 0.5 * (abs(dk_fwd) + abs(dk_bwd))
        if dk < 1e-12:
            masses[ax] = float("inf")
            continue
        d2e = (e_fwd - 2.0 * e0 + e_bwd) / dk**2
        if abs(d2e) < 1e-12:
            masses[ax] = float("inf")
        else:
            masses[ax] = _HBAR2_OVER_ME / d2e

    return masses


def _effective_mass_at_extremum(
    bs: Any,
    extremum_info: dict,
    spin: Any,
) -> dict[str, Any] | None:
    """Compute effective mass at a band extremum (VBM or CBM).

    Parameters
    ----------
    bs : BandStructureSymmLine
        Band structure with ``.bands``, ``.kpoints``,
        ``.lattice_rec``.
    extremum_info : dict
        Output of ``bs.get_vbm()`` or ``bs.get_cbm()``.
    spin : Spin
        Spin channel to use.

    Returns
    -------
    dict | None
        ``{scalar_mass, principal_masses, dos_effective_mass}``
        or ``None`` if insufficient data.
    """
    kpt_indices = extremum_info.get("kpoint_index")
    band_indices = extremum_info.get("band_index", {})
    if not kpt_indices or spin not in band_indices:
        return None
    if not band_indices[spin]:
        return None

    ki = kpt_indices[0]
    bi = band_indices[spin][0]

    bands_arr = bs.bands[spin]  # (n_bands, n_kpts)
    if bands_arr.ndim != 2:
        return None
    n_kpts = bands_arr.shape[1]
    if ki < 1 or ki >= n_kpts - 1:
        return None

    # Cartesian k-points (Å⁻¹)
    k_cart = np.array(
        [kp.cart_coords for kp in bs.kpoints],
        dtype=float,
    )
    energies = bands_arr[bi]

    masses = _parabolic_effective_mass(k_cart, energies, ki)
    if masses is None:
        return None

    # Scalar mass: average of finite principal masses
    finite = masses[np.isfinite(masses)]
    if len(finite) == 0:
        return None
    scalar = float(np.mean(finite))

    # DOS effective mass: (|m1*m2*m3|)^(1/3)
    #   Use only finite masses; if any axis is inf, skip it
    if len(finite) == 3:
        dos_mass = float(
            np.cbrt(abs(finite[0] * finite[1] * finite[2])),
        )
    else:
        dos_mass = float(np.mean(np.abs(finite)))

    return {
        "scalar_m_star": round(scalar, 4),
        "principal_masses": [
            round(float(m), 4) if np.isfinite(m) else None for m in masses
        ],
        "dos_effective_mass": round(dos_mass, 4),
    }


@_property_guard(
    key="cbm_effective_mass",
    methods=["carriers"],
)
def _derive_effective_mass(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> dict[str, Any] | None:
    """Effective masses at VBM and CBM via parabolic fitting.

    Primary key: ``cbm_effective_mass``.  Extra keys:
    ``vbm_effective_mass``, ``effective_mass_tensor``,
    ``dos_effective_mass``.

    Requires ``report.band_structure`` with a non-metallic gap.
    Uses 3-point central-difference ∂²E/∂k² around VBM/CBM
    k-points.
    """
    bs = getattr(report, "band_structure", None)
    if bs is None:
        return None
    if bs.is_metal():
        return None

    from pymatgen.electronic_structure.core import Spin

    spin = Spin.up
    cbm_info = bs.get_cbm()
    vbm_info = bs.get_vbm()

    cbm_result = _effective_mass_at_extremum(
        bs,
        cbm_info,
        spin,
    )
    vbm_result = _effective_mass_at_extremum(
        bs,
        vbm_info,
        spin,
    )

    method_tag = kw.get("_method_tag", "carriers")

    # Store VBM effective mass
    slabfy_obj.properties_metadata[f"{method_tag}/vbm_effective_mass"] = vbm_result

    # Store tensor (combined CBM + VBM principal masses)
    tensor_data: dict[str, Any] = {}
    if cbm_result:
        tensor_data["cbm"] = cbm_result["principal_masses"]
    if vbm_result:
        tensor_data["vbm"] = vbm_result["principal_masses"]
    slabfy_obj.properties_metadata[f"{method_tag}/effective_mass_tensor"] = (
        tensor_data if tensor_data else None
    )

    # Store DOS effective mass (combined)
    dos_data: dict[str, float | None] = {
        "cbm": (cbm_result["dos_effective_mass"] if cbm_result else None),
        "vbm": (vbm_result["dos_effective_mass"] if vbm_result else None),
    }
    slabfy_obj.properties_metadata[f"{method_tag}/dos_effective_mass"] = dos_data

    return cbm_result


# ═══════════════════════════════════════════════════════════════
# §15  Derive helpers — STM phase
# ═══════════════════════════════════════════════════════════════

# ── Phase 7: STM helpers (T1–T3) ────────────────────────────


def _tersoff_hamann_stm(
    charge_grid: np.ndarray,
    lattice_matrix: np.ndarray,
    frac_coords: np.ndarray,
    height_ang: float = 2.0,
    current_iso: float = 1e-4,
) -> dict[str, Any]:
    """Tersoff–Hamann STM from a 3-D charge-density grid.

    Parameters
    ----------
    charge_grid : np.ndarray
        3-D partial charge density ρ(x, y, z) on the FFT
        grid.  Shape ``(nx, ny, nz)``.
    lattice_matrix : np.ndarray
        (3, 3) lattice vectors (rows), Å.
    frac_coords : np.ndarray
        (N, 3) fractional coordinates of all atoms.
    height_ang : float
        Height above the topmost atom (Å) for the
        constant-height slice.
    current_iso : float
        Charge-density isosurface value (e/Å³) for the
        constant-current height map.

    Returns
    -------
    dict
        ``constant_height``  — dict with ``x``, ``y``
        (1-D, Å) and ``image`` (2-D).
        ``constant_current`` — dict with ``x``, ``y``
        (1-D, Å) and ``z_map`` (2-D, Å) or ``None``
        if the isosurface is not crossed.
    """
    nx, ny, nz = charge_grid.shape
    c_vec = lattice_matrix[2]
    c_len = float(np.linalg.norm(c_vec))

    # Topmost atom fractional z
    z_max_frac = float(np.max(frac_coords[:, 2]))

    # Target fractional z for constant-height
    target_frac = z_max_frac + height_ang / c_len
    # Wrap into [0, 1)
    target_frac = target_frac % 1.0
    # Map to nearest grid index
    iz = int(round(target_frac * nz)) % nz

    # Constant-height image: 2-D slice at iz
    ch_image = charge_grid[:, :, iz].copy()

    # Real-space x / y axes
    a_len = float(np.linalg.norm(lattice_matrix[0]))
    b_len = float(np.linalg.norm(lattice_matrix[1]))
    x_axis = np.linspace(0, a_len, nx, endpoint=False)
    y_axis = np.linspace(0, b_len, ny, endpoint=False)

    result: dict[str, Any] = {
        "constant_height": {
            "x": x_axis,
            "y": y_axis,
            "image": ch_image,
            "height_ang": height_ang,
            "grid_index_z": iz,
        },
    }

    # Constant-current: for each (ix, iy), scan z
    # from top down to find where ρ crosses current_iso.
    z_frac = np.linspace(0, 1, nz, endpoint=False)
    z_cart = z_frac * c_len  # cartesian z values
    z_map = np.full((nx, ny), np.nan)

    for ix in range(nx):
        for iy in range(ny):
            column = charge_grid[ix, iy, :]
            # Walk from topmost-atom grid index downward
            # (wrap if needed).
            start = int(round(z_max_frac * nz)) % nz
            for step in range(nz):
                k = (start - step) % nz
                if column[k] >= current_iso:
                    z_map[ix, iy] = z_cart[k]
                    break

    cc_valid = bool(np.any(np.isfinite(z_map)))
    result["constant_current"] = (
        {
            "x": x_axis,
            "y": y_axis,
            "z_map": z_map if cc_valid else None,
            "current_iso": current_iso,
        }
        if cc_valid
        else None
    )

    return result


@_property_guard(
    key="stm_constant_height",
    methods=["stm"],
    object_types=[Surface],
)
def _derive_stm_image(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> dict[str, Any] | None:
    """Simulated STM images from partial charge density.

    Primary key: ``stm_constant_height``.  Extra keys:
    ``stm_constant_current``, ``partial_charge``.

    Loads PARCHG (flat file) from the calculation directory
    via ``report.available_files``.  Falls back to py4vasp
    HDF5 if ``vaspwave.h5`` is available.

    Uses the Tersoff–Hamann approximation: tunnelling
    current ∝ local density of states ≈ partial charge
    density integrated over [E_F − eV, E_F].
    """
    avail = getattr(report, "available_files", {})
    parchg_path = avail.get("parchg")
    directory = getattr(report, "directory", None)

    chgcar_obj = None

    # Strategy 1: flat-file PARCHG via pymatgen
    if parchg_path is not None:
        try:
            from pymatgen.io.vasp.outputs import Chgcar

            chgcar_obj = Chgcar.from_file(parchg_path)
        except Exception:
            chgcar_obj = None

    # Strategy 2: py4vasp HDF5 (vaspwave.h5)
    if chgcar_obj is None and directory is not None:
        try:
            import py4vasp

            calc = py4vasp.Calculation.from_path(
                directory,
            )
            raw = calc.partial_charge.to_dict()
            # py4vasp returns a dict; wrap as Chgcar-like
            from pymatgen.io.vasp.outputs import Chgcar

            struct = getattr(report, "structure", None) or getattr(
                slabfy_obj, "slab", None
            )
            if struct is not None and "charge" in raw:
                chgcar_obj = Chgcar(
                    struct,
                    {"total": np.array(raw["charge"])},
                )
        except Exception:
            pass

    if chgcar_obj is None:
        return None

    grid = chgcar_obj.data.get("total")
    if grid is None or grid.ndim != 3:
        return None

    struct = chgcar_obj.structure
    lat = np.array(struct.lattice.matrix)
    frac = np.array([s.frac_coords for s in struct])

    stm = _tersoff_hamann_stm(
        charge_grid=grid,
        lattice_matrix=lat,
        frac_coords=frac,
        height_ang=2.0,
        current_iso=1e-4,
    )

    method_tag = kw.get("_method_tag", "stm")

    # Store constant-current image
    slabfy_obj.properties_metadata[f"{method_tag}/stm_constant_current"] = stm.get(
        "constant_current"
    )

    # Store partial charge metadata (grid shape, source)
    slabfy_obj.properties_metadata[f"{method_tag}/partial_charge"] = {
        "grid_shape": list(grid.shape),
        "source": ("PARCHG" if parchg_path is not None else "vaspwave.h5"),
    }

    return stm["constant_height"]


# ═══════════════════════════════════════════════════════════════
# §16  Wannier90 parsers
# ═══════════════════════════════════════════════════════════════

# ── Wannier90 parsers ────────────────────────────────────────


def _parse_wannier90_wout(path: str | Path) -> dict | None:
    """Parse ``wannier90.wout`` for WF centres and spreads.

    Parameters
    ----------
    path : str | Path
        Path to ``wannier90.wout``.

    Returns
    -------
    dict | None
        ``{"centres": list[list[float]], "spreads": list[float]}``
        or ``None`` if parsing fails.
    """
    path = Path(path)
    if not path.is_file():
        return None

    centres: list[list[float]] = []
    spreads: list[float] = []
    in_final = False

    try:
        with open(path, "r") as fh:
            for line in fh:
                if "Final State" in line:
                    in_final = True
                    continue
                if not in_final:
                    continue
                # Lines like:
                # WF centre and target centre:
                #   WF cu.    1    (  0.123,  0.456,  0.789 ), Spr =  1.234
                stripped = line.strip()
                if stripped.startswith("WF cu."):
                    # Extract centre from parentheses
                    lp = stripped.index("(")
                    rp = stripped.index(")")
                    xyz = [float(v) for v in stripped[lp + 1 : rp].split(",")]
                    # Extract spread after "Spr ="
                    spr_idx = stripped.index("Spr =")
                    spread = float(stripped[spr_idx + 5 :].strip())
                    centres.append(xyz)
                    spreads.append(spread)
                # Stop after "Sum of centres" line
                if in_final and "Sum of centres" in line:
                    break
    except (OSError, ValueError):
        return None

    if not centres:
        return None

    return {"centres": centres, "spreads": spreads}


def _parse_wannier90_hr(path: str | Path) -> dict | None:
    """Parse ``wannier90_hr.dat`` for the real-space Hamiltonian.

    The file format (Wannier90 convention)::

        header line
        n_wann
        n_rpts
        degeneracy weights (multi-line, 15 per line)
        R1x R1y R1z  m  n  Re(H)  Im(H)
        ...

    Parameters
    ----------
    path : str | Path
        Path to ``wannier90_hr.dat``.

    Returns
    -------
    dict | None
        ``{"n_wann": int, "n_rpts": int, "degeneracy": list,
        "rvec": list, "hr_real": list, "hr_imag": list}``
        or ``None`` if parsing fails.
    """
    path = Path(path)
    if not path.is_file():
        return None

    try:
        with open(path, "r") as fh:
            _header = fh.readline()  # noqa: F841
            n_wann = int(fh.readline().strip())
            n_rpts = int(fh.readline().strip())

            # Degeneracy weights: 15 per line
            deg: list[int] = []
            while len(deg) < n_rpts:
                deg.extend(int(x) for x in fh.readline().split())

            rvec: list[list[int]] = []
            hr_real: list[float] = []
            hr_imag: list[float] = []

            for line in fh:
                parts = line.split()
                if len(parts) < 7:
                    continue
                rx, ry, rz = int(parts[0]), int(parts[1]), int(parts[2])
                re_h = float(parts[5])
                im_h = float(parts[6])

                # First orbital pair of new R-vector
                m_idx, n_idx = int(parts[3]), int(parts[4])
                if m_idx == 1 and n_idx == 1:
                    rvec.append([rx, ry, rz])

                hr_real.append(re_h)
                hr_imag.append(im_h)

        return {
            "n_wann": n_wann,
            "n_rpts": n_rpts,
            "degeneracy": deg[:n_rpts],
            "rvec": rvec,
            "hr_real": hr_real,
            "hr_imag": hr_imag,
        }
    except (OSError, ValueError):
        return None


def _parse_wannier90_band(path: str | Path) -> dict | None:
    """Parse ``wannier90_band.dat`` for interpolated bands.

    Format: blocks separated by blank lines.  Each block has
    lines ``k_dist  energy`` for one band.

    Parameters
    ----------
    path : str | Path
        Path to ``wannier90_band.dat``.

    Returns
    -------
    dict | None
        ``{"distances": list[float], "energies": list[list[float]]}``
        or ``None`` if parsing fails.
    """
    path = Path(path)
    if not path.is_file():
        return None

    try:
        with open(path, "r") as fh:
            text = fh.read()
    except OSError:
        return None

    # Split into band blocks separated by blank lines
    blocks = text.strip().split("\n\n")
    if not blocks:
        return None

    distances: list[float] | None = None
    energies: list[list[float]] = []

    try:
        for block in blocks:
            lines = block.strip().split("\n")
            dists_block: list[float] = []
            ens_block: list[float] = []
            for line in lines:
                parts = line.split()
                if len(parts) < 2:
                    continue
                dists_block.append(float(parts[0]))
                ens_block.append(float(parts[1]))
            if distances is None:
                distances = dists_block
            energies.append(ens_block)
    except (ValueError, IndexError):
        return None

    if distances is None or not energies:
        return None

    return {"distances": distances, "energies": energies}


# ═══════════════════════════════════════════════════════════════
# §19  Wannier90 TB utilities
# ═══════════════════════════════════════════════════════════════

# ── Wannier90 TB utilities ──────────────────────────────────


def _wannier_ham_k(
    hr_data: dict,
    kpoint: np.ndarray,
) -> np.ndarray:
    """Fourier-transform H(R) → H(k) for a single k-point.

    Implements the convention from wu2018 Eq. (3):
    ``H_{mn}(k) = Σ_R  exp(i k·R) / deg(R)  H_{mn}(R)``

    Parameters
    ----------
    hr_data : dict
        Parsed output of :func:`_parse_wannier90_hr`.
    kpoint : np.ndarray
        Fractional k-point coordinates, shape ``(3,)``.

    Returns
    -------
    np.ndarray
        Complex Hamiltonian matrix, shape ``(n_wann, n_wann)``.
    """
    n_wann = hr_data["n_wann"]
    n_rpts = hr_data["n_rpts"]
    rvec = np.asarray(hr_data["rvec"], dtype=float)  # (n_rpts, 3)
    deg = np.asarray(hr_data["degeneracy"], dtype=float)  # (n_rpts,)

    hr_flat = np.asarray(hr_data["hr_real"], dtype=float) + 1j * np.asarray(
        hr_data["hr_imag"], dtype=float
    )  # (n_rpts * n_wann * n_wann,)
    hr_mat = hr_flat.reshape(n_rpts, n_wann, n_wann)

    k = np.asarray(kpoint, dtype=float)
    # Phase factors: exp(2πi k·R) for fractional coords
    phases = np.exp(2j * np.pi * rvec @ k) / deg  # (n_rpts,)

    # H(k) = Σ_R phase(R) * H(R)
    hk = np.einsum("r,rmn->mn", phases, hr_mat)
    return hk


def _compute_wannier_dos(
    hr_data: dict,
    energy_grid: np.ndarray,
    kmesh: tuple[int, int, int] = (10, 10, 10),
    sigma: float = 0.1,
) -> np.ndarray:
    """Compute DOS from the Wannier tight-binding Hamiltonian.

    Generates a uniform k-mesh, diagonalises H(k) at each point,
    and broadens eigenvalues with a Gaussian.

    Parameters
    ----------
    hr_data : dict
        Parsed Wannier90 hr data.
    energy_grid : np.ndarray
        Energy values (eV) at which to evaluate the DOS.
    kmesh : tuple[int, int, int]
        Number of k-points along each reciprocal axis.
    sigma : float
        Gaussian broadening width (eV).

    Returns
    -------
    np.ndarray
        DOS values, shape ``(len(energy_grid),)``.
    """
    nk1, nk2, nk3 = kmesh
    n_kpts = nk1 * nk2 * nk3
    n_wann = hr_data["n_wann"]
    all_eigs = np.empty((n_kpts, n_wann))

    idx = 0
    for i1 in range(nk1):
        for i2 in range(nk2):
            for i3 in range(nk3):
                kpt = np.array(
                    [
                        i1 / nk1,
                        i2 / nk2,
                        i3 / nk3,
                    ]
                )
                hk = _wannier_ham_k(hr_data, kpt)
                eigs = np.linalg.eigvalsh(hk)
                all_eigs[idx] = eigs
                idx += 1

    # Gaussian broadening
    dos = np.zeros_like(energy_grid)
    prefactor = 1.0 / (sigma * np.sqrt(2.0 * np.pi) * n_kpts)
    for eigs in all_eigs:
        for e_n in eigs:
            dos += prefactor * np.exp(-0.5 * ((energy_grid - e_n) / sigma) ** 2)

    return dos


def _compute_cohp(
    hr_data: dict,
    atom_pairs: list[tuple[int, int]],
    energy_grid: np.ndarray,
    kmesh: tuple[int, int, int] = (10, 10, 10),
    sigma: float = 0.1,
) -> dict[tuple[int, int], np.ndarray]:
    """Compute COHP from Wannier Hamiltonian (nelson2020 Eq. 6).

    For each atom pair (m, n), COHP is:

    ``COHP_{mn}(E) = -Σ_k Σ_j Re[H_{mn}(k) C*_{mj}(k) C_{nj}(k)]
                      × δ(E - ε_j(k))``

    where C_{mj}(k) are eigenvector components and the delta
    function is replaced by Gaussian broadening.

    Parameters
    ----------
    hr_data : dict
        Parsed Wannier90 hr data.
    atom_pairs : list[tuple[int, int]]
        Pairs of Wannier function indices (0-based) for COHP.
    energy_grid : np.ndarray
        Energy values (eV).
    kmesh : tuple[int, int, int]
        Number of k-points along each reciprocal axis.
    sigma : float
        Gaussian broadening width (eV).

    Returns
    -------
    dict[tuple[int, int], np.ndarray]
        COHP curves indexed by atom pair, shape
        ``(len(energy_grid),)`` each.  Negative = bonding.
    """
    nk1, nk2, nk3 = kmesh
    n_kpts = nk1 * nk2 * nk3

    # Initialise COHP accumulators
    cohp: dict[tuple[int, int], np.ndarray] = {
        pair: np.zeros_like(energy_grid) for pair in atom_pairs
    }

    prefactor = 1.0 / (sigma * np.sqrt(2.0 * np.pi) * n_kpts)

    for i1 in range(nk1):
        for i2 in range(nk2):
            for i3 in range(nk3):
                kpt = np.array(
                    [
                        i1 / nk1,
                        i2 / nk2,
                        i3 / nk3,
                    ]
                )
                hk = _wannier_ham_k(hr_data, kpt)
                eigs, evecs = np.linalg.eigh(hk)

                for m, n in atom_pairs:
                    # H_mn(k)
                    h_mn = hk[m, n]
                    # Σ_j C*_{mj} C_{nj} δ(E - ε_j)
                    for j, e_j in enumerate(eigs):
                        weight = np.real(h_mn * np.conj(evecs[m, j]) * evecs[n, j])
                        gauss = np.exp(-0.5 * ((energy_grid - e_j) / sigma) ** 2)
                        # COHP convention: negative = bonding
                        cohp[(m, n)] -= prefactor * weight * gauss

    return cohp


# ═══════════════════════════════════════════════════════════════
# §20  Wannier90 derive helpers
# ═══════════════════════════════════════════════════════════════

# ── Wannier _derive_* helpers ────────────────────────────────


@_property_guard(
    key="wf_centres",
    methods=["wannier"],
)
def _derive_wannier_functions(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> dict | None:
    """Wannier function centres, spreads and charge centres (W1+W5).

    Reads ``report.wannier_data`` populated from
    ``wannier90.wout``.  Returns centres and spreads and
    writes ``wannier/charge_centres`` as well.
    """
    method_tag = kw.get("_method_tag", "wannier")
    wd = getattr(report, "wannier_data", None)
    if wd is None:
        return None

    centres = wd.get("centres")
    spreads = wd.get("spreads")
    if centres is None or spreads is None:
        return None

    if not centres:
        return None

    result = {
        "centres": [[round(float(v), 6) for v in c] for c in centres],
        "spreads": [round(float(s), 6) for s in spreads],
        "n_wann": len(centres),
    }

    # Charge centres (W5) — same as WF centres for MLWFs
    # (Berry-phase-equivalent electronic charge localisation)
    slabfy_obj.properties_metadata[f"{method_tag}/charge_centres"] = result["centres"]

    return result


@_property_guard(
    key="wannier_bands",
    methods=["wannier"],
)
def _derive_wannier_bands(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> dict | None:
    """Wannier-interpolated band structure (W2).

    Reads ``report.wannier_data["bands"]`` populated from
    ``wannier90_band.dat``.
    """
    wd = getattr(report, "wannier_data", None)
    if wd is None:
        return None

    bands = wd.get("bands")
    if bands is None:
        return None

    distances = bands.get("distances")
    energies = bands.get("energies")
    if distances is None or energies is None:
        return None

    return {
        "distances": [round(float(d), 6) for d in distances],
        "energies": [[round(float(e), 6) for e in band] for band in energies],
        "n_bands": len(energies),
        "n_kpoints": len(distances),
    }


@_property_guard(
    key="wannier_dos",
    methods=["wannier"],
)
def _derive_wannier_dos(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> dict | None:
    """Wannier-interpolated DOS from tight-binding H(k) (W3).

    Computes the DOS by diagonalising the Wannier Hamiltonian on
    a uniform k-mesh and Gaussian-broadening the eigenvalues.
    """
    wd = getattr(report, "wannier_data", None)
    if wd is None:
        return None

    hr = wd.get("hr")
    if hr is None:
        return None

    # Require minimum Hamiltonian data
    if hr.get("n_wann", 0) == 0:
        return None

    # Energy grid: ±15 eV around zero, 0.01 eV step
    energy_grid = np.linspace(-15.0, 15.0, 3001)

    try:
        dos = _compute_wannier_dos(
            hr,
            energy_grid,
            kmesh=(10, 10, 10),
            sigma=0.1,
        )
    except (np.linalg.LinAlgError, ValueError):
        return None

    return {
        "energies_eV": [round(float(e), 4) for e in energy_grid],
        "dos": [round(float(d), 6) for d in dos],
    }


@_property_guard(
    key="cohp",
    methods=["wannier"],
)
def _derive_wannier_cohp(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> dict | None:
    """COHP from Wannier Hamiltonian (W4).

    Derives Crystal Orbital Hamilton Population following
    the methodology in nelson2020.  Uses the real-space
    Hamiltonian from ``wannier90_hr.dat`` to compute
    COHP for nearest-neighbour Wannier function pairs.

    The formula (cf. nelson2020 Eq. 6, adapted for
    Wannier basis with orthogonal overlap S=I):

    COHP_mn(E) = -Σ_k H_mn(k) Σ_j Re[C*_mj(k) C_nj(k)]
                 × δ(E - ε_j(k))
    """
    wd = getattr(report, "wannier_data", None)
    if wd is None:
        return None

    hr = wd.get("hr")
    if hr is None:
        return None

    n_wann = hr.get("n_wann", 0)
    if n_wann < 2:
        return None

    # Default: compute COHP for all nearest-neighbour pairs
    # (adjacent orbital indices)
    pairs = [(i, i + 1) for i in range(n_wann - 1)]

    energy_grid = np.linspace(-15.0, 15.0, 3001)

    try:
        cohp = _compute_cohp(
            hr,
            pairs,
            energy_grid,
            kmesh=(10, 10, 10),
            sigma=0.1,
        )
    except (np.linalg.LinAlgError, ValueError):
        return None

    # Serialise: keys as "m-n" strings
    cohp_out: dict[str, list[float]] = {}
    for (m, n), curve in cohp.items():
        cohp_out[f"{m}-{n}"] = [round(float(v), 6) for v in curve]

    # Integrated COHP (ICOHP) per pair
    de = energy_grid[1] - energy_grid[0]
    icohp: dict[str, float] = {}
    for key, curve_list in cohp_out.items():
        icohp[key] = round(float(np.trapezoid(curve_list, dx=de)), 6)

    return {
        "energies_eV": [round(float(e), 4) for e in energy_grid],
        "pairs": cohp_out,
        "icohp": icohp,
        "n_pairs": len(pairs),
    }


def _generate_carrier_kpoints(
    vbm_coords: list[float], cbm_coords: list[float], dk: float = 0.015
) -> tuple[list[list[float]], list[float]]:
    """Generate a 3D cross stencil of explicit K-points for effective mass calculations.

    Returns
    -------
    tuple[list[list[float]], list[float]]
        The unique K-points list and their corresponding weights (1.0).
    """
    kpts = []
    for center in [vbm_coords, cbm_coords]:
        if not center or len(center) != 3:
            continue
        cx, cy, cz = center
        kpts.append([cx, cy, cz])
        kpts.extend(
            [
                [cx + dk, cy, cz],
                [cx - dk, cy, cz],
                [cx, cy + dk, cz],
                [cx, cy - dk, cz],
                [cx, cy, cz + dk],
                [cx, cy, cz - dk],
            ]
        )

    unique_kpts = []
    for pt in kpts:
        if pt not in unique_kpts:
            unique_kpts.append(pt)

    weights = [1.0] * len(unique_kpts)
    return unique_kpts, weights


def _generate_posnics_grid(slabfy_obj, grid_spacing=0.2, padding=1.5):
    """
    Generates a 2D or 3D POSNICS grid for VASP NMR/NICS calculations over a slab
    and returns it as a pymatgen Kpoints object.

    Args:
        slabfy_obj: Object with attributes:
            - slab: pymatgen.core.Structure
            - thickness: float (fractional c-coordinate of the topmost slab layer)
            - adparticle: Any (None if clean slab, otherwise evaluated as True)
        grid_spacing: float, approximate grid density in Angstroms.

    Returns:
        pymatgen.io.vasp.inputs.Kpoints: The POSNICS grid wrapped in a Kpoints object.
    """
    slab = slabfy_obj.slab

    # Lattice vector lengths
    a_len = slab.lattice.a
    b_len = slab.lattice.b
    c_len = slab.lattice.c

    # Determine the number of grid points in the a-b plane based on desired density
    nx = int(np.ceil(a_len / grid_spacing))
    ny = int(np.ceil(b_len / grid_spacing))

    # Generate fractional coordinates for the X and Y axes [0, 1)
    x_frac = np.linspace(0, 1, nx, endpoint=False)
    y_frac = np.linspace(0, 1, ny, endpoint=False)

    # Define vertical padding (delta) in Angstroms, then convert to fractional
    base_padding_ang = padding
    delta_frac = base_padding_ang / c_len

    if slabfy_obj.adparticle is not None:
        # --- 3D Grid Formulation ---
        topmost_c = max(site.frac_coords[2] for site in slab)

        z_start_ang = 0.5
        z_end_ang = 1.0

        z_min = slabfy_obj.thickness + (z_start_ang / c_len)
        z_max = topmost_c + (z_end_ang / c_len)

        z_dist_ang = (z_max - z_min) * c_len
        nz = max(2, int(np.ceil(z_dist_ang / grid_spacing)))

        z_frac = np.linspace(z_min, z_max, nz, endpoint=True)
    else:
        # --- 2D Grid Formulation ---
        z_frac = [slabfy_obj.thickness + delta_frac]

    # Create 3D meshgrid and flatten to (N, 3) array
    X, Y, Z = np.meshgrid(x_frac, y_frac, z_frac, indexing="ij")
    points = np.vstack([X.ravel(), Y.ravel(), Z.ravel()]).T

    # Periodically wrap fractional coordinates back strictly into [0.0, 1.0)
    points = points % 1.0

    # Convert numpy array to list of lists (required by Kpoints)
    kpts_list = points.tolist()

    return kpts_list


# ═══════════════════════════════════════════════════════════════
# §14  NMR / NICS Parsing
# ═══════════════════════════════════════════════════════════════


def _parse_nmr_outcar(outcar_path: str) -> dict[str, Any] | None:
    """Parse NMR chemical shielding tensors and NICS values from OUTCAR.

    This function extracts NMR data from VASP 6.6+ OUTCAR files, including:
    - Chemical shielding tensors (σ) for each atom
    - Isotropic shielding values
    - Shielding anisotropy and asymmetry parameters
    - NICS (Nucleus-Independent Chemical Shift) at POSNICS grid points
    - Electric field gradients (EFG) if available

    Parameters
    ----------
    outcar_path : str
        Path to OUTCAR file from an NMR calculation.

    Returns
    -------
    dict | None
        Parsed NMR data with structure::

            {
                "chemical_shielding": [
                    {
                        "element": str,
                        "index": int,
                        "tensor": [[float]*3]*3,
                        "isotropic": float,
                        "anisotropy": float,
                        "asymmetry": float,
                    },
                    ...
                ],
                "nics": {
                    "positions": [[float]*3],
                    "values": [float],
                },
                "efg": [
                    {
                        "element": str,
                        "index": int,
                        "tensor": [[float]*3]*3,
                        "cq": float,
                        "eta": float,
                    },
                    ...
                ],
            }

        Returns None if the file is not an NMR calculation or parsing fails.

    Notes
    -----
    VASP NMR output markers to search for:
    - "LNMR_SYM_RED" or "NMR chemical shielding" for shielding data
    - "POSNICS" or "NICS" for nucleus-independent chemical shifts
    - "Electric field gradient" for EFG data

    The shielding tensor eigenvalues (σ₁₁, σ₂₂, σ₃₃) are used to compute:
    - Isotropic shielding: σ_iso = (σ₁₁ + σ₂₂ + σ₃₃) / 3
    - Anisotropy: Δσ = σ₃₃ - (σ₁₁ + σ₂₂) / 2
    - Asymmetry: η = (σ₂₂ - σ₁₁) / (σ₃₃ - σ_iso)

    References
    ----------
    VASP NMR tutorial: https://vasp.at/tutorials/latest/nmr/part3/
    """
    # TODO: Implement OUTCAR parsing when VASP 6.6 NMR output is available
    # The implementation should:
    # 1. Open OUTCAR and search for NMR calculation markers
    # 2. Parse chemical shielding tensor blocks (3x3 per atom)
    # 3. Extract NICS values if POSNICS was used
    # 4. Parse EFG data if present
    # 5. Compute derived quantities (isotropic, anisotropy, asymmetry)

    import os

    if not os.path.isfile(outcar_path):
        return None

    nmr_data: dict[str, Any] = {
        "chemical_shielding": [],
        "nics": {"positions": [], "values": []},
        "efg": [],
    }

    # Placeholder: Read OUTCAR and check for NMR markers
    try:
        with open(outcar_path, "r") as f:
            content = f.read()

        # Check if this is an NMR calculation
        nmr_markers = [
            "LNMR_SYM_RED",
            "chemical shielding",
            "LCHIMAG",
            "LNICSALL",
        ]
        is_nmr = any(marker in content for marker in nmr_markers)

        if not is_nmr:
            return None

        # TODO: Parse shielding tensors
        # Pattern: Look for blocks like:
        #   ion    1   element   C
        #     sigma tensor (ppm)
        #       xx      xy      xz
        #       yx      yy      yz
        #       zx      zy      zz

        # TODO: Parse NICS values
        # Pattern: Look for POSNICS grid output

        # TODO: Parse EFG data
        # Pattern: Look for "Electric field gradient" blocks

    except (OSError, IOError):
        return None

    # Return None if no data was parsed (skeleton implementation)
    if not nmr_data["chemical_shielding"] and not nmr_data["nics"]["values"]:
        return None

    return nmr_data


def _compute_shielding_parameters(
    tensor: list[list[float]],
) -> tuple[float, float, float]:
    """Compute NMR shielding parameters from a 3x3 tensor.

    Parameters
    ----------
    tensor : list[list[float]]
        3x3 chemical shielding tensor in ppm.

    Returns
    -------
    tuple[float, float, float]
        (isotropic, anisotropy, asymmetry) values.

    Notes
    -----
    Conventions follow Haeberlen notation:
    - Eigenvalues ordered as |σ₃₃ - σ_iso| ≥ |σ₁₁ - σ_iso| ≥ |σ₂₂ - σ_iso|
    - Isotropic: σ_iso = Tr(σ) / 3
    - Anisotropy: Δσ = σ₃₃ - (σ₁₁ + σ₂₂) / 2
    - Asymmetry: η = (σ₂₂ - σ₁₁) / (σ₃₃ - σ_iso), where 0 ≤ η ≤ 1
    """
    tensor_arr = np.array(tensor)

    # Compute eigenvalues
    eigenvalues = np.linalg.eigvalsh(tensor_arr)

    # Isotropic shielding (trace / 3)
    isotropic = float(np.trace(tensor_arr) / 3.0)

    # Sort eigenvalues by |σ - σ_iso| (Haeberlen convention)
    deviations = np.abs(eigenvalues - isotropic)
    sorted_indices = np.argsort(deviations)
    sigma_22, sigma_11, sigma_33 = eigenvalues[sorted_indices]

    # Anisotropy
    anisotropy = float(sigma_33 - (sigma_11 + sigma_22) / 2.0)

    # Asymmetry (guard against division by zero)
    denom = sigma_33 - isotropic
    if abs(denom) < 1e-10:
        asymmetry = 0.0
    else:
        asymmetry = float((sigma_22 - sigma_11) / denom)

    return isotropic, anisotropy, asymmetry


@_property_guard(
    key="chemical_shielding",
    methods=["nmr"],
    object_types=[Surface, Interface],
)
def _derive_nmr_shielding(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> list[dict[str, Any]] | None:
    """Derive NMR chemical shielding from OUTCAR.

    Extracts per-atom shielding tensors and computes:
    - Isotropic shielding (ppm)
    - Shielding anisotropy
    - Asymmetry parameter

    Parameters
    ----------
    report : VaspReport
        Parsed VASP output containing available_files.
    slabfy_obj : Surface | Interface
        The slabfy object to store results on.
    **kw : Any
        Additional keyword arguments (includes _method_tag).

    Returns
    -------
    list[dict] | None
        List of per-atom shielding data, or None if unavailable.
    """
    outcar = report.available_files.get("outcar")
    if not outcar:
        return None

    nmr_data = _parse_nmr_outcar(outcar)
    if nmr_data is None:
        return None

    return nmr_data.get("chemical_shielding") or None


@_property_guard(
    key="nics",
    methods=["nmr"],
    object_types=[Surface, Interface],
)
def _derive_nics(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> dict[str, Any] | None:
    """Derive NICS values from POSNICS calculation.

    NICS (Nucleus-Independent Chemical Shift) values represent the
    magnetic shielding at points in space away from atomic nuclei,
    useful for analyzing aromaticity and ring currents.

    Parameters
    ----------
    report : VaspReport
        Parsed VASP output containing available_files.
    slabfy_obj : Surface | Interface
        The slabfy object to store results on.
    **kw : Any
        Additional keyword arguments (includes _method_tag).

    Returns
    -------
    dict | None
        NICS data with structure::

            {
                "positions": [[x, y, z], ...],  # Fractional coordinates
                "values": [nics_1, nics_2, ...],  # NICS values in ppm
            }

        Returns None if POSNICS data is unavailable.
    """
    outcar = report.available_files.get("outcar")
    if not outcar:
        return None

    nmr_data = _parse_nmr_outcar(outcar)
    if nmr_data is None:
        return None

    nics = nmr_data.get("nics")
    if not nics or not nics.get("values"):
        return None

    return nics


@_property_guard(
    key="efg",
    methods=["nmr"],
    object_types=[Surface, Interface],
)
def _derive_efg(
    report: "VaspReport",
    slabfy_obj: Any,
    **kw: Any,
) -> list[dict[str, Any]] | None:
    """Derive electric field gradients from NMR calculation.

    EFG tensors are relevant for quadrupolar nuclei (spin > 1/2)
    and provide information about the local electronic environment.

    Parameters
    ----------
    report : VaspReport
        Parsed VASP output containing available_files.
    slabfy_obj : Surface | Interface
        The slabfy object to store results on.
    **kw : Any
        Additional keyword arguments (includes _method_tag).

    Returns
    -------
    list[dict] | None
        List of per-atom EFG data with structure::

            {
                "element": str,
                "index": int,
                "tensor": [[float]*3]*3,
                "cq": float,  # Quadrupole coupling constant
                "eta": float,  # Asymmetry parameter
            }

        Returns None if EFG data is unavailable.
    """
    outcar = report.available_files.get("outcar")
    if not outcar:
        return None

    nmr_data = _parse_nmr_outcar(outcar)
    if nmr_data is None:
        return None

    return nmr_data.get("efg") or None
