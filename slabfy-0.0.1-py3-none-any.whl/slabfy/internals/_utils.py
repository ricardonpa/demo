import importlib.resources
import json
import os

from typing import Any, Union, TYPE_CHECKING

if TYPE_CHECKING:
    from slabfy.core import Bulk, Adparticle, Surface, Interface
    from pymatgen.core.structure import Structure


def _read_slabfy_file(
    path: str,
) -> Union["Bulk", "Adparticle", "Surface", "Interface", "Structure"]:
    """Read a slabfy object from a POSCAR file by detecting its prefix.

    This function inspects the first line of the file to determine
    whether it contains a serialized Bulk, Adparticle, Surface, or
    Interface object. It then delegates to the appropriate ``.read()``
    method.

    If no slabfy prefix is detected, falls back to reading as a plain
    pymatgen Structure via ``Poscar.from_file``.

    Parameters
    ----------
    path : str
        Path to the POSCAR file.

    Returns
    -------
    Bulk | Adparticle | Surface | Interface | Structure
        The deserialized slabfy object, or a plain Structure if no
        prefix is detected.

    Raises
    ------
    FileNotFoundError
        If the file does not exist.
    ValueError
        If the prefix is recognized but deserialization fails.

    Examples
    --------
    >>> obj = _read_slabfy_file("POSCAR")
    >>> type(obj)
    <class 'slabfy.core.Surface'>
    """
    # Avoid circular imports by importing inside function
    from slabfy import utils
    from slabfy.core import Bulk, Adparticle, Surface, Interface
    from pymatgen.io.vasp.inputs import Poscar

    with open(path, "r", encoding="utf-8") as fh:
        first_line = fh.readline().strip()

    # Check prefixes in order of specificity (Interface before Surface
    # since Interface is a subclass of Surface)
    if first_line.startswith(utils.INTERFACE_B64_PREFIX):
        return Interface.read(path)
    if first_line.startswith(utils.SURFACE_B64_PREFIX):
        return Surface.read(path)
    if first_line.startswith(utils.BULK_B64_PREFIX):
        return Bulk.read(path)
    if first_line.startswith(utils.ADPARTICLE_B64_PREFIX):
        return Adparticle.read(path)

    # No slabfy prefix found — fall back to plain Structure
    return Poscar.from_file(path).structure


def _freeze_surface_layers(surface: "Surface", free_layers: int) -> "Structure":
    """Freeze all layers except the top ``free_layers`` layers of a Surface.

    Parameters
    ----------
    surface : Surface
        The Surface object with ``surface_axis_layers`` populated.
    free_layers : int
        Number of layers from the top to leave unfrozen.

    Returns
    -------
    Structure
        A copy of the slab with selective dynamics applied.
    """
    if surface.slab is None:
        raise ValueError("Surface has no slab attribute")

    layers_dict = surface.surface_axis_layers
    if not layers_dict:
        raise ValueError("Surface.surface_axis_layers is not populated")

    frozen = surface.slab.copy()

    # layers_dict is sorted descending by height (top first)
    # Keys are heights in Angstrom
    layer_heights = list(layers_dict.keys())  # Already sorted descending
    n_layers = len(layer_heights)

    # Determine which heights to keep free (top N layers)
    free_heights = set(layer_heights[: min(free_layers, n_layers)])

    # Apply selective dynamics based on Cartesian height
    # We need to match sites to their layer heights
    for site in frozen:
        # Find which layer this site belongs to by matching height
        site_height = _get_site_layer_height(site, layer_heights)

        if site_height in free_heights:
            site.properties["selective_dynamics"] = [True, True, True]
        else:
            site.properties["selective_dynamics"] = [False, False, False]

    return frozen


def _freeze_interface_layers(
    interface: "Interface", free_left: int, free_right: int
) -> "Structure":
    """Freeze layers outside the interface contact region.

    Parameters
    ----------
    interface : Interface
        The Interface object with ``interface_axis_layers`` and
        ``interface_axis_position`` populated.
    free_left : int
        Number of layers to the left of the interface position to leave unfrozen.
    free_right : int
        Number of layers to the right of the interface position to leave unfrozen.

    Returns
    -------
    Structure
        A copy of the slab with selective dynamics applied.
    """
    if interface.slab is None:
        raise ValueError("Interface has no slab attribute")

    layers_dict = interface.interface_axis_layers
    if not layers_dict:
        raise ValueError("Interface.interface_axis_layers is not populated")

    interface_pos = interface.interface_axis_position
    if interface_pos is None:
        raise ValueError("Interface.interface_axis_position is not set")

    frozen = interface.slab.copy()

    # layers_dict keys are heights in Angstrom, sorted descending
    layer_heights = list(layers_dict.keys())

    # Split layers into left (< interface_pos) and right (>= interface_pos)
    left_layers = sorted([h for h in layer_heights if h < interface_pos], reverse=True)
    right_layers = sorted(
        [h for h in layer_heights if h >= interface_pos], reverse=True
    )

    # Determine which heights to keep free
    # Left: closest N layers to interface (highest heights among left layers)
    # Right: closest N layers to interface (lowest heights among right layers)
    free_left_heights = set(left_layers[: min(free_left, len(left_layers))])
    # For right, we want layers closest to interface, which are the lowest heights
    right_sorted_asc = sorted(right_layers)  # ascending by height
    free_right_heights = set(right_sorted_asc[: min(free_right, len(right_layers))])

    free_heights = free_left_heights | free_right_heights

    # Apply selective dynamics
    for site in frozen:
        site_height = _get_site_layer_height(site, layer_heights)

        if site_height in free_heights:
            site.properties["selective_dynamics"] = [True, True, True]
        else:
            site.properties["selective_dynamics"] = [False, False, False]

    return frozen


def _get_site_layer_height(
    site, layer_heights: list[float], decimals: int = 6
) -> float:
    """Find the layer height that a site belongs to.

    Uses the site's Cartesian z-coordinate projected onto the c-axis.
    """
    # Get site's Cartesian z coordinate
    site_z = round(site.coords[2], decimals)

    # Find closest layer height
    if not layer_heights:
        return site_z

    closest = min(layer_heights, key=lambda h: abs(h - site_z))
    return closest


def _load_settings_json(filename: str, user_dir: str | None = None) -> dict:
    """Load a settings JSON by filename.

    1. Load from package resources: ``slabfy/settings/<filename>``.
    2. If *user_dir* is set and ``<user_dir>/<filename>`` exists,
       deep-merge the user content on top (user wins on key conflicts).
    3. Return ``{}`` on any failure; never raise.
    """
    if not filename:
        return {}

    # 1) Load package defaults
    pkg_data: dict = {}
    try:
        ref = importlib.resources.files("slabfy").joinpath(f"settings/{filename}")
        with ref.open("r") as fh:
            pkg_data = json.load(fh)
    except Exception:
        pass

    # 2) Load user overrides and deep-merge
    if user_dir:
        user_path = os.path.join(user_dir, filename)
        if os.path.isfile(user_path):
            try:
                with open(user_path, "r") as fh:
                    user_data = json.load(fh)
                if user_data:
                    pkg_data = _deep_merge(pkg_data, user_data)
            except Exception:
                pass

    return pkg_data


def _deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge *override* into a copy of *base* (override wins)."""
    result = dict(base)
    for k, v in override.items():
        if k in result and isinstance(result[k], dict) and isinstance(v, dict):
            result[k] = _deep_merge(result[k], v)
        else:
            result[k] = v
    return result


def _resolve_user_dir(custom_section: dict) -> str:
    """Return the user config directory for slabfy.

    Resolution order:
    1. If ``CUSTOM.USER_DIR`` is a non-empty string pointing to an existing
       directory, use it (supports shared lab filesystems).
    2. Otherwise fall back to ``platformdirs.user_config_dir("slabfy")``.

    If the resolved directory does not exist it is created and seeded with
    empty JSON scaffolds so users know which files slabfy expects.
    """
    from platformdirs import user_config_dir

    candidate = custom_section.get("USER_DIR", "")
    if candidate and os.path.isdir(candidate):
        return candidate

    user_dir = user_config_dir("slabfy")

    if not os.path.isdir(user_dir):
        os.makedirs(user_dir, exist_ok=True)
        for seed_name in ("vasp6.json", "ase3.json", "sbatch.json"):
            seed_path = os.path.join(user_dir, seed_name)
            if not os.path.exists(seed_path):
                with open(seed_path, "w") as fh:
                    json.dump({}, fh)

    return user_dir


# ─── Scheduler job-script constants ──────────────────────────────────────────


def _render_job_script(
    job_config: dict[str, Any],
    output_file: str | None = None,
) -> str:
    """Render a SLURM or PBS/Torque job submission script from a config dict.

    Assumes all keys in *job_config* (except ``'scheduler'`` and ``'job-cmd'``)
    are already scheduler-native directive tokens, e.g. for SLURM use
    ``'--nodes'`` and for PBS use ``'-l nodes'``.

    Rules:
    - Always emit shebang `#!/bin/bash` as first line.
    - For each directive key/value pair, emit one scheduler line:
      `#SBATCH <key>=<value>` or `#PBS <key>=<value>`.
    - Keys with empty-string values are skipped.
    - Each command in ``job_config['job-cmd']`` becomes one line.
    """
    scheduler = str(job_config.get("scheduler", "slurm")).strip().lower()
    if scheduler not in ("slurm", "pbs", "torque"):
        raise ValueError(f"Unknown scheduler {scheduler!r}; must be 'slurm' or 'pbs'.")
    sched_key = "pbs" if scheduler == "torque" else scheduler
    prefix = "#SBATCH" if sched_key == "slurm" else "#PBS"

    lines: list[str] = ["#!/bin/bash"]
    skip = {"scheduler", "job-cmd"}
    for key, value in job_config.items():
        if key in skip:
            continue
        if str(value).strip() == "":
            continue
        sep = "=" if sched_key == "slurm" else " "
        lines.append(f"{prefix} {key}{sep}{value}")

    lines.append("")
    for cmd in job_config.get("job-cmd", []):
        lines.append(str(cmd))

    script = "\n".join(lines)
    if output_file is not None:
        with open(output_file, "w", encoding="utf-8") as fh:
            fh.write(script)
    return script
