def _check_mlip():
    pass

def _install_mlip(mlip: str):
    pass