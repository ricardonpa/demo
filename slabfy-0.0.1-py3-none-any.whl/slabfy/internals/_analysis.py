"""
slabfy.internals._analysis
==========================
Internal analysis functions for slabfy.analysis — DO NOT import directly.
Use ``from slabfy.analysis import ...`` instead.

Functions here may change without notice.

FUNCTION MAP
────────────
§1  Constants
    _EV_ANG2_TO_J_M2

§2  Surface energy computation
    _compute_surface_energy

§3  Wulff construction helpers
    _get_palette, _assign_colors, _hex_to_rgba, _build_traces,
    _rotate_eye, _build_fig, _generate_wulff
"""

from __future__ import annotations

from pymatgen.analysis.wulff import WulffShape
import plotly.graph_objects as go
import numpy as np
from collections import defaultdict
from typing import TYPE_CHECKING, Literal, Any
import matplotlib, matplotlib.colors as mcolors
import io

if TYPE_CHECKING:
    from slabfy.core import Surface, Bulk


# ═══════════════════════════════════════════════════════════════
# §1  Constants
# ═══════════════════════════════════════════════════════════════

_EV_ANG2_TO_J_M2: float = 16.0218
"""Conversion factor: eV Å⁻² → J m⁻²."""


# ═══════════════════════════════════════════════════════════════
# §2  Surface energy computation
# ═══════════════════════════════════════════════════════════════


def _compute_surface_energy(
    surface: "Surface",
    e_unrelaxed: float,
    e_relaxed: float,
    bulk_energy: float | None = None,
) -> dict[str, float] | None:
    """Compute surface energy γ (J m⁻² and eV Å⁻²) from energies.

    This function computes surface energy using the formula::

        E_cleav = (n * bulk_energy_per_fu - E_unrelaxed) / 2
        E_relax = (E_relaxed - E_unrelaxed) / 2
        γ = (E_cleav + E_relax) / area

    Parameters
    ----------
    surface : Surface
        The surface object containing bulk reference and structure info.
    e_unrelaxed : float
        Energy at first ionic step (eV).
    e_relaxed : float
        Energy at last ionic step (eV).
    bulk_energy : float | None
        Bulk energy per formula unit (eV). If None, uses surface.bulk.energy.

    Returns
    -------
    dict[str, float] | None
        Dictionary with keys:
        - "surface_energy_J_m2": Surface energy in J/m²
        - "surface_energy_eV_A2": Surface energy in eV/Å²
        - "cleavage_energy_eV": Cleavage energy contribution (eV)
        - "relaxation_energy_eV": Relaxation energy contribution (eV)
        Returns None if any required quantity is unavailable.
    """
    # Get bulk reference
    bulk_obj = getattr(surface, "bulk", None)
    if bulk_energy is None:
        bulk_energy = (
            getattr(bulk_obj, "energy", None) if bulk_obj is not None else None
        )
    if bulk_energy is None:
        return None

    # Get surface area
    surface_area = getattr(surface, "surface_area", None)
    if not surface_area or float(surface_area) <= 0.0:
        return None

    # Get structures for composition ratio
    bulk_structure = getattr(bulk_obj, "structure", None)
    slab = getattr(surface, "slab", None)
    if bulk_structure is None or slab is None:
        return None

    # Compute stoichiometry ratio n
    try:
        bulk_reduced, _ = (
            bulk_structure.composition.get_reduced_composition_and_factor()
        )
        el = next(iter(bulk_reduced))
        n = float(slab.composition[el]) / float(bulk_reduced[el])
    except Exception:
        return None

    # Compute energies
    e_cleav = (n * float(bulk_energy) - float(e_unrelaxed)) / 2.0
    e_relax = (float(e_relaxed) - float(e_unrelaxed)) / 2.0

    surface_energy_ev_a2 = (e_cleav + e_relax) / float(surface_area)
    surface_energy_j_m2 = surface_energy_ev_a2 * _EV_ANG2_TO_J_M2

    return {
        "surface_energy_J_m2": surface_energy_j_m2,
        "surface_energy_eV_A2": surface_energy_ev_a2,
        "cleavage_energy_eV": e_cleav,
        "relaxation_energy_eV": e_relax,
    }


# ═══════════════════════════════════════════════════════════════
# §3  Wulff construction helpers
# ═══════════════════════════════════════════════════════════════


def _get_palette(n):
    cmap = matplotlib.colormaps.get_cmap("tab20").resampled(n)
    return [mcolors.to_hex(cmap(i)) for i in range(n)]


def _assign_colors(miller_indices, user_colors=None):
    user_colors = user_colors or {}
    palette = iter(_get_palette(len(miller_indices)))
    return {hkl: user_colors.get(hkl, next(palette)) for hkl in miller_indices}


def _hex_to_rgba(hex_color, alpha):
    h = hex_color.lstrip("#")
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return f"rgba({r},{g},{b},{alpha})"


def _build_traces(wulff, miller_list, colors, alpha, surface_energies):
    facets_by_miller = defaultdict(list)
    for f in wulff.facets:
        if len(f.points):
            facets_by_miller[miller_list[f.m_ind_orig]].append(f)

    traces = []
    for miller, hex_color in colors.items():
        facets = facets_by_miller.get(miller, [])
        if not facets:
            continue
        rgba = _hex_to_rgba(hex_color, alpha)
        label = f"({miller[0]}{miller[1]}{miller[2]})  {surface_energies[miller]:.3f}"
        verts, I, J, K = [], [], [], []
        for f in facets:
            flat = np.array(f.points).reshape(-1, 3)
            off = len(verts)
            verts.extend(flat.tolist())
            for t in range(len(f.points)):
                I.append(off + t * 3)
                J.append(off + t * 3 + 1)
                K.append(off + t * 3 + 2)
        v = np.array(verts)
        traces.append(
            go.Mesh3d(
                x=v[:, 0],
                y=v[:, 1],
                z=v[:, 2],
                i=I,
                j=J,
                k=K,
                color=rgba,
                opacity=alpha,
                flatshading=True,
                hoverinfo="skip",
                lighting=dict(ambient=0.8, diffuse=0.5, specular=0.1),
                name=label,
                legendgroup=label,
                showlegend=True,
            )
        )
        for f in facets:
            b = wulff.get_line_in_facet(f)
            if b is None or len(b) < 3:
                continue
            loop = np.vstack([b, b[0]])
            traces.append(
                go.Scatter3d(
                    x=loop[:, 0],
                    y=loop[:, 1],
                    z=loop[:, 2],
                    mode="lines",
                    line=dict(color="black", width=1.5),
                    showlegend=False,
                    legendgroup=label,
                    hoverinfo="skip",
                )
            )
    return traces


def _rotate_eye(eye, up, theta):
    """Rodrigues rotation of eye around up axis by theta radians."""
    e = np.array([eye["x"], eye["y"], eye["z"]], dtype=float)
    k = np.array([up["x"], up["y"], up["z"]], dtype=float)
    k /= np.linalg.norm(k)
    e_rot = (
        e * np.cos(theta)
        + np.cross(k, e) * np.sin(theta)
        + k * np.dot(k, e) * (1 - np.cos(theta))
    )
    return dict(x=float(e_rot[0]), y=float(e_rot[1]), z=float(e_rot[2]))


def _build_fig(traces, eye, up, center):
    fig = go.Figure(data=traces)
    fig.update_layout(
        paper_bgcolor="white",
        margin=dict(l=0, r=0, t=0, b=0),
        scene=dict(
            xaxis=dict(visible=False),
            yaxis=dict(visible=False),
            zaxis=dict(visible=False),
            bgcolor="rgba(0,0,0,0)",
            aspectmode="data",
            dragmode="orbit",
            camera=dict(eye=eye, up=up, center=center),
        ),
        legend=dict(
            title=dict(text="<b>hkl</b>    γ (J/m²)"),
            x=1.02,
            y=0.5,
            xanchor="left",
            yanchor="middle",
            itemsizing="constant",
            tracegroupgap=10,
            borderwidth=0,
            font=dict(family="monospace"),
        ),
    )
    return fig


# ── Entry point ───────────────────────────────────────────────────────────────


def _generate_wulff(
    structure,
    surface_energies: dict,
    colors: dict | None = None,
    export: Literal["static", "interactive", "gif", "structure"] = "interactive",
    filename: str | None = None,
    **kwargs,
):
    # Visualisation defaults — all overridable via kwargs
    alpha = kwargs.get("alpha", 0.9)
    eye = kwargs.get("eye", dict(x=2.0, y=2.0, z=0.8))
    up = kwargs.get("up", dict(x=0, y=0, z=1))
    center = kwargs.get("center", dict(x=0, y=0, z=0))
    width = kwargs.get("width", 800)
    height = kwargs.get("height", 800)
    scale = kwargs.get("scale", 3)
    n_frames = kwargs.get("n_frames", 72)
    frame_duration = kwargs.get("frame_duration", 60)  # ms per GIF frame

    _default_filenames = dict(
        static="wulff.png",
        interactive="wulff.html",
        gif="wulff.gif",
        structure="wulff.vasp",
    )
    filename = filename or _default_filenames[export]

    miller_list = list(surface_energies.keys())
    wulff = WulffShape(structure.lattice, miller_list, list(surface_energies.values()))
    colors = _assign_colors(miller_list, user_colors=colors)
    traces = _build_traces(wulff, miller_list, colors, alpha, surface_energies)
    fig = _build_fig(traces, eye, up, center)

    if export == "interactive":
        with open(filename, "w") as f:
            f.write(
                fig.to_html(
                    full_html=True,
                    include_plotlyjs="cdn",
                    config={"displaylogo": False},
                )
            )

    elif export == "static":
        fig.write_image(filename, width=width, height=height, scale=scale)

    elif export == "gif":
        from PIL import Image

        frames = []
        for i in range(n_frames):
            eye_i = _rotate_eye(eye, up, 2 * np.pi * i / n_frames)
            fig.update_layout(scene_camera=dict(eye=eye_i, up=up, center=center))
            frames.append(
                Image.open(
                    io.BytesIO(
                        fig.to_image(
                            format="png", width=width, height=height, scale=scale
                        )
                    )
                ).convert("RGBA")
            )
        frames[0].save(
            filename,
            save_all=True,
            append_images=frames[1:],
            loop=0,
            duration=frame_duration,
            optimize=True,
        )

    elif export == "structure":
        raise NotImplementedError("'structure' export is not yet implemented.")
