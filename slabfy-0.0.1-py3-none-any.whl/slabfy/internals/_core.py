"""
slabfy.internals._core
======================
Internal toolbox for slabfy.core — DO NOT import directly in user code.
Use ``from slabfy.core import ...`` instead.

Functions here may change without notice.

FUNCTION MAP
────────────
§1  Constants
    _RECURSIVE_MAX_WARN

§2  Math & pure-value primitives
    _make_vprint, _to_token, _wrap01, _unit_vec, _normalize_miller,
    _normalize_scaling, _rotation_from_axis_angle

§3  Naming, I/O & output helpers
    _component_label, _adparticle_label, _suffix_tokens,
    _output_prefix, _object_id, _resolve_output_dir,
    _format_formula, _layer_formula

§4  Structure & slab geometry
    _axis_layers, _symmetry_summary, _slab_geometry, _struct_snapshot,
    _shift_to_zero, _invert_c, _set_vacuum,
    _is_stoich, _prep_charges,
    _area_ab, _check_contacts, _parse_charge,
    _site_charge, _dipole_along_axis, _coerce_adparticle,
    _restack_layers

§5  Adsorption-site & surface-mapping helpers
    _normalize_site_map, _dedup_frac,
    _exclude_by_dist, _normalize_to_unit,
    _expand_from_unit, _count_sites,
    _parse_bonds, _get_paired_counts,
    _set_paired_counts,
    _map_surface_sites, _map_surface_directions

§6  Surface pipeline
    _resolve_bulk, _process_slab

§7  Epitaxial pipeline
    _resolve_miller_targets,
    _build_ref_surface,
    _build_component_surface,
    _derive_strain, _strain_metrics,
    _pick_if_contacts,
    _region_mask, _density_near_axis,
    _compute_if_sites,
    _resolve_if_miller, _process_epitaxial

§8  Lateral pipeline
    _canonical_pq, _enumerate_dirs,
    _complete_from_pq,
    _reindex_slab, _rotate_struct,
    _align_c_then_b, _match_a_supercells,
    _set_axis_affine, _ensure_b_width,
    _wrap_frac, _recut_axis,
    _group_layers_b, _b_shift_fracs,
    _span_along, _join_along_b,
    _resolve_join_miller, _process_lateral

§9  Decoration pipeline
    _process_decorate

§10 Recollection & filtering
    _recollect, _parse_filter, _apply_filter

§11 Recursive decorator
    _expand_recursive, _recursive_run_token,
    _recursive_sculptor_method
"""

from __future__ import annotations

from slabfy import utils
from slabfy.utils import unique_miller

import os
import glob
import pickle
import base64
import re
import warnings
import functools
import inspect
import numpy as np
from itertools import product as itertools_product

from math import gcd
from typing import Any, Union, Literal, TYPE_CHECKING
from collections import defaultdict

from pymatgen.io.vasp.inputs import Poscar
from pymatgen.core.structure import Structure
from pymatgen.core.surface import Slab, SlabGenerator
from pymatgen.core.lattice import Lattice
from pymatgen.core.periodic_table import DummySpecie
from pymatgen.transformations.standard_transformations import (
    AutoOxiStateDecorationTransformation,
)
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer
from pymatgen.analysis.interfaces.zsl import ZSLGenerator
from pymatgen.analysis.interfaces.coherent_interfaces import (
    CoherentInterfaceBuilder,
)
from pymatgen.analysis.structure_matcher import StructureMatcher

if TYPE_CHECKING:
    from slabfy.core import Bulk, Surface, Interface

# ── §1  Constants ────────────────────────────────────────────────────

_RECURSIVE_MAX_WARN = 100


# ── §1a  Serialization helpers ───────────────────────────────────────


def _slabfy_write(
    obj,
    structure: "Structure",
    filename: str,
    prefix: str,
    *,
    direct: bool = False,
    sort_structure: bool = True,
) -> None:
    """Atomic write of a slabfy object to POSCAR with embedded pickle header.

    Parameters
    ----------
    obj
        The slabfy object (Bulk, Adparticle, Surface, Interface) to serialize.
    structure : Structure
        The pymatgen Structure (or Slab) to write as the POSCAR body.
    filename : str
        Destination file path.
    prefix : str
        B64 prefix constant (e.g. ``utils.BULK_B64_PREFIX``).
    direct : bool
        If ``True``, use direct (fractional) coordinates in POSCAR.
    sort_structure : bool
        If ``True``, sort species in POSCAR output.

    Notes
    -----
    Builds the complete file content in memory before writing to avoid
    the two-step write→reopen pattern that can cause atomicity issues.
    """
    # Clean site properties for POSCAR compatibility
    site_properties_raw = dict(structure.site_properties)
    site_properties_clean: dict[str, list[object]] = {}
    for prop_name, values in site_properties_raw.items():
        if prop_name == "selective_dynamics":
            normalized: list[list[bool]] = []
            for value in values:
                if isinstance(value, (list, tuple)) and len(value) == 3:
                    normalized.append([bool(value[0]), bool(value[1]), bool(value[2])])
                else:
                    normalized.append([True, True, True])
            site_properties_clean[prop_name] = normalized
            continue

        if any(value is None for value in values):
            continue
        site_properties_clean[prop_name] = list(values)

    structure_for_poscar = Structure(
        structure.lattice,
        structure.species,
        structure.frac_coords,
        coords_are_cartesian=False,
        site_properties=site_properties_clean,
    )

    poscar = Poscar(structure_for_poscar, sort_structure=sort_structure)

    # Get POSCAR content as string
    poscar_str = poscar.get_str(direct=direct)
    lines = poscar_str.split("\n")

    # Serialize object and create header
    payload = base64.b64encode(pickle.dumps(obj)).decode("ascii")
    lines[0] = f"{prefix}{payload}"

    # Atomic write: build complete content then write once
    content = "\n".join(lines)
    with open(filename, "w", encoding="utf-8") as fh:
        fh.write(content)


def _slabfy_read(
    cls,
    filename: str,
    prefix: str,
    *,
    sync_from_poscar: bool = True,
    sync_attr: str = "structure",
    sync_ltol: float = 0.01,
    sync_stol: float = 0.01,
    sync_angle_tol: float = 0.5,
):
    """Decode a slabfy object from POSCAR with embedded pickle header.

    Parameters
    ----------
    cls
        The expected class type (Bulk, Adparticle, Surface, Interface).
    filename : str
        Path to the POSCAR file.
    prefix : str
        B64 prefix constant to match (e.g. ``utils.BULK_B64_PREFIX``).
    sync_from_poscar : bool
        When ``True``, compare the POSCAR body against the embedded
        structure attribute. If coordinates/lattice differ but
        composition matches, update the attribute and refresh metadata.
    sync_attr : str
        Name of the structure attribute to sync (``"structure"`` for
        Bulk/Adparticle, ``"slab"`` for Surface/Interface).
    sync_ltol, sync_stol, sync_angle_tol : float
        StructureMatcher tolerances for determining if sync is needed.

    Returns
    -------
    object
        The deserialized slabfy object, optionally with synced structure.

    Raises
    ------
    ValueError
        If the file doesn't contain the expected prefix or payload is invalid.
    """
    with open(filename, "r", encoding="utf-8") as fh:
        first_line = fh.readline().strip()

    if not first_line.startswith(prefix):
        raise ValueError(
            f"File {filename} does not contain serialized {cls.__name__} metadata"
        )

    payload = first_line[len(prefix) :].strip()
    try:
        obj = pickle.loads(base64.b64decode(payload))
    except Exception as exc:
        raise ValueError(
            f"Invalid serialized {cls.__name__} payload in {filename}"
        ) from exc

    if not isinstance(obj, cls):
        raise ValueError(f"Serialized payload in {filename} is not a {cls.__name__}")

    if not sync_from_poscar:
        return obj

    # --- sync structure from POSCAR body --------------------------
    embedded_structure = getattr(obj, sync_attr, None)
    if embedded_structure is None:
        return obj

    try:
        poscar_structure = Poscar.from_file(filename).structure
    except Exception:
        return obj

    matcher = StructureMatcher(
        ltol=sync_ltol,
        stol=sync_stol,
        angle_tol=sync_angle_tol,
        primitive_cell=False,
    )
    if matcher.fit(embedded_structure, poscar_structure):
        return obj

    if (
        embedded_structure.composition.get_el_amt_dict()
        != poscar_structure.composition.get_el_amt_dict()
    ):
        warnings.warn(
            f"POSCAR composition in {filename} differs from "
            "embedded object; returning embedded object "
            f"without updating {sync_attr}.",
            stacklevel=3,
        )
        return obj

    # Composition matches — update structure and refresh metadata
    setattr(obj, sync_attr, poscar_structure)

    # Clear computed site-related caches for Surface/Interface
    if sync_attr == "slab":
        if hasattr(obj, "surface_sites"):
            obj.surface_sites = None
        if hasattr(obj, "surface_directions"):
            obj.surface_directions = None
        if hasattr(obj, "interface_sites"):
            obj.interface_sites = None

    # Refresh metadata if method exists
    if hasattr(obj, "_refresh_metadata"):
        obj._refresh_metadata()

    return obj


# ── §1b  Patched CoherentInterfaceBuilder ────────────────────────────
from itertools import product as _product


class _PatchedCoherentInterfaceBuilder(CoherentInterfaceBuilder):
    """Drop-in subclass of CoherentInterfaceBuilder that prevents the
    label-keyed dict overwrite of terminations (pymatgen issue #3854).

    Internal termination pairs are stored as plain dicts; they are private
    to this class and do not leave internals/_core.py.  The class itself is
    kept because it is intended as a future upstream contribution.

    Key differences from the upstream class
    ----------------------------------------
    - Accepts ``termination_ftol``, ``label_index``, and
      ``filter_out_sym_slabs`` constructor kwargs.
    - ``_find_terminations`` stores every (film_slab, substrate_slab) pair
      as a plain dict indexed by position, never by label alone.
    - ``builder.terminations`` exposes unique ``(film_handle, sub_handle)``
      tuple pairs that encode the slab-index prefix, guaranteeing no
      collision even when two slabs share the same symmetry label.
    - ``get_interfaces(termination=...)`` resolves shifts via the index
      stored in the dict, then delegates supercell + Interface construction
      to the parent class via temporary ``_terminations`` patching.
    """

    def __init__(
        self,
        substrate_structure,
        film_structure,
        film_miller,
        substrate_miller,
        zslgen=None,
        termination_ftol: float = 0.25,
        label_index: bool = True,
        filter_out_sym_slabs: bool = False,
    ):
        self._termination_ftol = termination_ftol
        self._label_index = label_index
        self._filter_out_sym_slabs = filter_out_sym_slabs
        # super().__init__ triggers _find_matches then _find_terminations.
        super().__init__(
            substrate_structure=substrate_structure,
            film_structure=film_structure,
            film_miller=film_miller,
            substrate_miller=substrate_miller,
            zslgen=zslgen,
        )

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _sg(self, structure, miller, min_slab_size, in_unit_planes=True):
        from pymatgen.core.surface import SlabGenerator

        return SlabGenerator(
            structure,
            miller,
            min_slab_size=min_slab_size,
            min_vacuum_size=3,
            in_unit_planes=in_unit_planes,
            center_slab=True,
            primitive=True,
            reorient_lattice=False,
        )

    def _get_slabs_safe(self, sg):
        """Call get_slabs with graceful kwarg fallback across pymatgen versions."""
        for kwargs in [
            {
                "ftol": self._termination_ftol,
                "filter_out_sym_slabs": self._filter_out_sym_slabs,
            },
            {"filter_out_sym_slabs": self._filter_out_sym_slabs},
            {"ftol": self._termination_ftol},
            {},
        ]:
            try:
                return sg.get_slabs(**kwargs)
            except TypeError:
                continue
        return sg.get_slabs()

    @staticmethod
    def _make_handles(labels: list[str], always_prefix: bool) -> list[str]:
        """Build unique display handles from a list of labels.
        When always_prefix=True or a label appears more than once, the
        slab index is prepended to guarantee uniqueness.
        """
        counts: dict[str, int] = {}
        for lbl in labels:
            counts[lbl] = counts.get(lbl, 0) + 1
        return [
            f"{idx}:{lbl}" if (always_prefix or counts[lbl] > 1) else lbl
            for idx, lbl in enumerate(labels)
        ]

    def _resolve_record(self, termination):
        """Resolve termination to an internal record dict.

        Accepts both indexed handle pairs and plain label pairs.
        """
        if termination in self._termination_lookup:
            return self._termination_lookup[termination]

        matches = [
            r
            for r in self._termination_records
            if (r["film_label"], r["substrate_label"]) == termination
        ]
        if len(matches) == 1:
            return matches[0]
        elif len(matches) > 1:
            available = ", ".join(str(r["key"]) for r in matches)
            raise KeyError(
                f"Ambiguous termination {termination!r}. "
                f"Use an indexed handle: {available}"
            )
        else:
            raise KeyError(
                f"Termination {termination!r} not found. "
                f"First 5 available: {self.terminations[:5]}"
            )

    # ------------------------------------------------------------------
    # Override: _find_terminations
    # ------------------------------------------------------------------

    def _find_terminations(self):
        from pymatgen.core.interface import label_termination

        film_sg = self._sg(self.film_structure, self.film_miller, min_slab_size=1)
        sub_sg = self._sg(
            self.substrate_structure, self.substrate_miller, min_slab_size=1
        )

        film_slabs = self._get_slabs_safe(film_sg)
        sub_slabs = self._get_slabs_safe(sub_sg)

        film_labels = [str(label_termination(s)) for s in film_slabs]
        sub_labels = [str(label_termination(s)) for s in sub_slabs]
        film_handles = self._make_handles(film_labels, always_prefix=self._label_index)
        sub_handles = self._make_handles(sub_labels, always_prefix=self._label_index)
        film_shifts = [float(s.shift) for s in film_slabs]
        sub_shifts = [float(s.shift) for s in sub_slabs]

        # Store as plain dicts — private to this class.
        self._termination_records: list[dict] = [
            {
                "film_index": fi,
                "substrate_index": si,
                "film_label": fl,
                "substrate_label": sl,
                "film_handle": fh,
                "substrate_handle": sh,
                "film_shift": fs,
                "substrate_shift": ss,
                "key": (fh, sh),
            }
            for (fi, fl, fh, fs), (si, sl, sh, ss) in _product(
                zip(range(len(film_labels)), film_labels, film_handles, film_shifts),
                zip(range(len(sub_labels)), sub_labels, sub_handles, sub_shifts),
            )
        ]

        # Lookup by unique key.
        self._termination_lookup: dict[tuple, dict] = {
            rec["key"]: rec for rec in self._termination_records
        }
        # Public attribute expected by external callers (list of key tuples).
        self.terminations: list[tuple[str, str]] = list(self._termination_lookup)

    # ------------------------------------------------------------------
    # Override: get_interfaces
    # ------------------------------------------------------------------

    def get_interfaces(
        self,
        termination,
        gap: float = 2.0,
        vacuum_over_film: float = 20.0,
        film_thickness: float = 1,
        substrate_thickness: float = 1,
        in_layers: bool = True,
    ):
        """Yield Interface objects for the given termination pair.

        Resolves (film_shift, substrate_shift) from the index-safe dict,
        then delegates supercell + Interface construction to the parent by
        temporarily injecting the resolved shifts into the parent's
        ``_terminations`` dict.  This avoids importing private pymatgen
        helpers and keeps all ZSL match logic unchanged.
        """
        rec = self._resolve_record(termination)

        # Temporarily set parent's _terminations so super() resolves
        # the correct shift pair for this specific termination.
        parent_key = (rec["film_label"], rec["substrate_label"])
        saved_terminations = getattr(self, "_terminations", None)
        saved_terminations_list = list(self.terminations)
        try:
            self._terminations = {
                parent_key: (rec["film_shift"], rec["substrate_shift"]),
            }
            self.terminations = [parent_key]
            for iface in super().get_interfaces(
                termination=parent_key,
                gap=gap,
                vacuum_over_film=vacuum_over_film,
                film_thickness=film_thickness,
                substrate_thickness=substrate_thickness,
                in_layers=in_layers,
            ):
                # Inject rich termination metadata into interface_properties.
                props = dict(getattr(iface, "interface_properties", {}) or {})
                props.update(
                    termination=rec["key"],
                    termination_plain=(
                        rec["film_label"],
                        rec["substrate_label"],
                    ),
                    film_termination=rec["film_handle"],
                    substrate_termination=rec["substrate_handle"],
                    film_termination_index=rec["film_index"],
                    substrate_termination_index=rec["substrate_index"],
                    film_shift=rec["film_shift"],
                    substrate_shift=rec["substrate_shift"],
                    film_thickness=film_thickness,
                    substrate_thickness=substrate_thickness,
                )
                iface.interface_properties = props
                yield iface
        finally:
            # Restore original state.
            self._termination_lookup = {
                rec["key"]: rec for rec in self._termination_records
            }
            self.terminations = saved_terminations_list
            if saved_terminations is not None:
                self._terminations = saved_terminations


# ── §2  Math & pure-value primitives ──────────────────────────────────


def _make_vprint(tag: str, verbose: bool):
    """Return a conditional printer: ``_vprint(msg)`` → ``print(f"[{tag}] {msg}")``."""

    def _vprint(message: str) -> None:
        if verbose:
            print(f"[{tag}] {message}")

    return _vprint


def _to_token(value: Any, *, extra_safe: str = "") -> str:
    """Convert *value* to a filesystem-safe token string.

    Characters in A-Za-z0-9._- are always kept. Additional characters
    can be preserved via *extra_safe*. Leading/trailing hyphens stripped.
    """
    text = str(value).strip().replace(" ", "")
    safe_pattern = r"[^A-Za-z0-9._\-" + re.escape(extra_safe) + r"]+"
    text = re.sub(safe_pattern, "-", text)
    text = text.strip("-")
    return text or ""


def _wrap01(x: float, eps: float = 1e-12) -> float:
    """Wrap *x* to [0, 1) and snap values near 0 or 1 to 0.

    Parameters
    ----------
    x : float
        Value to wrap.
    eps : float
        Snapping tolerance near boundaries.

    Returns
    -------
    float
        Wrapped value in [0, 1).
    """
    val = float(x) % 1.0
    if val < eps or val > 1.0 - eps:
        return 0.0
    return val


def _unit_vec(vector: np.ndarray) -> np.ndarray:
    norm = float(np.linalg.norm(vector))
    if norm < 1e-12:
        raise ValueError("zero vector")
    return np.array(vector, dtype=float) / norm


def _normalize_miller(miller) -> tuple[int, ...]:
    """Normalize Miller indices.

    Accepts a tuple or list of 3 or 4 integers (or numeric strings). If 4 indices
    are provided (h, k, i, l) the redundant i is dropped and (h, k, l) is returned.
    """
    if not isinstance(miller, tuple):
        raise ValueError("miller must be provided as a tuple")

    if len(miller) not in (3, 4):
        raise ValueError("miller must have 3 or 4 elements")

    # convert elements to integers (allow negative values)
    try:
        ints = [int(x) for x in miller]
    except Exception:
        raise ValueError("miller elements must be integers")

    if len(ints) == 4:
        ints = [ints[0], ints[1], ints[3]]

    else:
        ints = ints[:3]

    return tuple(ints)


def _normalize_scaling(
    value: Any,
    default: tuple[int, int, int] = (1, 1, 1),
) -> tuple[int, int, int]:
    if value is None:
        return default

    if isinstance(value, (int, float, np.integer, np.floating)):
        c_scale = int(round(float(value)))
        c_scale = max(c_scale, 1)
        return (1, 1, c_scale)

    if isinstance(value, (tuple, list)) and len(value) == 3:
        normalized = tuple(max(int(round(float(component))), 1) for component in value)
        return normalized

    raise ValueError("scaling must be a scalar or tuple/list with 3 values")


def _rotation_from_axis_angle(
    axis_hat: np.ndarray,
    angle: float,
) -> np.ndarray:
    axis = _unit_vec(np.array(axis_hat, dtype=float))
    cross = np.array(
        [
            [0.0, -axis[2], axis[1]],
            [axis[2], 0.0, -axis[0]],
            [-axis[1], axis[0], 0.0],
        ],
        dtype=float,
    )
    ident = np.eye(3, dtype=float)
    return ident + (np.sin(angle) * cross) + ((1.0 - np.cos(angle)) * (cross @ cross))


# ── §3  Naming, I/O & output helpers ──────────────────────────────────


def _component_label(
    structure: Structure,
    miller: Union[tuple, int, None],
) -> str:
    """Build a compact label like 'Al2O3(100)' for output naming."""
    if miller is None:
        miller_str = ""
    elif isinstance(miller, int):
        miller_str = str(miller)
    else:
        try:
            normalized = _normalize_miller(tuple(miller))
            miller_str = "".join(str(int(v)) for v in normalized)
        except Exception:
            miller_str = _to_token(miller)
    return f"{structure.composition.reduced_formula}({miller_str})"


def _adparticle_label(adparticle: Any) -> str:
    if adparticle is None:
        return ""
    if isinstance(adparticle, Structure):
        return adparticle.composition.reduced_formula
    if isinstance(adparticle, str) and os.path.exists(adparticle):
        try:
            return Poscar.from_file(adparticle).structure.composition.reduced_formula
        except Exception:
            return _to_token(
                os.path.splitext(os.path.basename(adparticle))[0], extra_safe="()+"
            )
    return _to_token(adparticle, extra_safe="()+")


def _suffix_tokens(
    mapping: dict[str, Any],
    *,
    value_first: bool,
) -> list[str]:
    tokens: list[str] = []
    for key, value in mapping.items():
        key_text = _to_token(key, extra_safe="()+")
        if value is None:
            value_text = ""
        elif isinstance(value, bool):
            value_text = "1" if value else "0"
        elif isinstance(value, float):
            if abs(value - round(value)) < 1e-9:
                value_text = f"{value:.1f}"
            else:
                value_text = f"{value:.4f}".rstrip("0").rstrip(".")
        elif isinstance(value, tuple):
            try:
                normalized = _normalize_miller(tuple(value))
                value_text = "".join(str(int(v)) for v in normalized)
            except Exception:
                value_text = _to_token(value, extra_safe="()+")
        else:
            value_text = _to_token(value, extra_safe="()+")
        token = f"{value_text}{key_text}" if value_first else f"{key_text}{value_text}"
        tokens.append(token)
    return tokens


def _output_prefix(
    structure1: Structure,
    miller1: Union[tuple, int, None],
    structure2: Structure | None = None,
    miller2: Union[tuple, int, None] | None = None,
    adparticle: Any = None,
) -> str:
    parts = [_component_label(structure1, miller1)]
    if structure2 is not None:
        parts.append(_component_label(structure2, miller2))
    if adparticle is not None:
        parts.append(_adparticle_label(adparticle))
    return "_".join(_to_token(part, extra_safe="()+") for part in parts)


def _object_id(obj: Any, *, prefix: str, zpad: int = 2) -> str:
    """Return a compact string identifier for a Surface or Interface."""
    slab_index = int(getattr(obj, "slab_index", None) or 0)
    termination = str(getattr(obj, "slab_termination", None) or "UP").lower()
    return f"{prefix}{slab_index:0{zpad}d}{termination}"


def _resolve_output_dir(
    method_name: str,
    structure1: Structure,
    miller1: Union[tuple, int, None],
    structure2: Structure | None = None,
    miller2: Union[tuple, int, None] | None = None,
    adparticle: Any = None,
    file_args: dict[str, Any] | None = None,
    run_root: str | None = None,
) -> str:
    """Build and create the output directory for a Sculptor method.

    Parameters
    ----------
    run_root : str | None
        Optional subdirectory prefix injected by the recursive
        decorator.  When set, the output directory is nested
        under ``run_root/`` instead of ``./``.
    """
    parts = [method_name]
    parts.append(
        _output_prefix(
            structure1=structure1,
            miller1=miller1,
            structure2=structure2,
            miller2=miller2,
            adparticle=adparticle,
        )
    )
    if file_args:
        parts.extend(_suffix_tokens(file_args, value_first=True))

    dirname = "_".join(
        _to_token(part, extra_safe="()+") for part in parts if str(part).strip()
    )
    base = run_root if run_root else "."
    out_root = os.path.join(base, dirname)
    os.makedirs(out_root, exist_ok=True)
    return out_root


def _format_formula(structure: Structure) -> str:
    """Format bulk formula as full_formula (reduced_formula)."""
    full_formula = "".join(str(structure.composition.formula).split(" "))
    reduced_formula = structure.composition.reduced_formula
    return f"{full_formula} ({reduced_formula})"


def _layer_formula(values: list[str]) -> str:
    """Return reduced layer formula and net charge label."""
    counts = defaultdict(int)
    total_charge = 0.0

    for token in values:
        element_match = re.match(r"([A-Z][a-z]?)", token)
        if not element_match:
            continue
        element = element_match.group(1)
        counts[element] += 1
        total_charge += _parse_charge(token)

    formula_parts = []
    for element, amount in counts.items():
        if amount == 1:
            formula_parts.append(element)
        else:
            formula_parts.append(f"{element}{amount}")
    formula = "".join(formula_parts) if formula_parts else "Unknown"

    rounded_charge = round(total_charge)
    if abs(total_charge - rounded_charge) < 1e-6:
        charge_value = int(rounded_charge)
        if charge_value > 0:
            charge_label = f"+{charge_value}"
        else:
            charge_label = str(charge_value)
    else:
        charge_label = f"{total_charge:+.2f}"

    return f"{formula} ({charge_label})"


# ── §4  Structure & slab geometry ─────────────────────────────────────


def _axis_layers(
    structure: Structure,
    axis: Literal["a", "b", "c"] = "c",
    *,
    decimals: int = 6,
) -> dict[float, list[str]]:
    axis_key = str(axis).lower()
    axis_index = {"a": 0, "b": 1, "c": 2}.get(axis_key, 2)

    if len(structure) == 0:
        return {}

    lattice_rows = np.array(structure.lattice.matrix, dtype=float)
    axis_vector = np.array(lattice_rows[axis_index], dtype=float)
    axis_hat = _unit_vec(axis_vector)
    axis_length = float(np.linalg.norm(axis_vector))
    if axis_length <= 1e-12:
        return {}

    projections = np.dot(structure.cart_coords.astype(float), axis_hat)
    min_projection = float(np.min(projections))
    shifted = projections - min_projection

    tol_wrap = 10.0 ** (-decimals)
    normalized = np.mod(shifted, axis_length)
    normalized[np.abs(normalized - axis_length) <= tol_wrap] = 0.0
    normalized[np.abs(normalized) <= tol_wrap] = 0.0

    layers: dict[float, list[str]] = defaultdict(list)
    for idx, position in enumerate(normalized):
        key = round(float(position), decimals)
        layers[key].append(str(structure[idx].specie))

    return dict(sorted(layers.items(), reverse=True))


def _symmetry_summary(
    structure: Structure,
    symprec: float = 0.01,
    angle_tolerance: float = 5.0,
) -> dict[str, Any]:
    """Return basic crystallographic symmetry metadata for a structure.

    Parameters
    ----------
    structure : Structure
        Input pymatgen Structure.
    symprec : float
        Symmetry tolerance (angstrom).
    angle_tolerance : float
        Angle tolerance (degrees).
    """
    sga = SpacegroupAnalyzer(
        structure,
        symprec=float(symprec),
        angle_tolerance=float(angle_tolerance),
    )

    return {
        "spacegroup_symbol": sga.get_space_group_symbol(),
        "spacegroup_number": int(sga.get_space_group_number()),
        "crystal_system": sga.get_crystal_system(),
        "lattice_type": sga.get_lattice_type(),
        "point_group": sga.get_point_group_symbol(),
        "symprec": float(symprec),
        "angle_tolerance": float(angle_tolerance),
    }


def _slab_geometry(slab: Slab | Structure) -> tuple[float, float]:
    """Return slab thickness and vacuum thickness in Angstrom."""
    c_vector = np.array(slab.lattice.matrix[2], dtype=float)
    c_length = float(np.linalg.norm(c_vector))
    if c_length <= 1e-12:
        return 0.0, 0.0

    axis_hat = _unit_vec(c_vector)
    projections = np.dot(slab.cart_coords.astype(float), axis_hat)
    slab_thickness = float(np.max(projections) - np.min(projections))
    vacuum = float(max(c_length - slab_thickness, 0.0))
    return slab_thickness, vacuum


def _struct_snapshot(slab: Slab | Structure) -> Structure:
    """Build a geometry-preserving Structure snapshot from Slab/Structure."""
    if isinstance(slab, Structure) and not isinstance(slab, Slab):
        return Structure(
            slab.lattice,
            slab.species,
            slab.frac_coords,
            coords_are_cartesian=False,
            site_properties={
                key: list(values) for key, values in slab.site_properties.items()
            },
        )

    site_properties = {
        key: [site.properties.get(key) for site in slab] for key in slab.site_properties
    }
    return Structure(
        slab.lattice,
        slab.species,
        slab.frac_coords,
        coords_are_cartesian=False,
        site_properties=site_properties,
    )


def _shift_to_zero(
    slab: Slab | Structure,
) -> Slab | Structure:
    """Return a copy of ``slab`` translated so min Cartesian z is 0."""
    cart_coords = np.array(slab.cart_coords, dtype=float)
    z_min = float(np.min(cart_coords[:, 2]))
    if abs(z_min) <= 1e-12:
        return slab

    translated = cart_coords.copy()
    translated[:, 2] -= z_min

    site_properties = {
        key: [site.properties.get(key) for site in slab] for key in slab.site_properties
    }

    if isinstance(slab, Slab):
        return Slab(
            slab.lattice,
            slab.species,
            translated,
            slab.miller_index,
            slab.oriented_unit_cell,
            slab.shift,
            slab.scale_factor,
            coords_are_cartesian=True,
            site_properties=site_properties,
        )

    return Structure(
        slab.lattice,
        slab.species,
        translated,
        coords_are_cartesian=True,
        site_properties=site_properties,
    )


def _invert_c(obj: Slab | Structure) -> Slab | Structure:
    """Return *obj* mirrored along Cartesian z, preserving cell geometry."""
    shifted = _shift_to_zero(obj)
    cart_coords = np.array(shifted.cart_coords, dtype=float)
    z_max = float(np.max(cart_coords[:, 2]))
    mirrored = cart_coords.copy()
    mirrored[:, 2] = z_max - mirrored[:, 2]

    site_properties = {
        key: [site.properties.get(key) for site in shifted]
        for key in shifted.site_properties
    }
    if isinstance(obj, Slab):
        result = Slab(
            shifted.lattice,
            shifted.species,
            mirrored,
            obj.miller_index,
            obj.oriented_unit_cell,
            obj.shift,
            obj.scale_factor,
            coords_are_cartesian=True,
            site_properties=site_properties,
        )
    else:
        result = Structure(
            shifted.lattice,
            shifted.species,
            mirrored,
            coords_are_cartesian=True,
            site_properties=site_properties,
        )
    return _shift_to_zero(result)


def _set_vacuum(slab: Slab, target_vacuum: float) -> Slab:
    """Return a slab copy with exact requested vacuum while preserving positions."""
    cart_coords = slab.cart_coords.copy()
    z_min = float(np.min(cart_coords[:, 2]))
    cart_coords[:, 2] = cart_coords[:, 2] - z_min
    slab_thickness = float(np.max(cart_coords[:, 2]))
    new_c = slab_thickness + float(target_vacuum)
    lattice_matrix = slab.lattice.matrix.copy()
    c_vector = lattice_matrix[2]
    norm_c = np.linalg.norm(c_vector)
    if norm_c <= 1e-12:
        return slab
    lattice_matrix[2] = (c_vector / norm_c) * new_c

    site_properties = {
        key: [site.properties.get(key) for site in slab] for key in slab.site_properties
    }
    updated = Slab(
        Lattice(lattice_matrix),
        slab.species,
        cart_coords,
        slab.miller_index,
        slab.oriented_unit_cell,
        slab.shift,
        slab.scale_factor,
        coords_are_cartesian=True,
        site_properties=site_properties,
    )
    return updated


def _is_stoich(structure_ref: Structure, slab: Slab) -> bool:
    """Return whether slab composition is proportional to bulk reference."""
    try:
        return (
            structure_ref.composition.reduced_composition
            == slab.composition.reduced_composition
        )
    except Exception:
        return False


def _prep_charges(structure: Structure, verbose: bool) -> Structure:
    """Return structure with charge information if possible.

    Priority:
    1) Keep charges if they are already present.
    2) Try AutoOxiStateDecorationTransformation.
    3) Fall back to uncharged structure.
    """
    already_charged = all(
        getattr(species, "oxi_state", None) is not None
        for site in structure
        for species, _amount in site.species.items()
    )
    if already_charged:
        return structure

    try:
        return AutoOxiStateDecorationTransformation().apply_transformation(structure)
    except Exception:
        if verbose:
            print(
                "Warning: could not assign oxidation states; using uncharged structure"
            )
        return structure


def _area_ab(structure: Structure) -> float:
    a_vec = structure.lattice.matrix[0]
    b_vec = structure.lattice.matrix[1]
    return float(np.linalg.norm(np.cross(a_vec, b_vec)))


def _check_contacts(
    structure: Structure,
    threshold: float = 0.8,
) -> list[tuple[int, int, float]]:
    """Return pairs of site indices with inter-atomic distance below *threshold*."""
    center, point, _, dist = structure.get_neighbor_list(r=threshold)
    seen: set[tuple[int, int]] = set()
    pairs: list[tuple[int, int, float]] = []
    for c_idx, p_idx, d in zip(center, point, dist):
        key = (min(int(c_idx), int(p_idx)), max(int(c_idx), int(p_idx)))
        if key not in seen:
            seen.add(key)
            pairs.append((int(c_idx), int(p_idx), float(d)))
    return pairs


def _parse_charge(token: str) -> float:
    """Parse oxidation-state charge from species-like token (e.g., Ti4+, O2-)."""
    match = re.search(r"(\d*\.?\d*)([+-])$", token)
    if not match:
        return 0.0
    magnitude = float(match.group(1)) if match.group(1) else 1.0
    return magnitude if match.group(2) == "+" else -magnitude


def _site_charge(site: Any) -> float:
    if "charge" in site.properties:
        return float(site.properties["charge"])
    if "oxi_state" in site.properties:
        return float(site.properties["oxi_state"])
    specie = getattr(site, "specie", None)
    if specie is not None and getattr(specie, "oxi_state", None) is not None:
        return float(specie.oxi_state)
    return 0.0


def _dipole_along_axis(
    structure: Structure,
    axis_vector: np.ndarray,
    *,
    center_position: float | None = None,
    window_depth: float | None = None,
) -> float:
    axis = _unit_vec(np.array(axis_vector, dtype=float))
    projections = np.dot(structure.cart_coords.astype(float), axis)
    charges = np.array([_site_charge(site) for site in structure], dtype=float)

    axis_length = float(np.linalg.norm(np.array(axis_vector, dtype=float)))
    volume = float(abs(np.linalg.det(structure.lattice.matrix)))
    if axis_length <= 1e-12 or volume <= 1e-12:
        return 0.0
    area_perp = volume / axis_length
    if area_perp <= 1e-12:
        return 0.0

    if center_position is not None and window_depth is not None:
        mask = (projections >= float(center_position) - float(window_depth)) & (
            projections <= float(center_position) + float(window_depth)
        )
        if not np.any(mask):
            return 0.0
        projections = projections[mask]
        charges = charges[mask]
        centered = projections - float(center_position)
    else:
        centered = projections - float(np.mean(projections))

    dipole = float(np.sum(charges * centered))
    return dipole / area_perp


def _coerce_adparticle(value: Any) -> Structure | None:
    if value is None:
        return None

    if isinstance(value, Structure):
        return value.copy()

    if isinstance(value, str):
        if os.path.exists(value):
            return Poscar.from_file(value).structure

        box_size = 10.0
        center = box_size / 2.0
        try:
            return Structure(
                Lattice.cubic(box_size),
                [value],
                [[center, center, center]],
                coords_are_cartesian=True,
            )
        except Exception:
            return Structure(
                Lattice.cubic(box_size),
                [DummySpecie(value)],
                [[center, center, center]],
                coords_are_cartesian=True,
            )

    raise ValueError("adparticle must be a Structure, string, or None")


def _restack_layers(
    structure: Structure,
    target_layers: list[int],
    stacking_layers: list[int],
    axis: Literal["a", "b", "c"] = "c",
) -> Structure:
    """Rearrange atomic layers along *axis* and return a new Structure.

    Parameters
    ----------
    structure : Structure
        Input structure (Slab or Structure with vacuum).
    target_layers : list[int]
        0-based layer indices defining the contiguous range that
        will be replaced.  Negative indices are supported.
    stacking_layers : list[int]
        0-based layer indices whose atoms replace the target range.
        An empty list removes the target range outright.
    axis : {'a', 'b', 'c'}
        Lattice axis along which layers are identified.

    Returns
    -------
    Structure
        Rebuilt structure with adjusted lattice vector along *axis*
        so that the vacuum gap is preserved.
    """
    axis_key = str(axis).lower()
    axis_index = {"a": 0, "b": 1, "c": 2}.get(axis_key, 2)

    layer_map = _axis_layers(structure, axis=axis_key)
    if not layer_map:
        raise ValueError("structure has no detectable layers")

    # Sorted positions: index 0 = top (highest), index N-1 = bottom
    positions = list(layer_map.keys())
    n_layers = len(positions)

    # --- resolve negative indices --------------------------------
    def _resolve(idx: int) -> int:
        resolved = idx if idx >= 0 else n_layers + idx
        if not 0 <= resolved < n_layers:
            raise IndexError(
                f"layer index {idx} out of range [{-n_layers}, {n_layers - 1}]"
            )
        return resolved

    resolved_target = [_resolve(i) for i in target_layers]
    resolved_stack = [_resolve(i) for i in stacking_layers]

    # Target must span a contiguous range
    target_lo = min(resolved_target)
    target_hi = max(resolved_target)
    target_range = set(range(target_lo, target_hi + 1))

    # --- partition layers into three groups ----------------------
    # Groups preserve descending-height order (same as layer_map)
    before_indices = [i for i in range(n_layers) if i < target_lo]
    after_indices = [i for i in range(n_layers) if i > target_hi]
    replacement_indices = resolved_stack

    # --- gather per-group Cartesian coordinates ------------------
    lattice_rows = np.array(structure.lattice.matrix, dtype=float)
    axis_vector = np.array(lattice_rows[axis_index], dtype=float)
    axis_hat = _unit_vec(axis_vector)
    axis_length = float(np.linalg.norm(axis_vector))

    projections = np.dot(
        structure.cart_coords.astype(float),
        axis_hat,
    )
    min_proj = float(np.min(projections))

    # Map each site to its layer index in the sorted positions list
    tol = 10.0**-6
    normalized = np.mod(projections - min_proj, axis_length)
    normalized[np.abs(normalized - axis_length) <= tol] = 0.0
    normalized[np.abs(normalized) <= tol] = 0.0

    site_layer: list[int] = []
    for site_pos in normalized:
        rounded = round(float(site_pos), 6)
        matched = False
        for layer_idx, layer_pos in enumerate(positions):
            if abs(rounded - layer_pos) <= tol:
                site_layer.append(layer_idx)
                matched = True
                break
        if not matched:
            site_layer.append(-1)

    # --- compute thickness of each group -------------------------
    def _group_thickness(indices: list[int]) -> float:
        """Thickness of a set of layers (max - min position)."""
        if len(indices) <= 1:
            return 0.0
        group_positions = [positions[i] for i in indices]
        return max(group_positions) - min(group_positions)

    # Inter-layer gap: average spacing used to pad single layers
    if n_layers >= 2:
        all_gaps = sorted(
            abs(positions[i] - positions[i + 1]) for i in range(n_layers - 1)
        )
        avg_gap = float(np.mean(all_gaps))
    else:
        avg_gap = 0.0

    before_thickness = _group_thickness(before_indices)
    replacement_thickness = _group_thickness(replacement_indices)
    after_thickness = _group_thickness(after_indices)

    # Original slab thickness (max - min of all atoms)
    original_min = float(np.min(projections))
    original_max = float(np.max(projections))
    original_slab_thickness = original_max - original_min
    original_vacuum = axis_length - original_slab_thickness

    # --- compute anchor and shift offsets ------------------------
    # Anchor: position of the first target layer
    anchor_pos = positions[target_lo]

    # Replacement group base: position of lowest-height replacement
    if replacement_indices:
        rep_positions = [positions[i] for i in replacement_indices]
        rep_min = min(rep_positions)
        rep_max = max(rep_positions)
    else:
        rep_min = 0.0
        rep_max = 0.0

    # After-group will be shifted so its top aligns seamlessly
    if after_indices:
        after_top = positions[min(after_indices)]
    else:
        after_top = 0.0

    # --- build new site list -------------------------------------
    new_species: list = []
    new_coords: list[np.ndarray] = []
    new_site_props: dict[str, list] = {key: [] for key in structure.site_properties}
    cart_coords = np.array(structure.cart_coords, dtype=float)

    def _add_sites(
        layer_indices: list[int],
        shift: float,
    ) -> None:
        """Append sites from given layers, shifted along axis."""
        for site_idx in range(len(structure)):
            if site_layer[site_idx] in layer_indices:
                coord = cart_coords[site_idx].copy()
                coord += axis_hat * shift
                new_species.append(structure[site_idx].species)
                new_coords.append(coord)
                for key in new_site_props:
                    new_site_props[key].append(structure[site_idx].properties.get(key))

    # Before group: no shift needed (stays at original positions)
    _add_sites(before_indices, shift=0.0)

    # Replacement group: shift so rep_max aligns with anchor_pos
    if replacement_indices:
        rep_shift = anchor_pos - rep_max
        _add_sites(replacement_indices, shift=rep_shift)
        # After-group shifts to below replacement group
        if after_indices:
            # New bottom of replacement = rep_min + rep_shift
            new_rep_bottom = rep_min + rep_shift
            after_shift = (new_rep_bottom - avg_gap) - after_top
            _add_sites(after_indices, shift=after_shift)
    else:
        # Empty stacking: after-group shifts up to anchor position
        if after_indices:
            after_shift = anchor_pos - after_top
            _add_sites(after_indices, shift=after_shift)

    if not new_coords:
        raise ValueError("restacking produced an empty structure")

    coords_array = np.array(new_coords, dtype=float)

    # --- adjust lattice vector to preserve vacuum ----------------
    new_proj = np.dot(coords_array, axis_hat)
    new_slab_thickness = float(np.max(new_proj) - np.min(new_proj))
    new_axis_length = new_slab_thickness + original_vacuum
    new_matrix = lattice_rows.copy()
    axis_norm = float(np.linalg.norm(new_matrix[axis_index]))
    if axis_norm > 1e-12:
        new_matrix[axis_index] = new_matrix[axis_index] / axis_norm * new_axis_length

    # Shift all coords so minimum projection is at 0
    min_new_proj = float(np.min(np.dot(coords_array, axis_hat)))
    coords_array -= axis_hat * min_new_proj

    new_lattice = Lattice(new_matrix)

    if isinstance(structure, Slab):
        return Slab(
            new_lattice,
            new_species,
            coords_array,
            structure.miller_index,
            structure.oriented_unit_cell,
            structure.shift,
            structure.scale_factor,
            coords_are_cartesian=True,
            site_properties=new_site_props,
        )

    return Structure(
        new_lattice,
        new_species,
        coords_array,
        coords_are_cartesian=True,
        site_properties=new_site_props,
    )


# ── §5  Adsorption-site & surface-mapping helpers ─────────────────────


def _normalize_site_map(
    surf_sites: dict[str, Any] | None,
) -> dict[str, list[np.ndarray]]:
    normalized: dict[str, list[np.ndarray]] = {
        "ontop": [],
        "bridge": [],
        "hollow": [],
    }
    if not isinstance(surf_sites, dict):
        return normalized

    for key in ("ontop", "bridge", "hollow"):
        values = surf_sites.get(key, [])
        if not isinstance(values, (list, tuple, np.ndarray)):
            continue
        for value in values:
            try:
                coord = np.array(value, dtype=float)
            except Exception:
                continue
            if coord.shape != (3,):
                continue
            normalized[key].append(coord)
    return normalized


def _dedup_frac(
    frac: np.ndarray,
    *,
    tol: float = 1e-3,
) -> np.ndarray:
    """Deduplicate (N, 3) fractional coordinates within *tol*.

    Parameters
    ----------
    frac : np.ndarray
        Array of shape ``(N, 3)`` with fractional coordinates.
    tol : float
        Tolerance for rounding-based deduplication.

    Returns
    -------
    np.ndarray
        Unique subset of shape ``(M, 3)`` where ``M <= N``.
    """
    if frac.ndim != 2 or frac.shape[1] != 3:
        return frac
    if frac.shape[0] == 0:
        return frac
    decimals = max(0, int(round(-np.log10(tol))))
    rounded = np.round(frac, decimals=decimals)
    seen: set[tuple[float, ...]] = set()
    unique_indices: list[int] = []
    for idx in range(rounded.shape[0]):
        key = tuple(rounded[idx])
        if key not in seen:
            seen.add(key)
            unique_indices.append(idx)
    return frac[unique_indices]


def _exclude_by_dist(
    base_points: list[np.ndarray],
    forbidden_points: list[np.ndarray],
    *,
    tol: float = 0.35,
) -> list[np.ndarray]:
    if not base_points:
        return []
    if not forbidden_points:
        return list(base_points)

    kept: list[np.ndarray] = []
    for point in base_points:
        is_forbidden = False
        for ref in forbidden_points:
            if float(np.linalg.norm(point - ref)) <= float(tol):
                is_forbidden = True
                break
        if not is_forbidden:
            kept.append(point)
    return kept


def _normalize_to_unit(
    site_map: dict[str, Any],
    *,
    lattice: "Lattice",
    na: int,
    nb: int,
    periodic_axes: tuple[int, ...] = (0, 1),
    tol: float = 1e-3,
) -> dict[str, Any]:
    """Collapse supercell site map to unique sites per unit cell.

    For each site kind (``ontop``, ``bridge``, ``hollow``), Cartesian
    coordinates are converted to fractional, folded into the base
    unit cell using the scaling factors *na* / *nb*, deduplicated,
    and converted back.  Non-site keys (e.g. ``__paired_ads_counts__``)
    are passed through unchanged.

    Parameters
    ----------
    site_map : dict[str, Any]
        Raw site map with ``ontop`` / ``bridge`` / ``hollow`` lists
        of Cartesian coordinates, plus optional metadata keys.
    lattice : Lattice
        Lattice of the slab the sites were computed on.
    na, nb : int
        In-plane supercell scaling factors.
    periodic_axes : tuple[int, ...]
        Axes along which to fold (0 → a, 1 → b).
    tol : float
        Deduplication tolerance in fractional space.

    Returns
    -------
    dict[str, Any]
        Site map with unique-per-unit-cell coordinates.
    """
    site_keys = {"ontop", "bridge", "hollow"}
    result: dict[str, Any] = {}
    scale = [1, 1, 1]
    if 0 in periodic_axes:
        scale[0] = max(int(na), 1)
    if 1 in periodic_axes:
        scale[1] = max(int(nb), 1)

    for key, value in site_map.items():
        if key not in site_keys:
            result[key] = value
            continue

        pts = value
        if not isinstance(pts, (list, tuple, np.ndarray)):
            result[key] = pts
            continue

        if len(pts) == 0:
            result[key] = []
            continue

        cart = np.array(pts, dtype=float)
        if cart.ndim != 2 or cart.shape[1] != 3:
            result[key] = pts
            continue

        frac = np.array(
            [lattice.get_fractional_coords(c) for c in cart],
            dtype=float,
        )

        for ax in periodic_axes:
            s = scale[ax]
            if s > 1:
                for i in range(frac.shape[0]):
                    frac[i, ax] = _wrap01(frac[i, ax] * s) / s

        frac = _dedup_frac(frac, tol=tol)

        unique_cart = np.array(
            [lattice.get_cartesian_coords(f) for f in frac],
            dtype=float,
        )
        result[key] = [row.tolist() for row in unique_cart]

    return result


def _expand_from_unit(
    points_cart: list[list[float]] | np.ndarray,
    *,
    lattice: "Lattice",
    na: int,
    nb: int,
    periodic_axes: tuple[int, ...] = (0, 1),
    tol: float = 1e-3,
) -> list[np.ndarray]:
    """Expand unit-cell site points to full supercell coordinates.

    Parameters
    ----------
    points_cart : array-like
        Cartesian coordinates of unique (unit-cell) sites,
        shape ``(N, 3)`` or list of 3-element lists.
    lattice : Lattice
        Lattice of the supercell slab.
    na, nb : int
        In-plane supercell scaling factors.
    periodic_axes : tuple[int, ...]
        Axes along which to replicate (0 → a, 1 → b).
    tol : float
        Deduplication tolerance in fractional space.

    Returns
    -------
    list[np.ndarray]
        Expanded Cartesian coordinates covering the full slab.
    """
    if not isinstance(points_cart, np.ndarray):
        points_cart = np.array(points_cart, dtype=float)
    if points_cart.ndim != 2 or points_cart.shape[0] == 0:
        return []

    base_frac = np.array(
        [lattice.get_fractional_coords(c) for c in points_cart],
        dtype=float,
    )

    a_range = range(max(int(na), 1)) if 0 in periodic_axes else [0]
    b_range = range(max(int(nb), 1)) if 1 in periodic_axes else [0]

    all_frac: list[np.ndarray] = []
    for ia in a_range:
        for ib in b_range:
            shifted = base_frac.copy()
            if 0 in periodic_axes and int(na) > 1:
                for i in range(shifted.shape[0]):
                    shifted[i, 0] = _wrap01(
                        shifted[i, 0] + ia / int(na),
                    )
            if 1 in periodic_axes and int(nb) > 1:
                for i in range(shifted.shape[0]):
                    shifted[i, 1] = _wrap01(
                        shifted[i, 1] + ib / int(nb),
                    )
            all_frac.append(shifted)

    combined = np.vstack(all_frac)
    combined = _dedup_frac(combined, tol=tol)

    return [np.array(lattice.get_cartesian_coords(f), dtype=float) for f in combined]


def _count_sites(
    surf_sites: dict[str, list[float]] | None,
) -> dict[str, int]:
    """Count adsorption sites grouped by raw ASF categories."""
    counts = {"ontop": 0, "bridge": 0, "hollow": 0}
    if not surf_sites:
        return counts

    for key in ("ontop", "bridge", "hollow"):
        values = surf_sites.get(key, [])
        if isinstance(values, (list, tuple, np.ndarray)):
            counts[key] = len(values)
    return counts


def _parse_bonds(
    bonds: dict[tuple[str, str], float] | None,
) -> dict[tuple[str, str], float] | None:
    """Normalize user bond map to SlabGenerator format.

    Accepted input form:
    - {('C', 'H'): 1.2}
    """
    if not bonds:
        return None

    parsed: dict[tuple[str, str], float] = {}
    for bond_key, threshold in bonds.items():
        if isinstance(bond_key, tuple):
            if len(bond_key) != 2:
                raise ValueError(f'invalid bond key "{bond_key}"; expected 2 species')
            pair = (str(bond_key[0]).strip(), str(bond_key[1]).strip())
            if not pair[0] or not pair[1]:
                raise ValueError("bond tuple species cannot be empty")
        else:
            raise ValueError('bond keys must be tuple pairs, e.g. ("C", "H")')

        parsed[pair] = float(threshold)

    return parsed


def _get_paired_counts(
    surface_sites: dict[str, Any] | None,
) -> dict[str, int] | None:
    if not isinstance(surface_sites, dict):
        return None
    value = surface_sites.get("__paired_ads_counts__")
    if isinstance(value, dict):
        return value
    return None


def _set_paired_counts(
    surface: "Surface",
    value: dict[str, int] | None,
) -> None:
    if not isinstance(value, dict):
        return
    if surface.surface_sites is None or not isinstance(surface.surface_sites, dict):
        surface.surface_sites = {}
    surface.surface_sites["__paired_ads_counts__"] = value


def _map_surface_sites(surface) -> dict:
    """Compute adsorption sites for *surface*, unique per unit cell.

    Sites are normalized using the in-plane scaling factors
    ``surface.scaling[0]`` (a) and ``surface.scaling[1]`` (b) so
    that only one copy per translational repeat is kept.
    Only the in-plane (a, b) Cartesian components are stored;
    the c-component is dropped because it is always equal to
    ``surface.thickness`` and can be recovered from that attribute.

    Parameters
    ----------
    surface : Surface
        Surface object whose ``.slab`` and ``.scaling`` are used.

    Returns
    -------
    dict[str, Any]
        Site map with ``ontop`` / ``bridge`` / ``hollow`` keys
        containing **2-element** ``[a, b]`` Cartesian coords
        unique per unit cell.
    """
    import slabfy.core as _core_mod

    asf = _core_mod.AdsorbateSiteFinder(surface.slab)
    raw_map = dict(asf.find_adsorption_sites())

    na = int(surface.scaling[0])
    nb = int(surface.scaling[1])
    norm_map = _normalize_to_unit(
        raw_map,
        lattice=surface.slab.lattice,
        na=na,
        nb=nb,
        periodic_axes=(0, 1),
    )

    for key in ("ontop", "bridge", "hollow"):
        pts = norm_map.get(key, [])
        norm_map[key] = [[p[0], p[1]] for p in pts]

    return norm_map


def _map_surface_directions(surface) -> list[tuple[int, int, int]]:
    """Map unique surface directions orthogonal to the surface normal.

    Uses symmetry-unique Miller indices from the bulk structure up to
    ``max_order=10`` and retains only those orthogonal to ``surface.miller``.

    Parameters
    ----------
    surface : Surface
        Surface object whose ``.bulk`` and ``.miller`` are used.

    Returns
    -------
    list[tuple[int, int, int]]
        Sorted list of canonical orthogonal Miller directions.
    """
    if surface.bulk is None:
        raise ValueError("Bulk structure is required to map directions")
    if surface.miller is None:
        raise ValueError("Miller index is required to map directions")

    try:
        miller_tuple = _normalize_miller(tuple(surface.miller))
    except Exception as exc:
        raise ValueError(f"invalid surface miller index: {exc}")

    def _canonical_direction(
        direction: tuple[int, int, int],
    ) -> tuple[int, int, int]:
        h, k, l = int(direction[0]), int(direction[1]), int(direction[2])
        divisor = gcd(abs(h), gcd(abs(k), abs(l)))
        if divisor:
            h //= divisor
            k //= divisor
            l //= divisor
        for value in (h, k, l):
            if value < 0:
                h, k, l = -h, -k, -l
                break
            if value > 0:
                break
        return (h, k, l)

    symmetry_operations = SpacegroupAnalyzer(
        surface.bulk.structure,
    ).get_symmetry_operations(cartesian=False)

    candidate_directions = unique_miller(surface.bulk.structure, max_order=10)
    orthogonal_set: set[tuple[int, int, int]] = set()
    for direction in candidate_directions:
        equivalents: set[tuple[int, int, int]] = {_canonical_direction(direction)}
        for operation in symmetry_operations:
            transformed = tuple(
                int(round(value))
                for value in operation.rotation_matrix.T.dot(direction)
            )
            if transformed == (0, 0, 0):
                continue
            equivalents.add(_canonical_direction(transformed))

        for equivalent in equivalents:
            dot = (
                equivalent[0] * miller_tuple[0]
                + equivalent[1] * miller_tuple[1]
                + equivalent[2] * miller_tuple[2]
            )
            if dot == 0:
                orthogonal_set.add(equivalent)

    return sorted(
        orthogonal_set,
        key=lambda index: (
            index[0] ** 2 + index[1] ** 2 + index[2] ** 2,
            index[0],
            index[1],
            index[2],
        ),
    )


# ── §6  Surface pipeline ──────────────────────────────────────────────


def _resolve_bulk(
    bulk_input: Union[Structure, "Bulk", str],
) -> Structure:
    from slabfy.core import Bulk

    if isinstance(bulk_input, Bulk):
        return bulk_input.structure
    if isinstance(bulk_input, Structure):
        return bulk_input
    if not isinstance(bulk_input, str):
        raise ValueError("bulk input must be Structure, Bulk, or POSCAR path")
    if not os.path.exists(bulk_input):
        raise ValueError(f"bulk path does not exist: {bulk_input}")
    return Poscar.from_file(bulk_input).structure


def _process_slab(
    n: int,
    slab: Slab,
    miller: tuple,
    symmetry: bool,
    layers_ref: int,
    bulk_structure: Structure,
    structure_ref: Structure,
    bulk_energy: float | None = None,
    settings: dict[str, Any] | None = None,
) -> list["Surface"]:
    """Create one or two Surface objects from a slab.

    For symmetric slabs this returns one Surface. For asymmetric slabs this
    returns two Surfaces: the original (UP) and the inverse (DN).
    """
    from slabfy.core import Surface

    if settings is None:
        settings = {}
    verbose = bool(settings.get("verbose", 1))

    surfaces: list[Surface] = []

    # shift primary slab to z=0 reference early
    slab_shifted = _shift_to_zero(slab)
    if not isinstance(slab_shifted, Slab):
        raise ValueError("Expected Slab after supercell expansion")
    slab = slab_shifted

    # geometric parameters
    thickness, vacuum = _slab_geometry(slab)

    elements = _axis_layers(slab, axis="c")
    layers = len(elements)
    stoichiometric = _is_stoich(structure_ref, slab)
    surface_payload = _struct_snapshot(slab)
    surface_payload.add_site_property(
        "mask",
        ["surface"] * len(surface_payload),
    )

    up_surface = Surface(
        surface_payload,
        bulk=bulk_structure,
        bulk_energy=bulk_energy,
        miller=miller,
        thickness=thickness,
        vacuum=vacuum,
        symmetric=slab.is_symmetric(),
        slab_termination="SY" if slab.is_symmetric() else "UP",
        surface_sites=None,
        surface_directions=None,
        adparticle=None,
        slab_index=n + 1,
        surface_axis_layers=elements,
        scaling=(
            1,
            1,
            int(max(1, round((layers / layers_ref) if layers_ref else 1.0))),
        ),
        stoichiometric=stoichiometric,
        surface_dipole=_dipole_along_axis(
            slab,
            np.array(slab.lattice.matrix[2], dtype=float),
        ),
        surface_area=slab.surface_area,
    )
    up_surface.surface_sites = _map_surface_sites(up_surface)
    surfaces.append(up_surface)

    if slab.is_symmetric():
        return surfaces

    # Build inverse (downward termination) only for asymmetric slabs.
    # Inversion is applied directly to the UP slab coordinates preserving lattice.
    inverse_slab = _invert_c(slab)
    inverse_payload = _struct_snapshot(inverse_slab)
    inverse_payload.add_site_property(
        "mask",
        ["surface"] * len(inverse_payload),
    )

    dn_surface = Surface(
        inverse_payload,
        bulk=bulk_structure,
        bulk_energy=bulk_energy,
        miller=miller,
        thickness=thickness,
        vacuum=vacuum,
        symmetric=False,
        slab_termination="DN",
        surface_sites=None,
        surface_directions=None,
        adparticle=None,
        slab_index=n + 1,
        surface_axis_layers=elements,
        scaling=up_surface.scaling,
        stoichiometric=stoichiometric,
        surface_dipole=_dipole_along_axis(
            inverse_slab,
            np.array(inverse_slab.lattice.matrix[2], dtype=float),
        ),
        surface_area=slab.surface_area,
    )
    dn_surface.surface_sites = _map_surface_sites(dn_surface)
    surfaces.append(dn_surface)

    return surfaces


# ── §7  Epitaxial pipeline ────────────────────────────────────────────


def _resolve_miller_targets(
    structure_obj: Structure,
    miller_value: Union[tuple, int],
    min_slab_thickness: float,
) -> list[tuple[int, int, int]]:
    if isinstance(miller_value, int):
        max_order = int(miller_value)
        candidates = unique_miller(structure_obj, max_order=max_order)
        viable: list[tuple[int, int, int]] = []
        for miller_candidate in candidates:
            try:
                slab_generator = SlabGenerator(
                    structure_obj,
                    miller_candidate,
                    min_slab_size=max(float(min_slab_thickness), 1.0),
                    min_vacuum_size=1.0,
                    center_slab=True,
                )
                slabs = slab_generator.get_slabs(ftol=1e-12, symmetrize=False)
            except Exception:
                continue
            if slabs:
                viable.append(_normalize_miller(tuple(miller_candidate)))

        return viable

    if not isinstance(miller_value, tuple):
        raise ValueError("miller must be tuple or integer max order")
    return [_normalize_miller(miller_value)]


def _build_ref_surface(
    bulk_structure: Structure,
    miller: tuple[int, int, int],
    min_slab_thickness: float,
    vacuum: float,
) -> "Surface | None":
    from slabfy.core import Surface

    try:
        slab_generator = SlabGenerator(
            bulk_structure,
            tuple(miller),
            min_slab_size=float(min_slab_thickness),
            min_vacuum_size=max(float(vacuum), 1.0),
            center_slab=True,
        )
        slabs = slab_generator.get_slabs(ftol=1e-12, symmetrize=False)
    except Exception:
        return None

    if not slabs:
        return None

    try:
        slab_obj = slabs[0].get_orthogonal_c_slab()
    except Exception:
        slab_obj = slabs[0]

    try:
        slab_obj = _set_vacuum(slab_obj, float(vacuum))
    except Exception:
        pass

    slab_thickness, slab_vacuum = _slab_geometry(slab_obj)
    surface_obj = Surface(
        _struct_snapshot(slab_obj),
        bulk=bulk_structure,
        miller=tuple(miller),
        thickness=float(slab_thickness),
        vacuum=float(slab_vacuum),
        symmetric=bool(slab_obj.is_symmetric()),
        slab_termination="SY" if slab_obj.is_symmetric() else "UP",
        slab_index=1,
    )
    try:
        surface_obj.surface_sites = _map_surface_sites(surface_obj)
    except Exception:
        surface_obj.surface_sites = {}
    return surface_obj


def _build_component_surface(
    component_structure: Structure | None,
    reference_surface: "Surface | None",
    *,
    bulk_structure: Structure,
    miller: tuple[int, int, int],
    slab_index: int,
    slab_termination: str,
) -> "Surface":
    from slabfy.core import Surface

    slab_source = component_structure
    if slab_source is None and reference_surface is not None:
        slab_source = reference_surface.slab
    if slab_source is None:
        slab_source = bulk_structure.copy()

    slab_source = _shift_to_zero(slab_source)
    slab_snapshot = _struct_snapshot(slab_source)

    thickness: float | None = None
    vacuum: float | None = None
    symmetric: bool | None = None
    stoichiometric: bool | None = None
    bulk_energy: float | None = None
    surface_area: float | None = None
    surface_axis_layers: Any = None
    surface_dipole: float | None = None
    properties_metadata: dict = {}
    surface_sites: dict[str, Any] | None = None
    surface_directions: Any = None
    scaling = (1, 1, 1)

    if reference_surface is not None:
        thickness = (
            float(reference_surface.thickness)
            if reference_surface.thickness is not None
            else None
        )
        vacuum = (
            float(reference_surface.vacuum)
            if reference_surface.vacuum is not None
            else None
        )
        symmetric = reference_surface.symmetric
        stoichiometric = reference_surface.stoichiometric
        bulk_energy = (
            reference_surface.bulk.energy
            if reference_surface.bulk is not None
            else None
        )
        surface_area = reference_surface.surface_area
        surface_axis_layers = reference_surface.surface_axis_layers
        surface_dipole = reference_surface.surface_dipole
        properties_metadata = reference_surface.properties_metadata
        if isinstance(reference_surface.surface_sites, dict):
            surface_sites = {
                key: list(value) if isinstance(value, list) else value
                for key, value in reference_surface.surface_sites.items()
            }
        surface_directions = reference_surface.surface_directions
        scaling = _normalize_scaling(getattr(reference_surface, "scaling", (1, 1, 1)))

    if thickness is None or vacuum is None:
        try:
            slab_thickness, slab_vacuum = _slab_geometry(slab_snapshot)
            thickness = slab_thickness
            vacuum = slab_vacuum
        except Exception:
            pass

    if stoichiometric is None:
        try:
            stoichiometric = _is_stoich(bulk_structure, slab_snapshot)
        except Exception:
            pass

    return Surface(
        slab_snapshot,
        slab_index=int(slab_index),
        slab_termination=slab_termination,
        symmetric=symmetric,
        stoichiometric=stoichiometric,
        bulk=bulk_structure,
        bulk_energy=bulk_energy,
        miller=tuple(miller),
        thickness=thickness,
        vacuum=vacuum,
        surface_area=surface_area,
        surface_axis_layers=surface_axis_layers,
        surface_dipole=surface_dipole,
        properties_metadata=properties_metadata,
        surface_sites=surface_sites,
        surface_directions=surface_directions,
        scaling=scaling,
    )


def _derive_strain(
    interface_structure: Structure,
    substrate_surface: "Surface",
    film_surface: "Surface",
) -> tuple[float | None, dict[str, Any]]:
    """Derive scalar and component in-plane strain metrics for an interface."""
    interface_a = np.array(interface_structure.lattice.matrix[0], dtype=float)
    interface_b = np.array(interface_structure.lattice.matrix[1], dtype=float)

    substrate_metrics = _strain_metrics(
        np.array(substrate_surface.slab.lattice.matrix[0], dtype=float),
        np.array(substrate_surface.slab.lattice.matrix[1], dtype=float),
        interface_a,
        interface_b,
    )
    film_metrics = _strain_metrics(
        np.array(film_surface.slab.lattice.matrix[0], dtype=float),
        np.array(film_surface.slab.lattice.matrix[1], dtype=float),
        interface_a,
        interface_b,
    )

    scalar_strain: float | None = None
    if film_metrics is not None:
        scalar_strain = float(film_metrics["strain_rms"])
    elif substrate_metrics is not None:
        scalar_strain = float(substrate_metrics["strain_rms"])

    metadata: dict[str, Any] = {}
    if substrate_metrics is not None:
        metadata["substrate_strain"] = substrate_metrics
    if film_metrics is not None:
        metadata["film_strain"] = film_metrics

    return scalar_strain, metadata


def _strain_metrics(
    reference_a: np.ndarray,
    reference_b: np.ndarray,
    target_a: np.ndarray,
    target_b: np.ndarray,
) -> dict[str, float] | None:
    """Compute in-plane deformation metrics between two 2D lattice bases."""
    ref_a = np.array(reference_a, dtype=float)
    ref_b = np.array(reference_b, dtype=float)
    tgt_a = np.array(target_a, dtype=float)
    tgt_b = np.array(target_b, dtype=float)

    if np.linalg.norm(tgt_a) <= 1e-12 or np.linalg.norm(tgt_b) <= 1e-12:
        return None

    normal = np.cross(tgt_a, tgt_b)
    normal_norm = float(np.linalg.norm(normal))
    if normal_norm <= 1e-12:
        return None

    basis_u = tgt_a / np.linalg.norm(tgt_a)
    basis_n = normal / normal_norm
    basis_v = np.cross(basis_n, basis_u)

    def _project_2d(vector: np.ndarray) -> np.ndarray:
        return np.array(
            [
                float(np.dot(vector, basis_u)),
                float(np.dot(vector, basis_v)),
            ],
            dtype=float,
        )

    reference_matrix = np.column_stack([_project_2d(ref_a), _project_2d(ref_b)])
    target_matrix = np.column_stack([_project_2d(tgt_a), _project_2d(tgt_b)])

    det_ref = float(np.linalg.det(reference_matrix))
    if abs(det_ref) <= 1e-12:
        return None

    deformation = target_matrix @ np.linalg.inv(reference_matrix)
    right_cauchy_green = deformation.T @ deformation
    eigenvalues = np.linalg.eigvalsh(right_cauchy_green)
    if np.any(eigenvalues <= 0):
        return None

    principal_stretches = np.sqrt(eigenvalues)
    principal_strains = principal_stretches - 1.0
    strain_rms = float(np.sqrt(np.mean(principal_strains**2)))
    strain_max = float(np.max(np.abs(principal_strains)))

    area_ref = abs(det_ref)
    area_tgt = abs(float(np.linalg.det(target_matrix)))
    area_strain = (area_tgt / area_ref) - 1.0

    angle_ref = float(
        np.degrees(
            np.arccos(
                np.clip(
                    np.dot(ref_a, ref_b)
                    / (np.linalg.norm(ref_a) * np.linalg.norm(ref_b)),
                    -1.0,
                    1.0,
                )
            )
        )
    )
    angle_tgt = float(
        np.degrees(
            np.arccos(
                np.clip(
                    np.dot(tgt_a, tgt_b)
                    / (np.linalg.norm(tgt_a) * np.linalg.norm(tgt_b)),
                    -1.0,
                    1.0,
                )
            )
        )
    )

    return {
        "strain_rms": strain_rms,
        "strain_max": strain_max,
        "strain_principal_min": float(np.min(principal_strains)),
        "strain_principal_max": float(np.max(principal_strains)),
        "area_strain": float(area_strain),
        "angle_delta_deg": float(angle_tgt - angle_ref),
    }


def _pick_if_contacts(
    interface_layers: dict[float, list[str]] | list[tuple[float, list[str]]] | None,
    interface_axis_position: float | None,
) -> tuple[tuple[float, list[str]] | None, tuple[float, list[str]] | None]:
    if isinstance(interface_layers, dict):
        layers = sorted(interface_layers.items(), key=lambda item: float(item[0]))
    elif isinstance(interface_layers, list):
        layers = sorted(interface_layers, key=lambda item: float(item[0]))
    else:
        layers = []

    if not layers:
        return None, None

    if interface_axis_position is None:
        return layers[-1], layers[0]

    axis_position = float(interface_axis_position)
    upper_layers = [layer for layer in layers if float(layer[0]) >= axis_position]
    lower_layers = [layer for layer in layers if float(layer[0]) <= axis_position]

    surface1_layer = (
        min(upper_layers, key=lambda layer: float(layer[0]) - axis_position)
        if upper_layers
        else layers[-1]
    )
    surface2_layer = (
        max(lower_layers, key=lambda layer: float(layer[0]))
        if lower_layers
        else layers[0]
    )
    return surface1_layer, surface2_layer


def _region_mask(
    structure: Structure,
    axis_vector: np.ndarray,
    interface_position: float,
    interface_depth: float,
) -> tuple[np.ndarray, np.ndarray, float]:
    if interface_depth <= 0:
        return np.zeros(len(structure), dtype=bool), np.array([], dtype=float), 0.0

    axis = np.array(axis_vector, dtype=float)
    axis_length = float(np.linalg.norm(axis))
    volume = float(abs(np.linalg.det(structure.lattice.matrix)))
    if axis_length <= 1e-12 or volume <= 1e-12:
        return np.zeros(len(structure), dtype=bool), np.array([], dtype=float), 0.0

    axis_hat = _unit_vec(axis)
    projections = np.dot(structure.cart_coords.astype(float), axis_hat)
    mask = (projections >= interface_position - float(interface_depth)) & (
        projections <= interface_position + float(interface_depth)
    )

    area_perp = volume / axis_length
    if area_perp <= 1e-12:
        return np.zeros(len(structure), dtype=bool), np.array([], dtype=float), 0.0

    return mask, projections[mask], area_perp


def _density_near_axis(
    structure: Structure,
    axis_vector: np.ndarray,
    interface_position: float,
    interface_depth: float,
) -> float:
    mask, _projections_window, area_perp = _region_mask(
        structure,
        axis_vector,
        interface_position,
        interface_depth,
    )
    if area_perp <= 1e-12 or not np.any(mask):
        return 0.0

    coords_window = structure.cart_coords.astype(float)[mask]
    species_window = [site.specie for idx, site in enumerate(structure) if mask[idx]]

    thickness = 2.0 * float(interface_depth)
    volume_window = area_perp * thickness
    if volume_window <= 1e-12:
        return 0.0

    window_structure = Structure(
        Lattice.cubic(100.0),
        species_window,
        coords_window,
        coords_are_cartesian=True,
    )
    mass_amu = float(window_structure.composition.weight)
    amu_to_g = 1.66053906660e-24
    angstrom3_to_cm3 = 1e-24
    return (mass_amu * amu_to_g) / (volume_window * angstrom3_to_cm3)


def _compute_if_sites(
    interface: "Interface",
    *,
    tol: float = 0.35,
) -> dict[str, list[list[float]]]:
    """Compute interface-unique adsorption sites on the top surface.

    For lateral interfaces the junction runs along **b**; adsorption
    sites live on the common **top surface** (high c).  Reference
    site sets are built from mask-based sub-structures extracted
    from ``interface.slab`` so that all coordinates share the same
    Cartesian frame.  Sites already present on either surface
    individually are excluded, yielding genuinely new
    interface-unique sites.

    For epitaxial interfaces the interface is buried — no top-surface
    interface-unique sites exist — so an empty map is returned.

    Parameters
    ----------
    interface : Interface
        Interface object with ``.slab``, ``.surface1``, ``.surface2``.
    tol : float
        Cartesian distance below which two sites are considered
        the same (used for exclusion).

    Returns
    -------
    dict[str, list[list[float]]]
        ``{'ontop': [...], 'bridge': [...], 'hollow': [...]}``
    """
    empty: dict[str, list[list[float]]] = {
        "ontop": [],
        "bridge": [],
        "hollow": [],
    }
    if interface.slab is None:
        return empty

    if str(interface.mode or "").lower() == "epitaxial":
        return {k: list(v) for k, v in empty.items()}

    # --- Full-slab ASF -------------------------------------------
    import slabfy.core as _core_mod

    AdsorbateSiteFinder = _core_mod.AdsorbateSiteFinder
    try:
        raw_all = dict(
            AdsorbateSiteFinder(
                interface.slab,
            ).find_adsorption_sites()
        )
    except Exception:
        return {k: list(v) for k, v in empty.items()}

    all_sites = _normalize_site_map(raw_all)

    # --- Mask-based reference site sets --------------------------
    mask_vals = interface.slab.site_properties.get("mask", [])
    s1_idx = [i for i, m in enumerate(mask_vals) if m == "surface1"]
    s2_idx = [i for i, m in enumerate(mask_vals) if m == "surface2"]

    s1_ref = _normalize_site_map(None)
    s2_ref = _normalize_site_map(None)

    if s1_idx:
        try:
            s1_sub = Structure.from_sites(
                [interface.slab[i] for i in s1_idx],
            )
            s1_ref = _normalize_site_map(
                dict(AdsorbateSiteFinder(s1_sub).find_adsorption_sites())
            )
        except Exception:
            pass

    if s2_idx:
        try:
            s2_sub = Structure.from_sites(
                [interface.slab[i] for i in s2_idx],
            )
            s2_ref = _normalize_site_map(
                dict(AdsorbateSiteFinder(s2_sub).find_adsorption_sites())
            )
        except Exception:
            pass

    # --- Spatial window near interface axis ----------------------
    axis_key = str(
        getattr(interface, "interface_axis", "c"),
    ).lower()
    axis_index = {"a": 0, "b": 1, "c": 2}.get(axis_key, 2)
    axis_vector = np.array(
        interface.slab.lattice.matrix[axis_index],
        dtype=float,
    )
    axis_hat = _unit_vec(axis_vector)
    ipos = float(
        getattr(interface, "interface_axis_position", 0.0) or 0.0,
    )
    interface_depth = 2.0

    def _in_window(point: np.ndarray) -> bool:
        proj = float(
            np.dot(np.array(point, dtype=float), axis_hat),
        )
        return abs(proj - ipos) <= interface_depth

    # --- Exclude surface sites, apply window, normalize ----------
    filtered: dict[str, list[list[float]]] = {
        "ontop": [],
        "bridge": [],
        "hollow": [],
    }
    for key in ("ontop", "bridge", "hollow"):
        forbidden = [*s1_ref[key], *s2_ref[key]]
        kept = _exclude_by_dist(
            all_sites[key],
            forbidden,
            tol=tol,
        )
        kept = [pt for pt in kept if _in_window(pt)]
        filtered[key] = [pt.tolist() for pt in kept]

    # Normalize to unique per unit interface repeat (a-axis only)
    na_int = 1
    if interface.surface1 is not None and interface.surface2 is not None:
        na_int = min(
            int(getattr(interface.surface1, "scaling", (1,))[0]),
            int(getattr(interface.surface2, "scaling", (1,))[0]),
        )
    if na_int > 1:
        filtered = _normalize_to_unit(
            filtered,
            lattice=interface.slab.lattice,
            na=na_int,
            nb=1,
            periodic_axes=(0,),
        )

    # Keep only in-plane (a, b) components
    for key in ("ontop", "bridge", "hollow"):
        pts = filtered.get(key, [])
        filtered[key] = [[p[0], p[1]] for p in pts]

    return filtered


def _resolve_if_miller(
    interface: "Interface",
    surface_index: Literal[1, 2],
) -> tuple[int, int, int] | None:
    fallback_surface = interface.surface1 if surface_index == 1 else interface.surface2
    fallback = getattr(fallback_surface, "miller", None)
    if fallback is not None:
        try:
            return _normalize_miller(tuple(fallback))
        except Exception:
            pass

    explicit = interface.miller1 if surface_index == 1 else interface.miller2
    if explicit is None:
        return None
    try:
        return _normalize_miller(tuple(explicit))
    except Exception:
        return None


def _dedup_epitaxial_candidates(
    candidates: list[dict],
    matcher: StructureMatcher,
) -> list[dict]:
    """Deduplicate ZSL-match duplicates within each (hkl1, hkl2, termination) bucket.

    Deliberately does NOT merge across different terminations; those are
    physically distinct contact surfaces and must be preserved as separate
    Interface outputs.
    """
    buckets: dict[tuple, list[dict]] = {}
    for entry in candidates:
        # Use str() to handle both plain-label and indexed-handle terminations.
        key = (
            tuple(entry["bulk1_hkl"]),
            tuple(entry["bulk2_hkl"]),
            str(entry["termination"]),
        )
        buckets.setdefault(key, []).append(entry)

    unique: list[dict] = []
    for bucket in buckets.values():
        structs = [e["structure"] for e in bucket]
        groups = matcher.group_structures(structs)
        id_to_idx = {id(s): i for i, s in enumerate(structs)}
        for group in groups:
            unique.append(bucket[id_to_idx[id(group[0])]])
    return unique


def _process_epitaxial(
    bulk1: Union[Structure, str],
    bulk2: Union[Structure, str],
    miller1: Union[tuple, int],
    miller2: Union[tuple, int],
    bulk1_thickness: float,
    bulk2_thickness: float,
    gap: float,
    vacuum: float,
    settings: dict[str, Any],
    **kwargs: Any,
) -> list["Interface"]:
    """Build epitaxial interfaces using screening workflow."""
    from slabfy.core import Surface, Interface

    verbose = bool(settings.get("verbose", 1))
    _vprint = _make_vprint("join", verbose)

    bulk1_structure = _resolve_bulk(bulk1)
    bulk2_structure = _resolve_bulk(bulk2)

    bulk1_hkls = _resolve_miller_targets(bulk1_structure, miller1, bulk1_thickness)
    bulk2_hkls = _resolve_miller_targets(bulk2_structure, miller2, bulk2_thickness)

    # Contact-termination screening toggle.
    # When False (default): one representative termination per (hkl1, hkl2) pair.
    # When True: all terminations discovered by the patched builder are used.
    enable_contact_shifts = bool(kwargs.get("enable_contact_shifts", False))
    termination_ftol = float(kwargs.get("termination_ftol", 0.25))
    label_index = bool(kwargs.get("label_index", True))
    filter_out_sym_slabs = bool(kwargs.get("filter_out_sym_slabs", False))

    zsl_max_interface_area = float(kwargs.get("zsl_max_interface_area", 400.0))
    zsl_max_length_tol = float(kwargs.get("zsl_max_length_tol", 0.06))
    zsl_max_angle_tol = float(kwargs.get("zsl_max_angle_tol", 0.06))
    zsl_generator = ZSLGenerator(
        max_area=zsl_max_interface_area,
        max_length_tol=zsl_max_length_tol,
        max_angle_tol=zsl_max_angle_tol,
    )

    # Build reference Surface objects for each HKL so we can attach them
    # to the final Interface objects as surface1 / surface2 metadata.
    bulk1_surface_map: dict[tuple[int, int, int], "Surface | None"] = {
        hkl: _build_ref_surface(bulk1_structure, hkl, bulk1_thickness, vacuum)
        for hkl in bulk1_hkls
    }
    bulk2_surface_map: dict[tuple[int, int, int], "Surface | None"] = {
        hkl: _build_ref_surface(bulk2_structure, hkl, bulk2_thickness, vacuum)
        for hkl in bulk2_hkls
    }

    _vprint("starting epitaxial interface search")
    _vprint(
        f"bulk1 hkls={len(bulk1_hkls)} bulk2 hkls={len(bulk2_hkls)} "
        f"max_area={zsl_max_interface_area}"
    )

    candidates: list[dict[str, Any]] = []
    for bulk1_hkl in bulk1_hkls:
        for bulk2_hkl in bulk2_hkls:
            try:
                builder = _PatchedCoherentInterfaceBuilder(
                    substrate_structure=bulk1_structure,
                    film_structure=bulk2_structure,
                    substrate_miller=bulk1_hkl,
                    film_miller=bulk2_hkl,
                    zslgen=zsl_generator,
                    termination_ftol=termination_ftol,
                    label_index=label_index,
                    filter_out_sym_slabs=filter_out_sym_slabs,
                )
            except Exception as exc:
                _vprint(
                    f"failed builder for bulk1={bulk1_hkl} bulk2={bulk2_hkl}: {exc}"
                )
                continue

            terminations = list(getattr(builder, "terminations", []) or [])
            if not terminations:
                continue

            # When enable_contact_shifts is False, use only the first
            # termination per (hkl1, hkl2) pair — mirroring the
            # enable_contact_shifts=False behavior in _process_lateral.
            if not enable_contact_shifts:
                terminations = terminations[:1]

            for termination in terminations:
                try:
                    interfaces = builder.get_interfaces(
                        termination=termination,
                        gap=float(gap),
                        vacuum_over_film=float(vacuum),
                        film_thickness=float(bulk2_thickness),
                        substrate_thickness=float(bulk1_thickness),
                        in_layers=False,
                    )
                except Exception as exc:
                    _vprint(
                        f"skipping termination {termination} "
                        f"for pair ({bulk1_hkl}, {bulk2_hkl}): {exc}"
                    )
                    continue

                for interface_structure in interfaces:
                    area = _area_ab(interface_structure)
                    if area > zsl_max_interface_area:
                        continue
                    interface_properties = dict(
                        getattr(interface_structure, "interface_properties", {}) or {}
                    )
                    candidates.append(
                        {
                            "structure": interface_structure,
                            "bulk1_hkl": bulk1_hkl,
                            "bulk2_hkl": bulk2_hkl,
                            "termination": termination,
                            "area": float(area),
                            "interface_properties": interface_properties,
                        }
                    )

    if not candidates:
        _vprint("no epitaxial interfaces found within constraints")
        return []

    matcher = StructureMatcher(
        primitive_cell=False,
        scale=False,
        ltol=0.2,
        stol=0.3,
        angle_tol=5,
    )
    unique_candidates = _dedup_epitaxial_candidates(candidates, matcher)

    unique_candidates.sort(key=lambda entry: entry["area"])

    interfaces_out: list[Interface] = []
    for idx, entry in enumerate(unique_candidates, start=1):
        bulk1_surface = bulk1_surface_map.get(entry["bulk1_hkl"])
        bulk2_surface = bulk2_surface_map.get(entry["bulk2_hkl"])
        if bulk1_surface is None or bulk2_surface is None:
            continue

        structure_base = _shift_to_zero(entry["structure"])
        if not isinstance(structure_base, Structure):
            continue

        strain_scalar, strain_metadata = _derive_strain(
            structure_base,
            bulk1_surface,
            bulk2_surface,
        )

        interface_properties = dict(entry.get("interface_properties", {}) or {})
        zsl_von_mises = interface_properties.get("von_mises_strain", None)
        if strain_scalar is None and zsl_von_mises is not None:
            try:
                strain_scalar = float(zsl_von_mises)
            except Exception:
                pass

        variants = [
            ("UP", structure_base),
            ("DN", _invert_c(structure_base)),
        ]

        substrate_component = getattr(entry["structure"], "substrate", None)
        if not isinstance(substrate_component, Structure):
            substrate_component = None
        film_component = getattr(entry["structure"], "film", None)
        if not isinstance(film_component, Structure):
            film_component = None

        n_substrate = len(substrate_component) if substrate_component else 0
        n_film = len(film_component) if film_component else 0
        if n_substrate + n_film == len(structure_base):
            # Use pymatgen's interface_label (preserved through
            # sort()) to assign the mask correctly.  The naive
            # positional split (['surface1']*N + ['surface2']*M)
            # is wrong because Interface.from_slabs() sorts sites
            # by species, interleaving substrate and film atoms.
            interface_labels = structure_base.site_properties.get(
                "interface_label",
                [],
            )
            if len(interface_labels) != len(structure_base):
                raise ValueError(
                    "pymatgen interface structure is missing "
                    "interface_label site property; cannot "
                    "assign substrate/film mask"
                )
            mask = [
                "surface1" if "substrate" in str(label) else "surface2"
                for label in interface_labels
            ]
            structure_base.add_site_property("mask", mask)
            variants = [
                ("UP", structure_base),
                ("DN", _invert_c(structure_base)),
            ]

        for slab_termination, structure_obj in variants:
            surface1_component = substrate_component
            if slab_termination == "DN" and surface1_component is not None:
                surface1_component = _invert_c(surface1_component)

            surface2_component = film_component
            if slab_termination == "DN" and surface2_component is not None:
                surface2_component = _invert_c(surface2_component)

            surface1_variant = _build_component_surface(
                surface1_component,
                bulk1_surface,
                bulk_structure=bulk1_structure,
                miller=tuple(entry["bulk1_hkl"]),
                slab_index=idx,
                slab_termination=slab_termination,
            )
            surface2_variant = _build_component_surface(
                surface2_component,
                bulk2_surface,
                bulk_structure=bulk2_structure,
                miller=tuple(entry["bulk2_hkl"]),
                slab_index=idx,
                slab_termination=slab_termination,
            )

            axis_vector = np.array(structure_obj.lattice.matrix[2], dtype=float)
            axis_hat = _unit_vec(axis_vector)
            projections = np.dot(structure_obj.cart_coords.astype(float), axis_hat)
            mask_vals = structure_obj.site_properties.get("mask", [])
            if mask_vals:
                sub_proj = projections[
                    [i for i, m in enumerate(mask_vals) if m == "surface1"]
                ]
                film_proj = projections[
                    [i for i, m in enumerate(mask_vals) if m == "surface2"]
                ]
                if len(sub_proj) > 0 and len(film_proj) > 0:
                    interface_position = float(
                        (np.max(sub_proj) + np.min(film_proj)) / 2.0
                    )
                else:
                    interface_position = float(np.mean(projections))
            else:
                interface_position = float(np.mean(projections))
            interface_depth = 2.0
            thickness_surface1 = float(surface1_variant.thickness or 0.0)
            thickness_surface2 = float(surface2_variant.thickness or 0.0)
            interface_thickness = thickness_surface1 + thickness_surface2 + float(gap)
            interface_area = _area_ab(structure_obj)
            interface_dipole = _dipole_along_axis(
                structure_obj,
                axis_vector,
                center_position=interface_position,
                window_depth=interface_depth,
            )
            interface_density = _density_near_axis(
                structure_obj,
                axis_vector,
                interface_position,
                interface_depth,
            )
            interface_axis_layers = _axis_layers(structure_obj, axis="c")

            interface_metadata = {
                "zsl": interface_properties,
            }

            interfaces_out.append(
                Interface(
                    structure_obj,
                    surface1=surface1_variant,
                    surface2=surface2_variant,
                    miller1=tuple(entry["bulk1_hkl"]),
                    miller2=tuple(entry["bulk2_hkl"]),
                    slab_index=idx,
                    slab_termination=slab_termination,
                    mode="epitaxial",
                    stoichiometric=bool(
                        surface1_variant.stoichiometric
                        and surface2_variant.stoichiometric
                    ),
                    symmetric=bool(
                        surface1_variant.symmetric and surface2_variant.symmetric
                    ),
                    interface_axis="c",
                    interface_axis_layers=interface_axis_layers,
                    interface_axis_position=float(interface_position),
                    gap=float(gap),
                    scaling=(1, 1, 1),
                    interface_strain=strain_scalar,
                    interface_area=float(interface_area),
                    interface_dipole=float(interface_dipole),
                    interface_density=float(interface_density),
                    thickness=float(interface_thickness),
                    vacuum=float(vacuum),
                    interface_sites={
                        "ontop": [],
                        "bridge": [],
                        "hollow": [],
                    },
                    interface_metadata=interface_metadata,
                )
            )

    return interfaces_out


# ── §8  Lateral pipeline ──────────────────────────────────────────────


def _canonical_pq(p: int, q: int) -> tuple[int, int]:
    p = int(p)
    q = int(q)
    if p == 0 and q == 0:
        return (0, 0)
    divisor = int(np.gcd(abs(p), abs(q)))
    if divisor:
        p //= divisor
        q //= divisor
    if p < 0 or (p == 0 and q < 0):
        p = -p
        q = -q
    return (p, q)


def _enumerate_dirs(
    slab: Structure,
    *,
    max_pq: int,
    max_dirs_keep: int,
    max_len_join: float | None,
    max_pq_l1: int | None,
) -> list[dict[str, Any]]:
    a_vec = np.array(slab.lattice.matrix[0], dtype=float)
    b_vec = np.array(slab.lattice.matrix[1], dtype=float)

    seen: set[tuple[int, int]] = set()
    out: list[dict[str, Any]] = []
    for p in range(-max_pq, max_pq + 1):
        for q in range(-max_pq, max_pq + 1):
            if p == 0 and q == 0:
                continue
            p0, q0 = _canonical_pq(p, q)
            if (p0, q0) in seen:
                continue
            if int(np.gcd(abs(p0), abs(q0))) != 1:
                continue

            if max_pq_l1 is not None and (abs(p0) + abs(q0)) > int(max_pq_l1):
                continue

            join_vec = (p0 * a_vec) + (q0 * b_vec)
            join_len = float(np.linalg.norm(join_vec))
            if join_len <= 1e-10:
                continue
            if max_len_join is not None and join_len > float(max_len_join):
                continue

            seen.add((p0, q0))
            out.append(
                {
                    "pq": (p0, q0),
                    "length": join_len,
                }
            )

    out.sort(key=lambda item: (item["length"], abs(item["pq"][0]) + abs(item["pq"][1])))

    # Collapse symmetry-equivalent directions: directions whose
    # join-vector lengths coincide originate from the same
    # point-group orbit of the slab lattice.  Keep the lowest
    # |p|+|q| representative per length group.
    deduped: list[dict[str, Any]] = []
    for item in out:
        if deduped and abs(item["length"] - deduped[-1]["length"]) < 1e-6:
            continue
        deduped.append(item)

    return deduped[: max(int(max_dirs_keep), 1)]


def _complete_from_pq(
    p: int,
    q: int,
) -> tuple[int, int]:
    p = int(p)
    q = int(q)
    if p == 0 and q == 0:
        raise ValueError("p and q cannot both be zero")
    if int(np.gcd(abs(p), abs(q))) != 1:
        raise ValueError("p and q must be coprime")

    def _egcd(a: int, b: int) -> tuple[int, int, int]:
        if b == 0:
            return (1, 0, a)
        x1, y1, g = _egcd(b, a % b)
        return (y1, x1 - (a // b) * y1, g)

    x0, y0, g = _egcd(abs(q), abs(p))
    if g != 1:
        raise ValueError("failed to complete unimodular basis")

    sign_q = 1 if q >= 0 else -1
    sign_p = 1 if p >= 0 else -1
    r = int(x0 * sign_q)
    s = int(-y0 * sign_p)
    if (r * q) - (s * p) != 1:
        r = -r
        s = -s
    if (r * q) - (s * p) != 1:
        raise ValueError("could not enforce det=1 completion")
    return (r, s)


def _reindex_slab(
    slab: Structure,
    p: int,
    q: int,
    *,
    max_coef: int,
    max_det: int,
    ortho_tol: float,
    max_a_len: float | None,
) -> tuple[Structure, dict[str, Any]]:
    a_vec = np.array(slab.lattice.matrix[0], dtype=float)
    b_vec = np.array(slab.lattice.matrix[1], dtype=float)
    c_vec = np.array(slab.lattice.matrix[2], dtype=float)

    g11 = float(np.dot(a_vec, a_vec))
    g12 = float(np.dot(a_vec, b_vec))
    g22 = float(np.dot(b_vec, b_vec))
    metric_scale = float(np.sqrt(max(g11 * g22, 1e-30)))

    best_score: tuple[float, int, int] | None = None
    best_tuple: tuple[int, int, int, float, float, float] | None = None

    for r in range(-int(max_coef), int(max_coef) + 1):
        for s in range(-int(max_coef), int(max_coef) + 1):
            if r == 0 and s == 0:
                continue
            det2 = (r * q) - (s * p)
            if det2 == 0 or abs(det2) > int(max_det):
                continue

            dot_val = (r * g11 * p) + (r * g12 * q) + (s * g12 * p) + (s * g22 * q)
            if abs(dot_val) > float(ortho_tol) * metric_scale:
                continue

            a_prime = (r * a_vec) + (s * b_vec)
            b_prime = (p * a_vec) + (q * b_vec)
            a_len = float(np.linalg.norm(a_prime))
            b_len = float(np.linalg.norm(b_prime))
            if a_len <= 1e-12 or b_len <= 1e-12:
                continue
            if max_a_len is not None and a_len > float(max_a_len):
                continue

            score = (a_len * b_len, abs(det2), abs(r) + abs(s))
            if best_score is None or score < best_score:
                best_score = score
                best_tuple = (r, s, det2, a_len, b_len, float(dot_val))

    if best_tuple is None:
        r, s = _complete_from_pq(p, q)
        a_prime = (r * a_vec) + (s * b_vec)
        b_prime = (p * a_vec) + (q * b_vec)
        a_len = float(np.linalg.norm(a_prime))
        b_len = float(np.linalg.norm(b_prime))
        if a_len <= 1e-12 or b_len <= 1e-12:
            raise RuntimeError("could not build non-degenerate lateral basis")
        fallback_dot = float(np.dot(a_prime, b_prime))
        if abs(fallback_dot) > float(ortho_tol) * metric_scale:
            raise RuntimeError(
                f"unimodular fallback exceeds ortho_tol: "
                f"|dot_ab|={abs(fallback_dot):.4e} > "
                f"{float(ortho_tol) * metric_scale:.4e}"
            )
        best_tuple = (r, s, 1, a_len, b_len, fallback_dot)

    r_best, s_best, det2, a_len, b_len, dot_val = best_tuple
    transform = np.eye(3, dtype=int)
    transform[0, 0] = int(r_best)
    transform[0, 1] = int(s_best)
    transform[1, 0] = int(p)
    transform[1, 1] = int(q)
    transform[2, 2] = 1

    transformed = slab.copy()
    transformed.make_supercell(transform)
    c_after = np.array(transformed.lattice.matrix[2], dtype=float)
    if (
        float(np.linalg.norm(c_after - c_vec)) > 1e-8
        and float(np.dot(c_after, c_vec)) < 0
    ):
        raise RuntimeError("in-plane reindex changed c-axis orientation")

    # Snap lattice to diagonal (orthogonal axes) preserving
    # fractional coords. The reindex guarantees a'·b' ≈ 0 and
    # c is already orthogonal from get_orthogonal_c_slab(), so
    # the snap is a rigid rotation with negligible shear.
    lat_rows = np.array(transformed.lattice.matrix, dtype=float)
    diag_lengths = np.array(
        [float(np.linalg.norm(lat_rows[i])) for i in range(3)],
        dtype=float,
    )
    transformed = Structure(
        Lattice(np.diag(diag_lengths)),
        transformed.species,
        transformed.frac_coords,
        coords_are_cartesian=False,
        site_properties=transformed.site_properties,
    )

    return transformed, {
        "p": int(p),
        "q": int(q),
        "r": int(r_best),
        "s": int(s_best),
        "det2d": int(det2),
        "a_len": float(a_len),
        "b_len": float(b_len),
        "dot_ab": float(dot_val),
    }


def _rotate_struct(
    structure: Structure,
    rotation: np.ndarray,
) -> Structure:
    lattice_rows = np.array(structure.lattice.matrix, dtype=float)
    cart_coords = np.array(structure.cart_coords, dtype=float)
    rotated_lattice = (rotation @ lattice_rows.T).T
    rotated_coords = (rotation @ cart_coords.T).T
    return Structure(
        Lattice(rotated_lattice),
        structure.species,
        rotated_coords,
        coords_are_cartesian=True,
        site_properties=structure.site_properties,
    )


def _align_c_then_b(
    slab_ref: Structure,
    slab_move: Structure,
) -> Structure:
    c_ref = _unit_vec(np.array(slab_ref.lattice.matrix[2], dtype=float))
    b_ref = _unit_vec(np.array(slab_ref.lattice.matrix[1], dtype=float))
    c_mov = _unit_vec(np.array(slab_move.lattice.matrix[2], dtype=float))

    cross_c = np.cross(c_mov, c_ref)
    sin_c = float(np.linalg.norm(cross_c))
    cos_c = float(np.clip(np.dot(c_mov, c_ref), -1.0, 1.0))
    if sin_c <= 1e-12:
        if cos_c > 0:
            rotation_c = np.eye(3)
        else:
            axis = _unit_vec(np.array(slab_ref.lattice.matrix[0], dtype=float))
            rotation_c = _rotation_from_axis_angle(axis, np.pi)
    else:
        axis = cross_c / sin_c
        angle = float(np.arctan2(sin_c, cos_c))
        rotation_c = _rotation_from_axis_angle(axis, angle)

    rotated = _rotate_struct(slab_move, rotation_c)

    b_mov = _unit_vec(np.array(rotated.lattice.matrix[1], dtype=float))
    b_ref_proj = b_ref - (np.dot(b_ref, c_ref) * c_ref)
    b_mov_proj = b_mov - (np.dot(b_mov, c_ref) * c_ref)
    if np.linalg.norm(b_ref_proj) <= 1e-12 or np.linalg.norm(b_mov_proj) <= 1e-12:
        return rotated

    b_ref_proj = _unit_vec(b_ref_proj)
    b_mov_proj = _unit_vec(b_mov_proj)
    sin_b = float(np.dot(c_ref, np.cross(b_mov_proj, b_ref_proj)))
    cos_b = float(np.clip(np.dot(b_mov_proj, b_ref_proj), -1.0, 1.0))
    twist = float(np.arctan2(sin_b, cos_b))
    rotation_b = _rotation_from_axis_angle(c_ref, twist)
    return _rotate_struct(rotated, rotation_b)


def _match_a_supercells(
    a1: float,
    a2: float,
    *,
    nmax: int,
    max_strain: float,
    max_aavg: float | None,
) -> tuple[float, int, int, float] | None:
    """Find smallest ``(n1, n2)`` whose strain is within threshold.

    Candidates are checked in order of increasing ``a_avg``.
    The first pair whose strain satisfies *max_strain* is
    returned immediately — no scaling is applied when the
    native ``(1, 1)`` pair already meets the threshold.
    Returns ``None`` when no pair satisfies both *max_strain*
    and *max_aavg*.
    """
    nmax_int = int(max(1, nmax))
    candidates: list[tuple[float, float, int, int]] = []

    for n1 in range(1, nmax_int + 1):
        a1_n = float(n1) * float(a1)
        if max_aavg is not None and 0.5 * a1_n > float(max_aavg):
            break
        for n2 in range(1, nmax_int + 1):
            a2_n = float(n2) * float(a2)
            a_avg = 0.5 * (a1_n + a2_n)
            if a_avg <= 1e-12:
                continue
            if max_aavg is not None and a_avg > float(max_aavg):
                continue
            strain = abs(a1_n - a2_n) / a_avg
            if strain <= float(max_strain):
                candidates.append((float(a_avg), float(strain), int(n1), int(n2)))

    if not candidates:
        return None

    # Sort by a_avg then strain and return the first match
    # (smallest supercell that satisfies the threshold).
    candidates.sort()
    best = candidates[0]
    return (best[1], best[2], best[3], best[0])


def _set_axis_affine(
    structure: Structure,
    *,
    axis: Literal["a", "b", "c"],
    target_length: float,
) -> Structure:
    axis_idx = {"a": 0, "b": 1, "c": 2}[str(axis)]
    lattice_rows = np.array(structure.lattice.matrix, dtype=float)
    vector = np.array(lattice_rows[axis_idx], dtype=float)
    vector_len = float(np.linalg.norm(vector))
    if vector_len <= 1e-12:
        raise ValueError(f"degenerate {axis}-axis")
    lattice_rows[axis_idx] = vector * (float(target_length) / vector_len)
    return Structure(
        Lattice(lattice_rows),
        structure.species,
        structure.frac_coords,
        coords_are_cartesian=False,
        site_properties=structure.site_properties,
    )


def _ensure_b_width(
    structure: Structure,
    *,
    min_b: float,
) -> tuple[Structure, int]:
    """Replicate along b until the atom span along b >= *min_b*.

    Uses the actual Cartesian extent of atoms projected onto the
    b lattice direction, so the returned structure is guaranteed
    to have a slab region at least *min_b* wide.
    """
    min_b_value = float(min_b)
    if min_b_value <= 0.0:
        return structure.copy(), 1

    b_vec = np.array(structure.lattice.matrix[1], dtype=float)
    b_len = float(np.linalg.norm(b_vec))
    if b_len <= 1e-12:
        return structure.copy(), 1

    b_hat = b_vec / b_len
    _, _, span = _span_along(structure, b_hat)
    if span >= min_b_value:
        return structure.copy(), 1

    # new_span = span + (factor - 1) * b_len
    factor = max(
        2,
        int(
            np.ceil(
                (min_b_value - float(span)) / b_len,
            )
        )
        + 1,
    )
    scaled = structure.copy()
    scaled.make_supercell([[1, 0, 0], [0, int(factor), 0], [0, 0, 1]])
    return scaled, int(factor)


def _wrap_frac(
    structure: Structure,
    *,
    eps: float = 1e-8,
) -> Structure:
    """Wrap all fractional coordinates into [0, 1)."""
    frac = np.mod(structure.frac_coords.copy().astype(float), 1.0)
    frac[np.abs(frac - 1.0) < eps] = 0.0
    frac[frac < 0.0] = np.mod(frac[frac < 0.0], 1.0)
    frac[np.abs(frac) < eps] = 0.0
    return Structure(
        structure.lattice,
        structure.species,
        frac,
        coords_are_cartesian=False,
        site_properties=structure.site_properties,
    )


def _recut_axis(
    structure: Structure,
    *,
    axis: int = 0,
) -> Structure:
    """Shift fractional origin along *axis* so the largest gap is behind.

    This positions atoms as compactly as possible along the given axis,
    matching legacy ``recut_axis_min_span``.
    """
    frac = structure.frac_coords.copy().astype(float)
    coord = np.mod(frac[:, axis], 1.0)
    if len(coord) == 0:
        return structure.copy()

    sorted_coords = np.sort(coord)
    gaps = np.diff(np.r_[sorted_coords, sorted_coords[0] + 1.0])
    largest_gap_idx = int(np.argmax(gaps))
    cut = float(sorted_coords[(largest_gap_idx + 1) % len(sorted_coords)] % 1.0)
    frac[:, axis] = np.mod(coord - cut, 1.0)
    return Structure(
        structure.lattice,
        structure.species,
        frac,
        coords_are_cartesian=False,
        site_properties=structure.site_properties,
    )


def _group_layers_b(
    structure: Structure,
    *,
    layer_tol_frac: float,
) -> list[float]:
    frac_b = np.mod(np.asarray(structure.frac_coords[:, 1], dtype=float), 1.0)
    if frac_b.size == 0:
        return []

    order = np.argsort(frac_b)
    assigned = np.zeros(frac_b.shape[0], dtype=bool)
    centers: list[float] = []
    half_window = 0.5 * float(layer_tol_frac)

    for idx in order:
        if assigned[idx]:
            continue
        center = float(frac_b[idx])
        in_group = np.array(
            [
                min(abs(float(value) - center), 1.0 - abs(float(value) - center))
                <= half_window
                for value in frac_b
            ],
            dtype=bool,
        )
        assigned |= in_group
        centers.append(center)

    centers.sort()
    return centers


def _b_shift_fracs(
    structure: Structure,
    *,
    enabled: bool,
    dedup_tol_frac: float,
) -> list[float]:
    if not enabled:
        return [0.0]

    layer_tol = 0.10
    layer_centers = _group_layers_b(
        structure,
        layer_tol_frac=layer_tol,
    )
    if not layer_centers:
        return [0.0]

    tol = float(max(1e-6, dedup_tol_frac))
    deduped_centers: list[float] = []
    for center in layer_centers:
        if all(
            min(
                abs(float(center) - float(existing)),
                1.0 - abs(float(center) - float(existing)),
            )
            > tol
            for existing in deduped_centers
        ):
            deduped_centers.append(float(center))

    out = [0.0]
    for center in deduped_centers:
        shift = float(center % 1.0)
        if min(abs(shift - 0.0), 1.0 - abs(shift - 0.0)) <= tol:
            continue
        out.append(shift)
    return out


def _span_along(
    structure: Structure,
    direction_hat: np.ndarray,
) -> tuple[float, float, float]:
    projections = np.dot(
        structure.cart_coords.astype(float),
        np.array(direction_hat, dtype=float),
    )
    proj_min = float(np.min(projections))
    proj_max = float(np.max(projections))
    return proj_min, proj_max, float(proj_max - proj_min)


def _join_along_b(
    slab1: Structure,
    slab2: Structure,
    *,
    gap: float,
    ang_tol_rad: float,
) -> tuple[Structure, float, float, float, float]:
    a1 = np.array(slab1.lattice.matrix[0], dtype=float)
    b1 = np.array(slab1.lattice.matrix[1], dtype=float)
    c1 = np.array(slab1.lattice.matrix[2], dtype=float)
    a2 = np.array(slab2.lattice.matrix[0], dtype=float)
    b2 = np.array(slab2.lattice.matrix[1], dtype=float)
    c2 = np.array(slab2.lattice.matrix[2], dtype=float)

    def _is_parallel(vec1: np.ndarray, vec2: np.ndarray) -> bool:
        theta = float(
            np.arccos(
                np.clip(
                    np.dot(_unit_vec(vec1), _unit_vec(vec2)),
                    -1.0,
                    1.0,
                )
            )
        )
        return theta <= ang_tol_rad or abs(np.pi - theta) <= ang_tol_rad

    if not (_is_parallel(a1, a2) and _is_parallel(b1, b2) and _is_parallel(c1, c2)):
        raise RuntimeError("slabs are not parallel-aligned for lateral join")

    b_hat = _unit_vec(b1)
    min1, _max1, span1 = _span_along(slab1, b_hat)
    min2, _max2, span2 = _span_along(slab2, b_hat)

    cart1 = slab1.cart_coords.astype(float).copy()
    cart2 = slab2.cart_coords.astype(float).copy()
    cart1 -= (min1 * b_hat)[None, :]
    cart2 -= (min2 * b_hat)[None, :]

    shift2 = (float(span1) + float(gap)) * b_hat
    b_total = float(span1 + gap + span2 + gap)
    interface_position = float(span1 + (0.5 * float(gap)))
    measured_gap = float(gap)
    thickness1 = float(span1)
    thickness2 = float(span2)
    carts = np.vstack([cart1, cart2 + shift2])

    lattice = Lattice(np.vstack([a1, (b_hat * b_total), c1]))
    species = list(slab1.species) + list(slab2.species)
    mask_values = ["surface1"] * len(slab1) + ["surface2"] * len(slab2)
    interface_structure = Structure(
        lattice,
        species,
        carts,
        coords_are_cartesian=True,
        site_properties={"mask": mask_values},
    )
    interface_structure = _shift_to_zero(interface_structure)
    if not isinstance(interface_structure, Structure):
        raise RuntimeError("failed to build lateral interface structure")

    return (
        interface_structure,
        measured_gap,
        interface_position,
        thickness1,
        thickness2,
    )


def _resolve_join_miller(
    slab: Structure,
    p: int,
    q: int,
    bulk_structure: Structure,
    surface_directions: list[tuple[int, int, int]] | None,
) -> tuple[int, int, int] | None:
    """Map a lateral (p,q) join direction to its bulk Miller index.

    The join vector ``p * a_slab + q * b_slab`` lives in the slab's
    ab-plane Cartesian frame — the same frame as the bulk lattice
    before any reindex/rotation transforms.  Candidate directions
    from ``surface_directions`` are compared using the bulk
    **reciprocal lattice** so the mapping is correct for all crystal
    systems (not just cubic).
    """
    if not surface_directions or bulk_structure is None:
        return None

    a_slab = np.array(slab.lattice.matrix[0], dtype=float)
    b_slab = np.array(slab.lattice.matrix[1], dtype=float)
    join_vec = float(p) * a_slab + float(q) * b_slab
    join_norm = float(np.linalg.norm(join_vec))
    if join_norm <= 1e-12:
        return None
    join_hat = join_vec / join_norm

    recip_rows = np.array(
        bulk_structure.lattice.reciprocal_lattice.matrix,
        dtype=float,
    )

    best: tuple[float, tuple[int, int, int]] | None = None
    for direction in surface_directions:
        try:
            h, k, l = _normalize_miller(tuple(direction))
        except Exception:
            continue
        g_vec = (
            float(h) * recip_rows[0]
            + float(k) * recip_rows[1]
            + float(l) * recip_rows[2]
        )
        g_norm = float(np.linalg.norm(g_vec))
        if g_norm <= 1e-12:
            continue
        score = abs(float(np.dot(g_vec / g_norm, join_hat)))
        if best is None or score > best[0]:
            best = (score, (int(h), int(k), int(l)))

    if best is None:
        return None
    return best[1]


def _process_lateral(
    bulk1: Union[Structure, str],
    bulk2: Union[Structure, str],
    miller1: Union[tuple, int],
    miller2: Union[tuple, int],
    bulk1_thickness: float,
    bulk2_thickness: float,
    gap: float,
    vacuum: float,
    settings: dict[str, Any],
    **kwargs: Any,
) -> list["Interface"]:
    from slabfy.core import Surface, Interface

    verbose = bool(settings.get("verbose", 1))

    _vprint = _make_vprint("join", verbose)

    bulk1_structure = _resolve_bulk(bulk1)
    bulk2_structure = _resolve_bulk(bulk2)
    bulk1_oxi = _prep_charges(bulk1_structure, verbose=verbose)
    bulk2_oxi = _prep_charges(bulk2_structure, verbose=verbose)

    bulk1_width = float(kwargs.get("bulk1_width", 5.0))
    bulk2_width = float(kwargs.get("bulk2_width", 5.0))

    def _parse_bulk_termination(
        value: Any,
        kwarg_name: str,
    ) -> tuple[int, str] | None:
        if value is None:
            return None
        if not isinstance(value, (tuple, list)) or len(value) != 2:
            raise ValueError(
                f"{kwarg_name} must be a tuple/list like (slab_index, slab_termination)"
            )

        slab_index = int(value[0])
        slab_termination = str(value[1]).strip().upper()
        if slab_index < 1:
            raise ValueError(f"{kwarg_name}[0] must be >= 1")
        if slab_termination not in ("UP", "DN", "SY"):
            raise ValueError(f"{kwarg_name}[1] must be one of 'UP', 'DN', or 'SY'")
        return (slab_index, slab_termination)

    bulk1_termination = _parse_bulk_termination(
        kwargs.get("bulk1_termination", None),
        "bulk1_termination",
    )
    bulk2_termination = _parse_bulk_termination(
        kwargs.get("bulk2_termination", None),
        "bulk2_termination",
    )

    lateral_max_pq = 10
    lateral_max_dirs_keep = 30
    lateral_max_len_join = 15.0
    lateral_max_pq_l1 = 4

    lateral_reindex_max_coef = 5
    lateral_reindex_max_det = 4
    lateral_reindex_ortho_tol = float(kwargs.get("lateral_ortho_tol", 1e-1))
    lateral_reindex_max_a_len = kwargs.get("lateral_reindex_max_a_len", None)
    if lateral_reindex_max_a_len is not None:
        lateral_reindex_max_a_len = float(lateral_reindex_max_a_len)

    enable_contact_shifts = bool(kwargs.get("enable_contact_shifts", False))

    lateral_max_a_pair_strain = float(kwargs.get("lateral_max_a_pair_strain", 0.10))
    lateral_max_aavg = kwargs.get("lateral_max_aavg", 15.0)
    if lateral_max_aavg is not None:
        lateral_max_aavg = float(lateral_max_aavg)
    # Fixed generous angular tolerance for the join parallelism
    # check — the real screening is now ortho_tol in reindexing.
    lateral_ang_tol_rad = float(np.deg2rad(5.0))

    hkls1 = _resolve_miller_targets(
        bulk1_structure,
        miller1,
        min_slab_thickness=bulk1_thickness,
    )
    hkls2 = _resolve_miller_targets(
        bulk2_structure,
        miller2,
        min_slab_thickness=bulk2_thickness,
    )
    if not hkls1 or not hkls2:
        return []

    def _build_dataset(
        bulk_raw: Structure,
        bulk_for_slab: Structure,
        hkls: list[tuple[int, int, int]],
        *,
        min_slab_size: float,
        requested_termination: tuple[int, str] | None,
    ) -> list[dict[str, Any]]:
        dataset: list[dict[str, Any]] = []
        for hkl in hkls:
            try:
                slab_generator = SlabGenerator(
                    bulk_for_slab,
                    tuple(hkl),
                    min_slab_size=float(min_slab_size),
                    min_vacuum_size=max(float(vacuum), 1.0),
                    center_slab=False,
                )
                slabs = slab_generator.get_slabs(ftol=1e-12, symmetrize=False)
            except Exception:
                continue
            if not slabs:
                continue

            # Reference layer count for c-scaling (same logic
            # as _process_slab / Sculptor.cleave).
            layers_ref = 1
            try:
                ref_gen = SlabGenerator(
                    bulk_for_slab,
                    tuple(hkl),
                    min_slab_size=1,
                    min_vacuum_size=0,
                )
                ref_slabs = ref_gen.get_slabs(ftol=1e-12)
                if ref_slabs:
                    layers_ref = len({round(s.c, 6) for s in ref_slabs[0].sites})
                    layers_ref = max(layers_ref, 1)
            except Exception:
                pass

            candidates = list(enumerate(slabs, start=1))
            if requested_termination is not None:
                idx = int(requested_termination[0])
                if 1 <= idx <= len(slabs):
                    candidates = [(idx, slabs[idx - 1])]
                else:
                    continue

            for term_idx, slab_obj in candidates:
                try:
                    slab_orth = slab_obj.get_orthogonal_c_slab()
                except Exception:
                    slab_orth = slab_obj
                try:
                    slab_orth = _set_vacuum(slab_orth, float(vacuum))
                except Exception:
                    pass
                slab_orth = _shift_to_zero(slab_orth)
                if not isinstance(slab_orth, Slab):
                    continue

                slab_structure = _struct_snapshot(slab_orth)
                thickness_local, vacuum_local = _slab_geometry(slab_orth)
                surface_obj = Surface(
                    slab_structure,
                    bulk=bulk_raw,
                    miller=tuple(hkl),
                    thickness=float(thickness_local),
                    vacuum=float(vacuum_local),
                    symmetric=bool(slab_orth.is_symmetric()),
                    slab_termination="SY" if slab_orth.is_symmetric() else "UP",
                    slab_index=int(term_idx),
                    surface_axis_layers=_axis_layers(slab_orth, axis="c"),
                    surface_dipole=_dipole_along_axis(
                        slab_orth,
                        np.array(slab_orth.lattice.matrix[2], dtype=float),
                    ),
                    surface_area=slab_orth.surface_area,
                    stoichiometric=_is_stoich(bulk_for_slab, slab_orth),
                )
                layers = len(surface_obj.surface_axis_layers)
                c_scale = int(max(1, round(layers / layers_ref)))
                surface_obj.scaling = (1, 1, c_scale)
                try:
                    surface_obj.surface_sites = _map_surface_sites(surface_obj)
                except Exception:
                    surface_obj.surface_sites = {}
                try:
                    surface_obj.surface_directions = _map_surface_directions(
                        surface_obj
                    )
                except Exception:
                    surface_obj.surface_directions = []

                directions = _enumerate_dirs(
                    slab_orth,
                    max_pq=lateral_max_pq,
                    max_dirs_keep=lateral_max_dirs_keep,
                    max_len_join=lateral_max_len_join,
                    max_pq_l1=lateral_max_pq_l1,
                )
                for direction in directions:
                    p_val, q_val = direction["pq"]
                    try:
                        slab_reindexed, reindex_meta = _reindex_slab(
                            slab_orth,
                            int(p_val),
                            int(q_val),
                            max_coef=lateral_reindex_max_coef,
                            max_det=lateral_reindex_max_det,
                            ortho_tol=lateral_reindex_ortho_tol,
                            max_a_len=lateral_reindex_max_a_len,
                        )
                    except Exception:
                        continue

                    # Resolve bulk hkl⟂ from (p,q) in the pre-rotation
                    # slab frame using reciprocal-lattice matching.
                    hkl_perp = _resolve_join_miller(
                        slab_orth,
                        int(p_val),
                        int(q_val),
                        bulk_raw,
                        surface_obj.surface_directions,
                    )

                    variants: list[tuple[str, Structure, Surface]] = [
                        (
                            surface_obj.slab_termination or "UP",
                            slab_reindexed,
                            surface_obj,
                        )
                    ]
                    if not bool(surface_obj.symmetric):
                        dn_slab = _invert_c(slab_reindexed)
                        dn_surface = Surface(
                            _struct_snapshot(dn_slab),
                            bulk=surface_obj.bulk,
                            miller=tuple(surface_obj.miller),
                            thickness=surface_obj.thickness,
                            vacuum=surface_obj.vacuum,
                            symmetric=False,
                            slab_termination="DN",
                            slab_index=surface_obj.slab_index,
                            surface_axis_layers=surface_obj.surface_axis_layers,
                            surface_dipole=(
                                None
                                if surface_obj.surface_dipole is None
                                else -float(surface_obj.surface_dipole)
                            ),
                            surface_area=surface_obj.surface_area,
                            stoichiometric=surface_obj.stoichiometric,
                            scaling=surface_obj.scaling,
                        )
                        try:
                            dn_surface.surface_sites = _map_surface_sites(dn_surface)
                        except Exception:
                            dn_surface.surface_sites = {}
                        dn_surface.surface_directions = list(
                            surface_obj.surface_directions or []
                        )
                        variants.append(("DN", dn_slab, dn_surface))

                    if requested_termination is not None:
                        requested_label = requested_termination[1]
                        allowed_labels = {requested_label}
                        if requested_label in ("UP", "DN"):
                            allowed_labels.add("SY")
                        variants = [
                            variant
                            for variant in variants
                            if str(variant[0]).upper() in allowed_labels
                        ]
                        if not variants:
                            continue

                    for termination_label, slab_variant, surface_variant in variants:
                        b_shift_fracs = _b_shift_fracs(
                            slab_variant,
                            enabled=enable_contact_shifts,
                            dedup_tol_frac=0.01,
                        )
                        b_shifts_data: list[tuple[int, float, Structure]] = []
                        for shift_idx, shift_frac in enumerate(b_shift_fracs):
                            shifted = slab_variant.copy()
                            if abs(float(shift_frac)) > 1e-12:
                                shifted.translate_sites(
                                    list(range(len(shifted))),
                                    [0.0, float(shift_frac), 0.0],
                                    frac_coords=True,
                                    to_unit_cell=True,
                                )
                            b_shifts_data.append(
                                (int(shift_idx), float(shift_frac), shifted)
                            )
                        dataset.append(
                            {
                                "surface": surface_variant,
                                "surface_hkl": tuple(hkl),
                                "termination_idx": int(term_idx),
                                "termination_label": termination_label,
                                "pq": (int(p_val), int(q_val)),
                                "join_len": float(direction["length"]),
                                "slab": slab_variant,
                                "reindex_meta": reindex_meta,
                                "hkl_perp": hkl_perp,
                                "b_shifts": b_shifts_data,
                            }
                        )
        return dataset

    dataset1 = _build_dataset(
        bulk1_structure,
        bulk1_oxi,
        hkls1,
        min_slab_size=bulk1_thickness,
        requested_termination=bulk1_termination,
    )
    dataset2 = _build_dataset(
        bulk2_structure,
        bulk2_oxi,
        hkls2,
        min_slab_size=bulk2_thickness,
        requested_termination=bulk2_termination,
    )
    if not dataset1 or not dataset2:
        _vprint("no lateral slab candidates after direction/reindex filtering")
        return []

    _vprint(f"lateral candidates: bulk1={len(dataset1)} bulk2={len(dataset2)}")

    ranked_candidates: list[dict[str, Any]] = []
    attempts = 0
    matched_count = 0
    for entry1 in dataset1:
        for s1_idx, s1_frac, slab1_shifted in entry1["b_shifts"]:
            for entry2 in dataset2:
                for s2_idx, s2_frac, slab2_shifted in entry2["b_shifts"]:
                    attempts += 1
                    _vprint(
                        f"  pair {attempts}: "
                        f"hkl1={entry1['surface_hkl']} "
                        f"pq1={entry1['pq']} "
                        f"term1={entry1['termination_label']} "
                        f"bshift1={s1_frac:.3f} | "
                        f"hkl2={entry2['surface_hkl']} "
                        f"pq2={entry2['pq']} "
                        f"term2={entry2['termination_label']} "
                        f"bshift2={s2_frac:.3f}"
                    )
                    try:
                        slab2_aligned = _align_c_then_b(
                            slab1_shifted,
                            slab2_shifted,
                        )
                    except Exception:
                        continue

                    a1_val = float(slab1_shifted.lattice.a)
                    a2_val = float(slab2_aligned.lattice.a)
                    match = _match_a_supercells(
                        a1_val,
                        a2_val,
                        nmax=10,
                        max_strain=lateral_max_a_pair_strain,
                        max_aavg=lateral_max_aavg,
                    )
                    if match is None:
                        naive = abs(a1_val - a2_val) / max(
                            0.5 * (a1_val + a2_val),
                            1e-12,
                        )
                        _vprint(
                            f"    -> SKIP a1={a1_val:.4f} "
                            f"a2={a2_val:.4f} "
                            f"min_strain={naive:.5f}"
                        )
                        continue
                    matched_count += 1
                    a_pair_strain, n1, n2, a_avg = match
                    _vprint(
                        f"    -> OK strain={a_pair_strain:.5f} "
                        f"n=({n1},{n2}) "
                        f"a_avg={a_avg:.4f}"
                    )

                    slab1_match = slab1_shifted.copy()
                    slab1_match.make_supercell([[int(n1), 0, 0], [0, 1, 0], [0, 0, 1]])
                    slab2_match = slab2_aligned.copy()
                    slab2_match.make_supercell([[int(n2), 0, 0], [0, 1, 0], [0, 0, 1]])
                    slab1_match = _set_axis_affine(
                        slab1_match,
                        axis="a",
                        target_length=float(a_avg),
                    )
                    slab2_match = _set_axis_affine(
                        slab2_match,
                        axis="a",
                        target_length=float(a_avg),
                    )

                    # Width enforcement AFTER a-matching and
                    # AFTER b-shift selection (shifts were computed
                    # on the pre-width reindexed slab).
                    slab1_match, bmult1 = _ensure_b_width(
                        slab1_match,
                        min_b=bulk1_width,
                    )
                    slab2_match, bmult2 = _ensure_b_width(
                        slab2_match,
                        min_b=bulk2_width,
                    )

                    c_common = float(max(slab1_match.lattice.c, slab2_match.lattice.c))
                    slab1_match = _set_axis_affine(
                        slab1_match,
                        axis="c",
                        target_length=c_common,
                    )
                    slab2_match = _set_axis_affine(
                        slab2_match,
                        axis="c",
                        target_length=c_common,
                    )

                    # Wrap + recut for clean structure (legacy step)
                    slab1_match = _recut_axis(
                        _wrap_frac(slab1_match),
                        axis=0,
                    )
                    slab2_match = _recut_axis(
                        _wrap_frac(slab2_match),
                        axis=0,
                    )

                    try:
                        (
                            combo,
                            measured_gap,
                            interface_position,
                            thickness1,
                            thickness2,
                        ) = _join_along_b(
                            slab1_match,
                            slab2_match,
                            gap=gap,
                            ang_tol_rad=lateral_ang_tol_rad,
                        )
                    except Exception:
                        continue

                    ranked_candidates.append(
                        {
                            "surface1": entry1["surface"],
                            "surface2": entry2["surface"],
                            "surface1_component": slab1_match,
                            "surface2_component": slab2_match,
                            "surface1_termination": str(
                                entry1.get(
                                    "termination_label",
                                    entry1["surface"].slab_termination or "UP",
                                )
                            ),
                            "surface2_termination": str(
                                entry2.get(
                                    "termination_label",
                                    entry2["surface"].slab_termination or "UP",
                                )
                            ),
                            "structure": combo,
                            "a_pair_strain": float(a_pair_strain),
                            "a_avg": float(a_avg),
                            "n_a": (int(n1), int(n2)),
                            "b_mult": (int(bmult1), int(bmult2)),
                            "a_scale": (int(n1), int(n2)),
                            "gap": float(measured_gap),
                            "interface_position": float(
                                interface_position,
                            ),
                            "thickness1": float(thickness1),
                            "thickness2": float(thickness2),
                            "pq1": entry1["pq"],
                            "pq2": entry2["pq"],
                            "join_len1": float(entry1["join_len"]),
                            "join_len2": float(entry2["join_len"]),
                            "reindex1": entry1["reindex_meta"],
                            "reindex2": entry2["reindex_meta"],
                            "hkl_perp1": entry1.get("hkl_perp"),
                            "hkl_perp2": entry2.get("hkl_perp"),
                            "b_shift_frac": (
                                float(s1_frac),
                                float(s2_frac),
                            ),
                            "b_shift_idx": (
                                int(s1_idx),
                                int(s2_idx),
                            ),
                        }
                    )

    if not ranked_candidates:
        _vprint(f"no lateral pair matched after {attempts} pairing attempts")
        return []

    _vprint(
        f"lateral pairing: {attempts} tested, "
        f"{matched_count} matched, "
        f"{len(ranked_candidates)} candidates"
    )

    ranked_candidates.sort(
        key=lambda entry: (
            float(entry["a_avg"]),
            float(entry["a_pair_strain"]),
        )
    )

    # Dedup: each (term_pair, pq_pair, b_shift) identity is
    # unique.  Symmetry-equivalent pq directions were already
    # collapsed per-structure in _enumerate_dirs,
    # so every surviving (pq1, pq2) pair is physically distinct.
    deduped_candidates: list[dict[str, Any]] = []
    seen_keys: set[tuple[Any, ...]] = set()
    for entry in ranked_candidates:
        key: tuple[Any, ...] = (
            int(entry["surface1"].slab_index or 0),
            str(entry["surface1_termination"]),
            int(entry["surface2"].slab_index or 0),
            str(entry["surface2_termination"]),
            entry["pq1"],
            entry["pq2"],
            int(entry["b_shift_idx"][0]),
            int(entry["b_shift_idx"][1]),
        )
        if key in seen_keys:
            continue
        seen_keys.add(key)
        deduped_candidates.append(entry)

    ranked_candidates = deduped_candidates

    _vprint(f"lateral dedup: {len(ranked_candidates)} unique")

    # --- Assign slab_index so UP/DN pairs share the same id ---
    # Normalize termination: DN→UP so that UP×SY and DN×SY
    # map to the same group.
    _dn_norm: dict[str, str] = {"DN": "UP"}
    group_idx_map: dict[tuple[Any, ...], int] = {}
    next_group = 1
    for candidate in ranked_candidates:
        t1 = str(
            candidate.get(
                "surface1_termination",
                candidate["surface1"].slab_termination or "UP",
            )
        )
        t2 = str(
            candidate.get(
                "surface2_termination",
                candidate["surface2"].slab_termination or "UP",
            )
        )
        group_key: tuple[Any, ...] = (
            int(candidate["surface1"].slab_index or 0),
            _dn_norm.get(t1, t1),
            int(candidate["b_shift_idx"][0]),
            int(candidate["surface2"].slab_index or 0),
            _dn_norm.get(t2, t2),
            int(candidate["b_shift_idx"][1]),
            candidate["pq1"],
            candidate["pq2"],
        )
        if group_key not in group_idx_map:
            group_idx_map[group_key] = next_group
            next_group += 1

    interfaces_out: list[Interface] = []
    for candidate in ranked_candidates:
        structure_base = _shift_to_zero(candidate["structure"])
        if not isinstance(structure_base, Structure):
            continue

        # Use pre-computed hkl⟂ resolved at (p,q) enumeration time
        # using reciprocal-lattice matching in the pre-rotation frame.
        inferred_miller1 = candidate.get("hkl_perp1")
        inferred_miller2 = candidate.get("hkl_perp2")
        if inferred_miller1 is None:
            inferred_miller1 = tuple(candidate["surface1"].miller)
        if inferred_miller2 is None:
            inferred_miller2 = tuple(candidate["surface2"].miller)

        term1 = str(
            candidate.get(
                "surface1_termination",
                candidate["surface1"].slab_termination or "UP",
            )
        )
        term2 = str(
            candidate.get(
                "surface2_termination",
                candidate["surface2"].slab_termination or "UP",
            )
        )

        # Determine slab_index from group mapping
        group_key = (
            int(candidate["surface1"].slab_index or 0),
            _dn_norm.get(term1, term1),
            int(candidate["b_shift_idx"][0]),
            int(candidate["surface2"].slab_index or 0),
            _dn_norm.get(term2, term2),
            int(candidate["b_shift_idx"][1]),
            candidate["pq1"],
            candidate["pq2"],
        )
        idx = group_idx_map[group_key]

        # Determine slab_termination from component terms
        if term1 == "SY" and term2 == "SY":
            interface_term = "SY"
        elif term1 == "DN" or term2 == "DN":
            interface_term = "DN"
        else:
            interface_term = "UP"

        surface1_component = candidate["surface1_component"]
        surface2_component = candidate["surface2_component"]
        structure_obj = structure_base
        measured_gap = float(candidate["gap"])
        interface_position = float(candidate["interface_position"])

        surface1_variant = _build_component_surface(
            surface1_component,
            candidate["surface1"],
            bulk_structure=bulk1_structure,
            miller=tuple(candidate["surface1"].miller),
            slab_index=idx,
            slab_termination=term1,
        )
        surface2_variant = _build_component_surface(
            surface2_component,
            candidate["surface2"],
            bulk_structure=bulk2_structure,
            miller=tuple(candidate["surface2"].miller),
            slab_index=idx,
            slab_termination=term2,
        )

        surface1_variant.scaling = (
            int(candidate["a_scale"][0]),
            int(candidate["b_mult"][0]),
            int(
                _normalize_scaling(
                    candidate["surface1"].scaling,
                )[2]
            ),
        )
        surface2_variant.scaling = (
            int(candidate["a_scale"][1]),
            int(candidate["b_mult"][1]),
            int(
                _normalize_scaling(
                    candidate["surface2"].scaling,
                )[2]
            ),
        )

        # Recompute surface_sites with final scaling so
        # normalization uses the correct (na, nb) values.
        surface1_variant.surface_sites = _map_surface_sites(surface1_variant)
        surface2_variant.surface_sites = _map_surface_sites(surface2_variant)

        surface1_variant.surface_area = _area_ab(
            surface1_variant.slab,
        )
        surface2_variant.surface_area = _area_ab(
            surface2_variant.slab,
        )

        axis_vector = np.array(
            structure_obj.lattice.matrix[1],
            dtype=float,
        )
        interface_depth = 2.0
        interface_thickness = max(
            float(surface1_variant.thickness or 0.0),
            float(surface2_variant.thickness or 0.0),
        )
        interface_area = float(
            interface_thickness * float(structure_obj.lattice.a),
        )
        interface_dipole = _dipole_along_axis(
            structure_obj,
            axis_vector,
            center_position=interface_position,
            window_depth=interface_depth,
        )
        interface_density = _density_near_axis(
            structure_obj,
            axis_vector,
            interface_position,
            interface_depth,
        )
        interface_axis_layers = _axis_layers(
            structure_obj,
            axis="b",
        )

        metadata: dict[str, Any] = {
            "lateral": {
                "pq1": candidate["pq1"],
                "pq2": candidate["pq2"],
                "join_len1": candidate["join_len1"],
                "join_len2": candidate["join_len2"],
                "n_a": candidate["n_a"],
                "b_mult": candidate["b_mult"],
                "a_avg": candidate["a_avg"],
                "a_pair_strain": candidate["a_pair_strain"],
                "reindex1": candidate["reindex1"],
                "reindex2": candidate["reindex2"],
                "b_shift_frac": candidate["b_shift_frac"],
                "b_shift_idx": candidate["b_shift_idx"],
                "surface_terminations": (term1, term2),
            },
        }

        interfaces_out.append(
            Interface(
                structure_obj,
                surface1=surface1_variant,
                surface2=surface2_variant,
                miller1=tuple(inferred_miller1),
                miller2=tuple(inferred_miller2),
                slab_index=idx,
                slab_termination=interface_term,
                mode="lateral",
                stoichiometric=bool(
                    surface1_variant.stoichiometric and surface2_variant.stoichiometric
                ),
                symmetric=bool(
                    surface1_variant.symmetric and surface2_variant.symmetric
                ),
                interface_axis="b",
                interface_axis_layers=interface_axis_layers,
                interface_axis_position=float(interface_position),
                gap=float(measured_gap),
                scaling=(1, 1, 1),
                interface_strain=float(
                    candidate["a_pair_strain"],
                ),
                interface_area=float(interface_area),
                interface_dipole=float(interface_dipole),
                interface_density=float(interface_density),
                thickness=float(interface_thickness),
                vacuum=float(vacuum),
                interface_sites=None,
                interface_metadata=metadata,
            )
        )

    return interfaces_out


# ── §9  Decoration pipeline ───────────────────────────────────────────


def _process_decorate(
    surface: Union["Surface", str],
    adparticle: Union[Structure, str],
    surface_sites: Union[tuple[float, float, float], str],
    adparticle_sites: list[Union[str, int]] | None = None,
    c_distance: float = 3.0,
    lat_distance: float = 8.0,
    coverage: float | None = None,
    *,
    settings: dict[str, Any] | None = None,
) -> tuple["Surface", int]:
    """Core decorate routine returning decorated Surface and placed count."""
    from slabfy.core import Surface, Interface

    if settings is None:
        settings = {}
    verbose = bool(settings.get("verbose", 1))

    _vprint = _make_vprint("decorate", verbose)

    def _resolve_surface(surface_input: Union[Surface, str]) -> Surface:
        if isinstance(surface_input, Surface):
            return surface_input
        if not isinstance(surface_input, str):
            raise ValueError("surface must be a Surface instance or a file path")
        if not os.path.exists(surface_input):
            raise ValueError(f"surface path does not exist: {surface_input}")
        try:
            loaded_surface = Surface.read(surface_input)
            if loaded_surface.slab is None:
                raise ValueError("loaded Surface object has no slab")
            return loaded_surface
        except Exception as exc:
            raise ValueError(
                "surface file must contain serialized Surface metadata "
                "(create it with Sculptor.cleave output-mode=2)"
            ) from exc

    def _resolve_adparticle_structure(
        adparticle_input: Union[Structure, str],
    ) -> Structure:
        structure_obj = _coerce_adparticle(adparticle_input)
        if structure_obj is None:
            raise ValueError(
                "adparticle must be a Structure or string (path or species symbol)"
            )
        return structure_obj

    def _extract_oxidation_charges(
        structure_obj: Structure,
    ) -> np.ndarray:
        try:
            decorated = AutoOxiStateDecorationTransformation().apply_transformation(
                structure_obj
            )
        except Exception:
            decorated = structure_obj

        charges: list[float] = []
        for site in decorated.sites:
            charge = 0.0
            for specie in site.species:
                oxi_state = getattr(specie, "oxi_state", None)
                if oxi_state is not None:
                    charge = float(oxi_state)
                    break
            charges.append(charge)
        return np.array(charges, dtype=float)

    def _resolve_adparticle_with_charges(
        adparticle_input: Union[Structure, str],
    ) -> tuple[
        Structure,
        list[Union[str, DummySpecie]],
        np.ndarray,
        np.ndarray,
    ]:
        structure = _resolve_adparticle_structure(adparticle_input)
        species = [next(iter(site.species.keys())) for site in structure.sites]
        coords = np.array(structure.cart_coords, dtype=float)
        charges = _extract_oxidation_charges(structure)
        return structure, species, coords, charges

    def _rotation_matrix_from_vectors(
        source: np.ndarray,
        target: np.ndarray,
    ) -> np.ndarray:
        source_u = source / np.linalg.norm(source)
        target_u = target / np.linalg.norm(target)
        v_cross = np.cross(source_u, target_u)
        v_norm = np.linalg.norm(v_cross)
        v_dot = float(np.dot(source_u, target_u))

        if v_norm < 1e-12:
            if v_dot > 0.0:
                return np.eye(3)
            axis = np.array([1.0, 0.0, 0.0])
            if abs(source_u[0]) > 0.9:
                axis = np.array([0.0, 1.0, 0.0])
            axis = axis - np.dot(axis, source_u) * source_u
            axis = axis / np.linalg.norm(axis)
            x, y, z = axis
            return np.array(
                [
                    [-1.0 + 2.0 * x * x, 2.0 * x * y, 2.0 * x * z],
                    [2.0 * x * y, -1.0 + 2.0 * y * y, 2.0 * y * z],
                    [2.0 * x * z, 2.0 * y * z, -1.0 + 2.0 * z * z],
                ],
                dtype=float,
            )

        skew = np.array(
            [
                [0.0, -v_cross[2], v_cross[1]],
                [v_cross[2], 0.0, -v_cross[0]],
                [-v_cross[1], v_cross[0], 0.0],
            ],
            dtype=float,
        )
        identity = np.eye(3)
        return identity + skew + skew @ skew * ((1.0 - v_dot) / (v_norm * v_norm))

    def _resolve_anchor_indices(
        species: list[Union[str, DummySpecie]],
        coords: np.ndarray,
        selected_sites: list[Union[str, int]] | None,
    ) -> list[int]:
        if not selected_sites:
            return []

        resolved: set[int] = set()
        for item in selected_sites:
            if isinstance(item, int):
                if item < 0:
                    raise ValueError("adparticle atom indices must be >= 0")
                idx = item - 1 if item >= 1 else item
                if idx >= len(coords):
                    raise ValueError(f"adparticle atom index out of range: {item}")
                resolved.add(idx)
            elif isinstance(item, str):
                matches = [
                    idx
                    for idx, specie in enumerate(species)
                    if str(specie).startswith(item)
                ]
                if not matches:
                    raise ValueError(f'no adparticle atoms matched symbol "{item}"')
                resolved.update(matches)
            else:
                raise ValueError(
                    "adparticle_sites must contain element symbols or atom indices"
                )

        return sorted(resolved)

    def _min_inplane_periodic_distance(lattice: Lattice) -> float:
        a_vec = np.array(lattice.matrix[0], dtype=float)
        b_vec = np.array(lattice.matrix[1], dtype=float)
        candidates = []
        for i in (-1, 0, 1):
            for j in (-1, 0, 1):
                if i == 0 and j == 0:
                    continue
                vector = i * a_vec + j * b_vec
                candidates.append(float(np.linalg.norm(vector)))
        return min(candidates) if candidates else 0.0

    def _ensure_supercell_for_lat_distance(
        target_surface: Surface,
        min_distance: float,
    ) -> None:
        if min_distance <= 0.0:
            return
        current_min = _min_inplane_periodic_distance(target_surface.slab.lattice)
        if current_min <= 1e-12:
            return
        if current_min >= min_distance:
            return
        multiplier = int(np.ceil(min_distance / current_min))
        multiplier = max(multiplier, 1)
        _vprint(
            f"lat_distance={min_distance:.3f} requires supercell "
            f"{multiplier}x{multiplier}x1"
        )
        target_surface.slab.make_supercell([multiplier, multiplier, 1])
        target_surface._refresh_metadata()

    def _parse_site_selector(
        target_surface: Surface,
        selector: Union[
            tuple[float, float, float],
            str,
        ],
    ) -> tuple[list[np.ndarray], str | None]:
        if isinstance(selector, tuple):
            if len(selector) != 3:
                raise ValueError("surface_sites tuple must have three values")
            coord = np.array(selector, dtype=float)
            if np.all(coord >= 0.0) and np.all(coord <= 1.0):
                coord = np.array(
                    target_surface.slab.lattice.get_cartesian_coords(coord),
                    dtype=float,
                )
            return [coord], None

        if not isinstance(selector, str):
            raise ValueError("surface_sites must be tuple or selector string")

        if target_surface.surface_sites is None:
            target_surface.surface_sites = _map_surface_sites(target_surface)

        selector_norm = selector.strip().lower()
        by_type = target_surface.surface_sites

        if not isinstance(by_type, dict) or not {
            "ontop",
            "bridge",
            "hollow",
        } <= set(by_type.keys()):
            raise ValueError(
                "surface.surface_sites must be raw ASF mapping with "
                "ontop/bridge/hollow keys"
            )

        by_label: dict[str, list[float]] = {}
        labels = {"ontop": "o", "bridge": "b", "hollow": "h"}
        for site_type, prefix in labels.items():
            cart_coords = by_type.get(site_type, [])
            if not isinstance(cart_coords, (list, tuple, np.ndarray)):
                continue
            for idx, site in enumerate(cart_coords, start=1):
                # Sites are stored as [a, b]; pad to 3D for
                # lattice conversion
                site_3d = [site[0], site[1], 0.0] if len(site) == 2 else site
                frac_coord = target_surface.slab.lattice.get_fractional_coords(site_3d)
                by_label[f"{prefix}{idx}"] = list(frac_coord)

        match = re.match(r"^([obh])(\d+)$", selector_norm)
        if not match:
            raise ValueError(
                "surface_sites selector must be in format oN|bN|hN (e.g. o1, b2, h3)"
            )
        site_id = f"{match.group(1)}{int(match.group(2))}"
        frac_site = by_label.get(site_id)
        if frac_site is None:
            raise ValueError(f"surface_sites selector not found on surface: {selector}")
        return [
            np.array(
                target_surface.slab.lattice.get_cartesian_coords(frac_site),
                dtype=float,
            )
        ], match.group(1)

    def _inplane_distance_periodic(
        lattice: Lattice,
        point_a_cart: np.ndarray,
        point_b_cart: np.ndarray,
    ) -> float:
        frac_a = np.array(lattice.get_fractional_coords(point_a_cart), dtype=float)
        frac_b = np.array(lattice.get_fractional_coords(point_b_cart), dtype=float)
        delta = frac_a - frac_b
        delta[0] -= np.round(delta[0])
        delta[1] -= np.round(delta[1])
        delta[2] = 0.0
        cart = np.array(lattice.get_cartesian_coords(delta), dtype=float)
        cart[2] = 0.0
        return float(np.linalg.norm(cart))

    def _surface_atom_charges(target_surface: Surface) -> np.ndarray:
        slab_structure = Structure(
            target_surface.slab.lattice,
            target_surface.slab.species,
            target_surface.slab.frac_coords,
            coords_are_cartesian=False,
        )
        return _extract_oxidation_charges(slab_structure)

    def _nearest_surface_atoms_for_site(
        target_surface: Surface,
        site_point: np.ndarray,
        site_kind: str,
    ) -> list[int]:
        needed = 2 if site_kind == "b" else 3
        cart_coords = np.array(target_surface.slab.cart_coords, dtype=float)
        z_top = float(np.max(cart_coords[:, 2]))
        top_mask = cart_coords[:, 2] >= (z_top - 2.0)
        candidate_indices = np.where(top_mask)[0].tolist()
        if len(candidate_indices) < needed:
            candidate_indices = list(range(len(cart_coords)))

        ranked = sorted(
            candidate_indices,
            key=lambda idx: _inplane_distance_periodic(
                target_surface.slab.lattice,
                cart_coords[idx],
                site_point,
            ),
        )
        return ranked[:needed]

    def _rotation_matrix_about_z(theta_rad: float) -> np.ndarray:
        cos_t = float(np.cos(theta_rad))
        sin_t = float(np.sin(theta_rad))
        return np.array(
            [
                [cos_t, -sin_t, 0.0],
                [sin_t, cos_t, 0.0],
                [0.0, 0.0, 1.0],
            ],
            dtype=float,
        )

    def _minimize_inplane_electrostatic_rotation(
        coords: np.ndarray,
        center: np.ndarray,
        anchor_indices: list[int],
        adparticle_charges: np.ndarray,
        slab_coords: np.ndarray,
        slab_charges: np.ndarray,
        surface_indices: list[int],
        translation: np.ndarray,
        samples: int = 72,
    ) -> np.ndarray:
        if not anchor_indices or not surface_indices:
            return coords

        best_metric = np.inf
        best_coords = coords
        rel = coords - center

        for theta in np.linspace(0.0, 2.0 * np.pi, num=samples, endpoint=False):
            rotation = _rotation_matrix_about_z(float(theta))
            rotated = (rel @ rotation.T) + center
            rotated_abs = rotated + translation

            net_force = np.zeros(3, dtype=float)
            for anchor_idx in anchor_indices:
                q_anchor = float(adparticle_charges[anchor_idx])
                if abs(q_anchor) <= 1e-12:
                    continue
                anchor_pos = rotated_abs[anchor_idx]
                for surf_idx in surface_indices:
                    q_surface = float(slab_charges[surf_idx])
                    if abs(q_surface) <= 1e-12:
                        continue
                    surface_pos = slab_coords[surf_idx]
                    delta = anchor_pos - surface_pos
                    distance = float(np.linalg.norm(delta))
                    if distance <= 1e-8:
                        continue
                    net_force += (q_anchor * q_surface) * delta / (distance**3)

            metric = float(np.linalg.norm(net_force))
            if metric < best_metric:
                best_metric = metric
                best_coords = rotated

        return best_coords

    def _apply_coverage(
        points: list[np.ndarray],
        value: float | None,
    ) -> list[np.ndarray]:
        if value is None:
            return points
        if not points:
            return points
        coverage_value = float(value)
        if coverage_value <= 0.0:
            raise ValueError("coverage must be > 0 when provided")
        if coverage_value > 1.0:
            raise ValueError("coverage must be <= 1.0 when provided")
        count = int(np.ceil(len(points) * coverage_value))
        count = max(1, min(count, len(points)))
        return points[:count]

    target_surface = _resolve_surface(surface)
    _vprint(f"decorating slab with {len(target_surface.slab)} base atoms")

    if coverage is None:
        _ensure_supercell_for_lat_distance(target_surface, float(lat_distance))

    if target_surface.surface_sites is None:
        target_surface.surface_sites = _map_surface_sites(target_surface)

    selected_site_points, selected_site_kind = _parse_site_selector(
        target_surface,
        surface_sites,
    )

    # Pad 2D stored sites → 3D (c=0) for expansion helpers
    selected_site_points = [
        (
            np.array([p[0], p[1], 0.0], dtype=float)
            if len(p) == 2
            else np.array(p, dtype=float)
        )
        for p in selected_site_points
    ]

    # Expand unique-per-unit-cell sites to full supercell
    if isinstance(target_surface, Interface):
        na_int = min(
            int(
                getattr(
                    target_surface.surface1,
                    "scaling",
                    (1,),
                )[0]
            ),
            int(
                getattr(
                    target_surface.surface2,
                    "scaling",
                    (1,),
                )[0]
            ),
        )
        if na_int > 1:
            cart = np.array(selected_site_points, dtype=float)
            selected_site_points = _expand_from_unit(
                cart,
                lattice=target_surface.slab.lattice,
                na=na_int,
                nb=1,
                periodic_axes=(0,),
            )
    else:
        na = int(target_surface.scaling[0])
        nb = int(target_surface.scaling[1])
        if na > 1 or nb > 1:
            cart = np.array(selected_site_points, dtype=float)
            selected_site_points = _expand_from_unit(
                cart,
                lattice=target_surface.slab.lattice,
                na=na,
                nb=nb,
                periodic_axes=(0, 1),
            )

    selected_site_points = _apply_coverage(selected_site_points, coverage)
    if not selected_site_points:
        raise ValueError("no adsorption sites selected for decoration")

    adparticle_structure, species, ads_coords, adparticle_charges = (
        _resolve_adparticle_with_charges(adparticle)
    )
    anchor_indices = _resolve_anchor_indices(
        species,
        ads_coords,
        adparticle_sites,
    )
    anchor_count = len(anchor_indices)

    ads_coords = np.array(ads_coords, dtype=float)
    ads_center = np.mean(ads_coords, axis=0)
    if anchor_count >= 1:
        anchor_center = np.mean(ads_coords[anchor_indices], axis=0)
        anchor_vector = anchor_center - ads_center
        if np.linalg.norm(anchor_vector) <= 1e-12 and anchor_count == 1:
            non_anchor_indices = [
                idx for idx in range(len(ads_coords)) if idx not in anchor_indices
            ]
            if non_anchor_indices:
                non_anchor_center = np.mean(
                    ads_coords[non_anchor_indices],
                    axis=0,
                )
                anchor_vector = anchor_center - non_anchor_center
        if np.linalg.norm(anchor_vector) > 1e-12:
            rotation = _rotation_matrix_from_vectors(
                anchor_vector,
                np.array([0.0, 0.0, -1.0], dtype=float),
            )
            ads_coords = ((ads_coords - ads_center) @ rotation.T) + ads_center
            _vprint("oriented adparticle so selected anchor atoms point towards -z")

    slab_charges = _surface_atom_charges(target_surface)
    slab_cart_coords = np.array(target_surface.slab.cart_coords, dtype=float)

    slab_top = float(np.max(target_surface.slab.cart_coords[:, 2]))
    ads_low = float(np.min(ads_coords[:, 2]))
    z_shift = slab_top + float(c_distance) - ads_low

    ads_center = np.mean(ads_coords, axis=0)
    decorated_count = 0
    if "mask" not in target_surface.slab.site_properties:
        target_surface.slab.add_site_property(
            "mask",
            ["surface"] * len(target_surface.slab),
        )
    for site_point in selected_site_points:
        translation = np.array(
            [
                float(site_point[0]) - float(ads_center[0]),
                float(site_point[1]) - float(ads_center[1]),
                z_shift,
            ],
            dtype=float,
        )
        translated_coords = ads_coords
        if anchor_count >= 2 and selected_site_kind in {"b", "h"}:
            surface_indices = _nearest_surface_atoms_for_site(
                target_surface,
                site_point,
                selected_site_kind,
            )
            translated_coords = _minimize_inplane_electrostatic_rotation(
                coords=translated_coords,
                center=ads_center,
                anchor_indices=anchor_indices,
                adparticle_charges=adparticle_charges,
                slab_coords=slab_cart_coords,
                slab_charges=slab_charges,
                surface_indices=surface_indices,
                translation=translation,
            )
            _vprint(
                "applied in-plane electrostatic rotation using "
                f"{len(surface_indices)} nearby surface atom(s)"
            )

        translated = translated_coords + translation
        for specie, coord in zip(species, translated):
            frac = target_surface.slab.lattice.get_fractional_coords(coord)
            append_properties: dict[str, object] = {
                "mask": "adparticle",
            }
            if "selective_dynamics" in target_surface.slab.site_properties:
                append_properties["selective_dynamics"] = [True, True, True]
            target_surface.slab.append(
                specie,
                frac,
                coords_are_cartesian=False,
                properties=append_properties,
            )
        decorated_count += 1

    _vprint(
        f"placed {decorated_count} adparticle instance(s) at "
        f"{len(selected_site_points)} site(s)"
    )
    target_surface.adparticle = adparticle_structure
    try:
        target_surface.symmetric = bool(target_surface.slab.is_symmetric())
    except Exception:
        pass
    try:
        target_surface.surface_axis_layers = _axis_layers(
            target_surface.slab,
            axis="c",
        )
    except Exception:
        pass
    try:
        thickness, vacuum = _slab_geometry(target_surface.slab)
        target_surface.thickness = thickness
        target_surface.vacuum = vacuum
    except Exception:
        pass
    try:
        axis_vector = np.array(target_surface.slab.lattice.matrix[2], dtype=float)
        target_surface.surface_dipole = _dipole_along_axis(
            target_surface.slab,
            axis_vector,
        )
    except Exception:
        pass
    try:
        target_surface.surface_area = _area_ab(target_surface.slab)
    except Exception:
        pass

    return target_surface, decorated_count


# ── §10 Recollection & filtering ──────────────────────────────────────


def _recollect(
    slab_resolved: Structure,
    miller: tuple,
    *,
    bulk: Structure | None = None,
    stoichiometric: bool | None = None,
    scaling: tuple = (1, 1, 1),
    symmetric: bool | None = None,
    thickness: float | None = None,
    vacuum: float | None = None,
    slab_index: int | None = None,
    slab_termination: str | None = None,
    bulk_energy: float | None = None,
    properties_metadata: dict | None = None,
    adparticle: Any = None,
) -> "Surface":
    """Build a Surface from a resolved structure and metadata.

    Core logic shared by :meth:`Sculptor.recollect` for both the
    standalone Surface path and the per-half Interface path.

    Parameters
    ----------
    slab_resolved : Structure
        Already-resolved slab geometry.
    miller : tuple
        Miller index, e.g. ``(1, 1, 1)``.
    bulk : Structure | None
        Bulk (parent) structure for stoichiometric detection.
    stoichiometric, symmetric : bool | None
        Override flags; auto-detected when possible.
    thickness, vacuum : float | None
        Override geometry; auto-inferred from structure.
    scaling : tuple
        In-plane + c scaling factors.
    slab_index, slab_termination : int | None, str | None
        Cleave-dependent metadata.
    bulk_energy : float | None
        Bulk DFT energy per formula unit.
    properties_metadata : dict | None
        Pre-computed properties dict (e.g. from surf_relax).
    adparticle : Structure | str | None
        Adsorbate structure or POSCAR path.

    Returns
    -------
    Surface
        Fully constructed Surface (without post-init enrichment).
    """
    from slabfy.core import Bulk, Surface

    slab_snapshot = _struct_snapshot(slab_resolved)
    if "mask" not in slab_snapshot.site_properties:
        slab_snapshot.add_site_property(
            "mask",
            ["surface"] * len(slab_snapshot),
        )

    _thick, _vac = _slab_geometry(slab_snapshot)
    _layers = _axis_layers(slab_snapshot, axis="c")
    _area = _area_ab(slab_snapshot)
    _dipole = _dipole_along_axis(
        slab_snapshot,
        np.array(slab_snapshot.lattice.matrix[2], dtype=float),
    )

    _sym = symmetric
    if _sym is None and isinstance(slab_resolved, Slab):
        try:
            _sym = slab_resolved.is_symmetric()
        except Exception:
            pass

    bulk_structure = None
    _stoich = stoichiometric
    if bulk is not None:
        bulk_structure = _resolve_bulk(bulk) if isinstance(bulk, str) else bulk
        if _stoich is None:
            _stoich = _is_stoich(bulk_structure, slab_resolved)

    return Surface(
        slab_snapshot,
        miller=miller,
        bulk=bulk_structure,
        bulk_energy=bulk_energy,
        properties_metadata=properties_metadata,
        thickness=(thickness if thickness is not None else _thick),
        vacuum=(vacuum if vacuum is not None else _vac),
        symmetric=_sym,
        stoichiometric=_stoich,
        slab_termination=slab_termination,
        slab_index=slab_index,
        surface_axis_layers=_layers,
        scaling=scaling,
        surface_dipole=_dipole,
        surface_area=_area,
        adparticle=adparticle,
        surface_sites=None,
        surface_directions=None,
    )


def _parse_filter(
    spec: str,
) -> list[tuple[str, str, str | None]]:
    """Parse a pipe-separated filter/sort specification string.

    Each token has the form ``attribute<``, ``attribute>``, or
    ``attribute=value``.  Returns a list of ``(attribute, operator,
    value)`` tuples where *operator* is one of ``'<'``, ``'>'``, or
    ``'='`` and *value* is the RHS string for ``=`` filters (else
    ``None``).

    Parameters
    ----------
    spec : str
        Pipe-delimited sort/filter descriptor, e.g.
        ``"interface_strain<|interface_dipole<|interface_density>"``.

    Returns
    -------
    list[tuple[str, str, str | None]]
        Parsed tokens.

    Raises
    ------
    ValueError
        If a token cannot be parsed.
    """
    tokens: list[tuple[str, str, str | None]] = []
    for raw_token in spec.split("|"):
        token = raw_token.strip()
        if not token:
            continue
        if "=" in token:
            attr, _, value = token.partition("=")
            tokens.append((attr.strip(), "=", value.strip()))
        elif token.endswith("<"):
            tokens.append((token[:-1].strip(), "<", None))
        elif token.endswith(">"):
            tokens.append((token[:-1].strip(), ">", None))
        else:
            raise ValueError(
                f'invalid filter token "{token}": must end with '
                f'"<", ">", or contain "="'
            )
    return tokens


def _apply_filter(
    items: list["Surface"],
    filter_spec: tuple,
) -> list["Surface"]:
    """Sort, filter, cap and re-enumerate *items* in place.

    Works with both ``Surface`` and ``Interface`` objects.

    Parameters
    ----------
    items : list[Surface]
        Full list of Surface or Interface objects (modified in place).
    filter_spec : tuple
        ``(spec_string, cap_int)`` — see ``Sculptor.join`` /
        ``Sculptor.cleave`` docstrings.

    Returns
    -------
    list[Surface]
        Filtered/sorted list with ``slab_index`` re-enumerated.
    """
    if not items:
        return items

    spec_str, cap = str(filter_spec[0]), int(filter_spec[1])
    tokens = _parse_filter(spec_str)

    # --- exact-match filters (``attribute=value``) ---
    eq_filters = [(attr, val) for attr, op, val in tokens if op == "="]
    if eq_filters:
        filtered: list["Surface"] = []
        for item in items:
            keep = True
            for attr, val in eq_filters:
                item_val = str(getattr(item, attr, "")).strip().upper()
                if item_val != val.strip().upper():
                    keep = False
                    break
            if keep:
                filtered.append(item)
        items = filtered

    # --- sort keys (``attribute<`` or ``attribute>``) ---
    sort_keys = [(attr, op) for attr, op, _ in tokens if op in ("<", ">")]
    if sort_keys:

        def _sort_key(item: "Surface") -> tuple:
            parts: list[float] = []
            for attr, op in sort_keys:
                raw = getattr(item, attr, None)
                try:
                    numeric = float(raw)
                except (TypeError, ValueError):
                    numeric = float("inf")
                parts.append(numeric if op == "<" else -numeric)
            return tuple(parts)

        items = sorted(items, key=_sort_key)

    # --- cap ---
    if cap > 0:
        # Hard cap: keep first *cap* items
        items = items[:cap]
    elif cap < 0:
        # Soft cap: keep first |cap| unique sort-key values;
        # all ties for the last value are included.
        abs_cap = abs(cap)
        if sort_keys:
            seen_values: list[tuple] = []
            cutoff_idx = len(items)
            for idx, item in enumerate(items):
                key_val = _sort_key(item)
                if key_val not in seen_values:
                    seen_values.append(key_val)
                if len(seen_values) > abs_cap:
                    cutoff_idx = idx
                    break
            items = items[:cutoff_idx]
        else:
            items = items[:abs_cap]

    # --- re-enumerate slab_index (UP/DN pairs share the same id) ---
    # Save original indices before overwriting so Surface objects
    # (whose slab_index is read directly) are not corrupted mid-loop.
    _orig_idx = {id(item): int(item.slab_index or 0) for item in items}
    _dn_norm: dict[str, str] = {"DN": "UP"}
    group_idx_map: dict[tuple, int] = {}
    next_group = 1
    for item in items:
        term = str(item.slab_termination or "UP")
        norm_term = _dn_norm.get(term, term)
        # Generic key: for Interface objects miller1/miller2 and
        # surface1/surface2 provide extra discrimination; for plain
        # Surface objects those attrs are absent and fall back to None.
        s1_idx = getattr(getattr(item, "surface1", None), "slab_index", None)
        s2_idx = getattr(getattr(item, "surface2", None), "slab_index", None)
        group_key = (
            _orig_idx[id(item)],
            norm_term,
            int(s1_idx) if s1_idx is not None else None,
            int(s2_idx) if s2_idx is not None else None,
            getattr(item, "miller", None),
            getattr(item, "miller1", None),
            getattr(item, "miller2", None),
        )
        if group_key not in group_idx_map:
            group_idx_map[group_key] = next_group
            next_group += 1
        item.slab_index = group_idx_map[group_key]

    return items


# ── §11 Recursive decorator ───────────────────────────────────────────


def _expand_recursive(
    recursive_map: dict[str, str],
    call_kwargs: dict[str, Any],
) -> list[dict[str, Any]]:
    """Expand file-path arguments via glob; return concrete kwarg dicts.

    Parameters
    ----------
    recursive_map : dict[str, str]
        Mapping from argument name to glob pattern, e.g.
        ``{'bulk': './*.vasp'}``.
    call_kwargs : dict[str, Any]
        The original kwargs passed to the Sculptor method.

    Returns
    -------
    list[dict[str, Any]]
        One kwarg dict per Cartesian combination of resolved files.
        Each dict is a shallow copy of *call_kwargs* with the
        expanded argument values substituted.

    Raises
    ------
    ValueError
        If any glob pattern matches zero files.
    """
    resolved_lists: dict[str, list[str]] = {}
    for arg_name, pattern in recursive_map.items():
        matches = sorted(glob.glob(str(pattern), recursive=True))
        if not matches:
            raise ValueError(
                f"recursive[{arg_name!r}]: glob {pattern!r} matched no files"
            )
        resolved_lists[arg_name] = matches

    arg_names = list(resolved_lists.keys())
    all_combos = list(itertools_product(*(resolved_lists[k] for k in arg_names)))

    result: list[dict[str, Any]] = []
    for combo in all_combos:
        kw = dict(call_kwargs)
        for arg_name, resolved_val in zip(arg_names, combo):
            kw[arg_name] = resolved_val
        result.append(kw)
    return result


def _recursive_run_token(
    resolved_kwargs: dict[str, Any],
    recursive_map: dict[str, str],
) -> str:
    """Build a directory-safe token for a single recursive run.

    Uses the basename (no extension) of each resolved file-path
    argument, joined by ``'_'``.
    """
    parts: list[str] = []
    for arg_name in recursive_map:
        val = resolved_kwargs.get(arg_name, "")
        stem = os.path.splitext(os.path.basename(str(val)))[0]
        parts.append(_to_token(stem))
    return "_".join(p for p in parts if p) or "run"


_RECURSIVE_MAX_WARN = 100


def _recursive_sculptor_method(method):
    """Decorator: glob-based batch recursion for any Sculptor method.

    When the caller passes ``recursive={arg: glob_pattern, ...}``,
    the decorator:

    1. Expands file-path argument globs (Cartesian product).
    2. Sets ``self._run_root`` to a per-run subdirectory token.
    3. Calls the original method for each combination.
    4. Collects and returns all results as a flat list.
    5. Raises ``RuntimeError`` with a summary if any run failed.
    """
    sig = inspect.signature(method)
    param_names = [p for p in sig.parameters if p != "self"]

    @functools.wraps(method)
    def wrapper(self, *args, **kwargs):
        recursive_map = kwargs.pop("recursive", None)
        if not recursive_map or not isinstance(recursive_map, dict):
            return method(self, *args, **kwargs)

        # Merge positional args into kwargs using the
        # pre-captured signature
        bound_kwargs = dict(zip(param_names, args))
        bound_kwargs.update(kwargs)

        verbose = bool(self.settings.get("verbose", 1))

        # Only expand args present in recursive_map AND
        # in the method signature
        active_map = {k: v for k, v in recursive_map.items() if k in param_names}
        if not active_map:
            if verbose:
                print(
                    f"[recursive] warning: no recursive keys "
                    f"match {method.__name__} signature "
                    f"{param_names}; running non-recursively."
                )
            return method(self, **bound_kwargs)

        expanded = _expand_recursive(
            active_map,
            bound_kwargs,
        )

        if len(expanded) > _RECURSIVE_MAX_WARN and verbose:
            print(
                f"[recursive] warning: {len(expanded)} "
                f"combinations — consider narrowing globs"
            )

        if verbose:
            print(
                f"[recursive] {method.__name__}: "
                f"{len(expanded)} run(s) from "
                f"{list(active_map.keys())}"
            )

        all_results: list = []
        failures: list[tuple[str, Exception]] = []

        for i, run_kwargs in enumerate(expanded):
            token = _recursive_run_token(run_kwargs, active_map)
            if verbose:
                print(f"[recursive] run {i + 1}/{len(expanded)}: {token}")
            self._run_root = token
            try:
                result = method(self, **run_kwargs)
            except Exception as exc:
                failures.append((token, exc))
                if verbose:
                    print(f"[recursive] run {i + 1} FAILED: {exc}")
                continue
            finally:
                self._run_root = None

            if isinstance(result, list):
                all_results.extend(result)
            elif result is not None:
                all_results.append(result)

        if failures:
            msg = f"[recursive] {len(failures)}/{len(expanded)} run(s) failed:\n"
            for token, exc in failures:
                msg += f"  {token}: {exc}\n"
            raise RuntimeError(msg)

        return all_results

    return wrapper
