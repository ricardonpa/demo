"""
ASE-specific simulation runners and result containers for slabfy.

This module provides ASE-specific tools for setting up and parsing
atomistic-level simulations. It includes:

- :class:`ASEReport` — dataclass container for parsed ASE results.

- :class:`ASETools` — high-level methods for setting up and reading
  ASE-driven simulations using MLIPs (e.g. MACE, Nequip, ORB etc.).
"""

from dataclasses import dataclass, field
from typing import Any, Union, Literal

from slabfy.core import Surface, Interface


'''
╔╦╗┌─┐┌┬┐┌─┐  ┌─┐┬  ┌─┐┌─┐┌─┐┌─┐┌─┐
 ║║├─┤ │ ├─┤  │  │  ├─┤└─┐└─┐├┤ └─┐
═╩╝┴ ┴ ┴ ┴ ┴  └─┘┴─┘┴ ┴└─┘└─┘└─┘└─┘
'''

@dataclass
class ASEReport:
    """Container for parsed ASE calculation results.

    Mirrors :class:`slabfy.vasp.VaspReport` in spirit but
    stores ASE-native quantities (Atoms trajectories,
    calculator-specific metadata, etc.).

    .. note::
       Stub — fields will be populated as ASE runners are
       implemented.
    """

    directory: str = ""
    energy: float | None = None
    forces: Any = None
    stress: Any = None
    structure: Any = None
    trajectory: list | None = None
    calculator: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


'''
╔╦╗┌─┐┌─┐┬  ┌─┐
 ║ │ ││ ││  └─┐
 ╩ └─┘└─┘┴─┘└─┘
'''


class ASETools:
    """High-level ASE setup and parsing interface.

    .. note::
       Stub — methods will be added as ASE runners are
       implemented.
    """

    def __init__(self) -> None:
        pass

    def _setup_run(
        self,
        slabfy_obj: Union[Surface, Interface, Structure, str],
        dir_path: str | None = None,
        ase_modifiers: Union[str, dict, None] = None,
        sbatch_config: Union[str, dict, None] = None,
        **kwargs,
    ) -> dict[str, Any]:
        """Prepare an ASE calculation for a given structure.

        Parameters
        ----------
        structure : Surface | Interface | str
            Input geometry.
        calculator : str
            Calculator name (``"emt"``, ``"gpaw"``, …).
        **kwargs
            Calculator-specific settings.

        Returns
        -------
        dict[str, Any]
            Setup artefacts (to be defined).
        """
        # TODO: implement ASE calculator setup
        raise NotImplementedError(
            "ASETools.setup_run is not yet implemented"
        )

    def _parse_run(
        self,
        directory: str,
        structure: Union[Surface, Interface, None] = None,
        **kwargs: Any,
    ) -> ASEReport:
        """Parse an ASE calculation directory.

        Parameters
        ----------
        directory : str
            Path to calculation outputs.
        structure : Surface | Interface | None
            If given, attach results back.
        **kwargs
            Extra options.

        Returns
        -------
        ASEReport
            Parsed results container.
        """
        raise NotImplementedError(
            "ASETools.parse_run is not yet implemented"
        )

    def relax(dir,tier,run,run_spec,method):
        """Perform DFT analysis on a surface.
        dir_path: str
        runner: Literal[“vasp”, “ase”]”
        runner_specification: dict
        method: Literal[“write”, “read”]
        """
        pass

    def md(dir,tier,run,run_spec,method):
        """Perform molecular dynamics analysis on a surface.
        dir_path: str
        runner: Literal[“vasp”, “ase”]”
        runner_specification: dict
        method: Literal[“write”, “read”]
        """
        pass
    
    def mc(dir,tier,run,run_spec,method):
        """Perform Monte Carlo analysis on a surface.
        dir_path: str
        runner: Literal[“vasp”, “ase”]”
        runner_specification: dict
        method: Literal[“write”, “read”]
        """
        pass

# TODO: implement ASE standard result parsing
# TODO: implement micro-env helpers into `utils.py`. Make runner work per directory to auto dimension gpu allocation (e.g. multiple simulations per run)
