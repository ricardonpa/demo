"""
Calculator-agnostic analysis routines for slabfy.

This module provides analysis functions that work regardless of
which simulation engine produced the results. It includes:

- :class:`SurfaceProperties` — dataclass container for surface-specific
  properties (e.g. work function, surface energy, etc.).
- :class:`InterfaceProperties` — dataclass container for interface-specific
  properties (e.g. adhesion energy, charge transfer, etc.).

- :class:`AnalysisTree` — cross-system workflows that require
  calculations on multiple different structures or sub-systems.
"""

from __future__ import annotations

import csv
import os
import re
from typing import TYPE_CHECKING, Literal, Union

import numpy as np

from slabfy.internals import _analysis as internals

from slabfy.internals._utils import _read_slabfy_file
from slabfy.internals._core import _normalize_scaling, _output_prefix

from slabfy import utils
from slabfy.utils import PHYS_CONSTANTS

from pymatgen.core.structure import Structure

from slabfy.core import Bulk, Adparticle, Surface, Interface, Sculptor
from slabfy.vasp import VaspTools
from slabfy.ase import AseTools

"""
╔╦╗┌─┐┌┬┐┌─┐  ┌─┐┬  ┌─┐┌─┐┌─┐┌─┐┌─┐
 ║║├─┤ │ ├─┤  │  │  ├─┤└─┐└─┐├┤ └─┐
═╩╝┴ ┴ ┴ ┴ ┴  └─┘┴─┘┴ ┴└─┘└─┘└─┘└─┘
"""


class AnalysisReport:
    """Description of AnalysisReport."""

    pass


"""
╔╦╗┌─┐┌─┐┬  ┌─┐
 ║ │ ││ ││  └─┐
 ╩ └─┘└─┘┴─┘└─┘
"""


class AnalysisTree:
    """Cross-system analysis workflows.

    Unlike :class:`~slabfy.vasp.VaspTools` and :class:`~slabfy.ase.AseTools`,
    whose methods derive properties from a single system state, ``AnalysisTree``
    methods require calculations on *multiple different structures or sub-systems*
    (e.g. before/after adsorption, multiple miller planes, slab-thickness series,
    CNEB images along a path).

    - AnalysisTree methods should read and write to a directory (``dir_path``).
    - `slabfy_objs` are read by default from `.vasp` files in `dir_path`
      (including Sculptor subdirectories), if not provided explicitly.

    """

    @staticmethod
    def convergence(
        dir_path: str,
        method: Literal["write", "read"],
        runner: Literal["vasp", "ase"],
        slabfy_obj: Union[Surface, Interface, str] = None,
        thickness_range: tuple[int, int] = (3, 10),
        **kwargs,
    ):
        """Run or parse a slab thickness convergence study.

        Parameters
        ----------
        dir_path : str
            Base directory for convergence study.
        method : {"write", "read"}
            Write VASP inputs or read results.
        runner : {"vasp", "ase"}
            Calculation runner.
        slabfy_obj : Surface | Interface | str
            Input structure (required for write).
        thickness_range : tuple[int, int]
            Min and max layer counts (default: 3-10).

        Returns
        -------
        list[dict] | None
            Convergence data on read, None on write.
        """
        tag = "[AnalysisTree.convergence]"
        _cfg = kwargs.get("settings", {})
        verbose = bool(_cfg.get("verbose", True)) if isinstance(_cfg, dict) else True

        tree_path = os.path.join(dir_path, "convergence_tree")
        os.makedirs(tree_path, exist_ok=True)

        if method == "write":
            if slabfy_obj is None:
                raise ValueError(f"{tag} slabfy_obj is required for write mode")

            if isinstance(slabfy_obj, str):
                slabfy_obj = _read_slabfy_file(slabfy_obj)

            if not isinstance(slabfy_obj, (Surface, Interface)):
                raise ValueError(f"{tag} slabfy_obj must be Surface or Interface")

            # Apply freeze_coords if needed
            slabfy_obj.slab = utils.freeze_coords(slabfy_obj.slab, coord1=0)

            scale_a, scale_b, scale_c = _normalize_scaling(slabfy_obj.scaling)
            obj_axis_layers = slabfy_obj.surface_axis_layers
            obj_unit_axis_layers = obj_axis_layers[
                0 : int(len(obj_axis_layers) / scale_c)
            ]

            min_c, max_c = (
                int(thickness_range[0] / len(obj_unit_axis_layers)),
                int(thickness_range[1] / len(obj_unit_axis_layers)),
            )

            for c in np.arange(min_c, max_c + 1):
                # Use Sculptor.restack to generate all slabs
                sub_slabfy_obj = Sculptor.restack(
                    slabfy_obj,
                    target_layers=slabfy_obj.surface_axis_layers,
                    stacking_layers=obj_unit_axis_layers * int(c),
                )
                # Pass each sub_slabfy_obj to `VaspTools.relax` + tree_path/{tag}_{_output_prefix(sub_slabfy_obj.slab, sub_slabfy_obj.miller)}_{c}cT
                sub_dir_path = os.path.join(
                    tree_path,
                    f"{tag}_{_output_prefix(sub_slabfy_obj.slab, sub_slabfy_obj.miller)}_{int(c)}cT",
                )
                if runner == "vasp":
                    VaspTools.relax(
                        sub_slabfy_obj,
                        dir_path=sub_dir_path,
                        method="write",
                        auto_freeze=False,
                        **kwargs,
                    )
                elif runner == "ase":
                    AseTools.relax(
                        sub_slabfy_obj,
                        dir_path=sub_dir_path,
                        method="write",
                        auto_freeze=False,
                        **kwargs,
                    )

        elif method == "read":
            # List all subdirectories in tree_path with {tag} prefix
            sub_dir_paths = [
                os.path.join(tree_path, d)
                for d in os.listdir(tree_path)
                if d.startswith(tag)
            ]
            # Read each sub_slabfy_obj using `VaspTools.relax` + dir_path
            convergence_report = []
            for sub_dir_path in sub_dir_paths:
                # Extract c from directory name pattern: {tag}_..._XcT
                match = re.search(r"(\d+)cT$", os.path.basename(sub_dir_path))
                c = int(match.group(1)) if match else None

                if runner == "vasp":
                    sub_slabfy_obj, report = VaspTools.relax(
                        slabfy_obj, dir_path=sub_dir_path, method="read", **kwargs
                    )
                    convergence_report.append(
                        {
                            "dir": sub_dir_path,
                            "thickness": c,
                            "slabfy_obj": sub_slabfy_obj,
                            "report": report,
                        }
                    )
                elif runner == "ase":
                    sub_slabfy_obj, report = AseTools.relax(
                        slabfy_obj, dir_path=sub_dir_path, method="read", **kwargs
                    )
                    convergence_report.append(
                        {
                            "dir": sub_dir_path,
                            "thickness": c,
                            "slabfy_obj": sub_slabfy_obj,
                            "report": report,
                        }
                    )

            # Save convergence report to file as csv
            csv_path = os.path.join(tree_path, f"{tag}_convergence.csv")
            with open(csv_path, "w", newline="") as f:
                if convergence_report:
                    writer = csv.DictWriter(f, fieldnames=["dir", "thickness"])
                    writer.writeheader()
                    for entry in convergence_report:
                        writer.writerow(
                            {"dir": entry["dir"], "thickness": entry["thickness"]}
                        )

            return convergence_report

        else:
            raise ValueError(f"{tag} Method {method} not recognized.")

    @staticmethod
    def wulff(
        dir_path: str,
        method: Literal["write", "read"],
        runner: Literal["vasp", "ase"] = "vasp",
        bulk: Union[Bulk, str] = None,
        miller_order: int = 2,
        **kwargs,
    ):
        """Build a Wulff construction from surface energy data.

        Parameters
        ----------
        dir_path : str
            Base directory for Wulff construction study.
        method : {"write", "read"}
            Write calculation inputs or read results.
        runner : {"vasp", "ase"}
            Calculation runner (default: "vasp").
        bulk : Bulk | str | None
            Bulk structure (required for write mode).
        miller_order : int
            Maximum Miller index order for surface generation (default: 2).

        Returns
        -------
        dict | None
            Surface energies dictionary on read, None on write.
        """
        tag = "[AnalysisTree.wulff]"
        _cfg = kwargs.get("settings", {})
        verbose = bool(_cfg.get("verbose", True)) if isinstance(_cfg, dict) else True

        tree_path = os.path.join(dir_path, "wulff_tree")
        os.makedirs(tree_path, exist_ok=True)

        if method == "write":
            if bulk is None:
                raise ValueError(f"{tag} bulk is required for write mode")

            if isinstance(bulk, str):
                bulk = _read_slabfy_file(bulk)

            # Write bulk calculation if energy not available
            if bulk.energy is None:
                bulk_dir = os.path.join(dir_path, "bulk")
                if runner == "vasp":
                    VaspTools.relax(
                        bulk,
                        dir_path=bulk_dir,
                        method="write",
                        auto_freeze=True,
                        **kwargs,
                    )
                elif runner == "ase":
                    AseTools.relax(
                        bulk,
                        dir_path=bulk_dir,
                        method="write",
                        auto_freeze=True,
                        **kwargs,
                    )

            # Generate surfaces for all Miller indices up to miller_order
            surfaces = Sculptor.cleave(bulk, miller=miller_order)

            for surface in surfaces:
                sub_dir_path = os.path.join(
                    tree_path, f"{tag}_{_output_prefix(surface.slab, surface.miller)}"
                )
                if runner == "vasp":
                    VaspTools.relax(
                        surface,
                        dir_path=sub_dir_path,
                        method="write",
                        auto_freeze=True,
                        **kwargs,
                    )
                elif runner == "ase":
                    AseTools.relax(
                        surface,
                        dir_path=sub_dir_path,
                        method="write",
                        auto_freeze=True,
                        **kwargs,
                    )

        elif method == "read":
            # Read bulk calculation if available
            bulk_dir = os.path.join(dir_path, "bulk")
            if os.path.exists(bulk_dir):
                contcar_path = os.path.join(bulk_dir, "CONTCAR")
                if not os.path.exists(contcar_path):
                    raise FileNotFoundError(
                        f"{tag} CONTCAR file not found in {bulk_dir}"
                    )
                bulk = _read_slabfy_file(contcar_path)

                if runner == "vasp":
                    bulk, bulk_report = VaspTools.relax(
                        bulk,
                        dir_path=bulk_dir,
                        method="read",
                        **kwargs,
                    )
                    # Store final relaxed energy
                    if bulk_report.energy:
                        bulk.energy = bulk_report.energy[-1].get("toten")
                elif runner == "ase":
                    bulk, bulk_report = AseTools.relax(
                        bulk,
                        dir_path=bulk_dir,
                        method="read",
                        **kwargs,
                    )
                    if bulk_report.energy:
                        bulk.energy = bulk_report.energy[-1].get("toten")
            elif bulk is None:
                raise ValueError(
                    f"{tag} bulk is required when no bulk calculation exists"
                )

            # Loop over all subdirectories in tree_path with {tag} prefix
            sub_dir_paths = [
                os.path.join(tree_path, d)
                for d in os.listdir(tree_path)
                if d.startswith(tag)
            ]

            if not sub_dir_paths:
                raise FileNotFoundError(
                    f"{tag} No surface calculations found in {tree_path}"
                )

            surface_energies = {}
            for sub_dir_path in sub_dir_paths:
                contcar_path = os.path.join(sub_dir_path, "CONTCAR")
                if not os.path.exists(contcar_path):
                    raise FileNotFoundError(
                        f"{tag} CONTCAR file not found in {sub_dir_path}"
                    )

                surface = _read_slabfy_file(contcar_path)

                # Read surface calculation and get report
                if runner == "vasp":
                    surface, report = VaspTools.relax(
                        surface, dir_path=sub_dir_path, method="read", **kwargs
                    )
                elif runner == "ase":
                    surface, report = AseTools.relax(
                        surface, dir_path=sub_dir_path, method="read", **kwargs
                    )

                # Set bulk reference if not available
                if surface.bulk is None or surface.bulk.energy is None:
                    surface.bulk = bulk

                # Extract energies from report
                if not report.energy:
                    continue

                e_unrelaxed = report.energy[0].get("toten")
                e_relaxed = report.energy[-1].get("toten")

                if e_unrelaxed is None or e_relaxed is None:
                    continue

                # Compute surface energy using the new function
                se_result = internals._compute_surface_energy(
                    surface=surface,
                    e_unrelaxed=e_unrelaxed,
                    e_relaxed=e_relaxed,
                    bulk_energy=bulk.energy,
                )

                if se_result is None:
                    continue

                surface_energies[sub_dir_path] = {
                    "miller": surface.miller,
                    "surface_energy_J_m2": se_result["surface_energy_J_m2"],
                    "surface_energy_eV_A2": se_result["surface_energy_eV_A2"],
                    "cleavage_energy_eV": se_result["cleavage_energy_eV"],
                    "relaxation_energy_eV": se_result["relaxation_energy_eV"],
                }

            # Get lowest surface energy per Miller index
            lowest_surface_energies = {}
            for se_data in surface_energies.values():
                miller = se_data["miller"]
                se_j_m2 = se_data["surface_energy_J_m2"]
                if miller not in lowest_surface_energies:
                    lowest_surface_energies[miller] = se_j_m2
                else:
                    lowest_surface_energies[miller] = min(
                        lowest_surface_energies[miller], se_j_m2
                    )

            # Generate Wulff construction
            internals._generate_wulff(bulk.structure, lowest_surface_energies)

            return surface_energies

        else:
            raise ValueError(f"{tag} Method {method} not recognized.")

        # TODO: Consider implementing exporting the wulff shape as an slabfy Adparticle object.

    def wulff_mu(dir, run, run_spec, method):
        """Compute surface energy as a function of chemical potential.
        dir_path: str
        runner: Literal[“vasp”, “ase”]”
        runner_specification: dict
        method: Literal[“write”, “read”]
        """
        pass

    def adsorption(dir, run, run_spec, method):
        """Perform adsorption analysis on a surface.
        dir_path: str
        runner: Literal[“vasp”, “ase”]”
        runner_specification: dict
        method: Literal[“write”, “read”]
        """
        pass
        # TODO: Add Eads plot bar chart.

    def cneb(dir, run, run_spec, method):
        """Perform climbing nudged elastic band analysis on an interface.
        dir_path: str
        runner: Literal[“vasp”, “ase”]”
        runner_specification: dict
        method: Literal[“write”, “read”]
        """
        pass
        # TODO: Add volcano plot?

    def cdd(dir, vasp_spec, method, out):
        """Perform charge density difference analysis on an interface.
        dir_path: str
        runner: Literal[“vasp”, “ase”]”
        runner_specification: dict
        method: Literal[“write”, “read”]
        """
        pass
        # TODO: Replace or convert independent cdd scripts to slabfy

    def ablation(dir, set, run, run_spec, method):
        """Perform ablation analysis on a surface.
        dir_path: str
        setting: Literal[“vdw”, “sol”, “dipol”, “all”]
        runner: Literal[“vasp”, “ase”]”
        runner_specification: dict
        method: Literal[“write”, “read”]
        """
        pass

    def hybridization(dir, run, run_spec, method):
        """Perform orbital hybridization analysis on a surface.
        dir_path: str
        runner: Literal[“vasp”, “ase”]”
        runner_specification: dict
        method: Literal[“write”, “read”]
        """
        pass

    def hull(dir, run, run_spec, method):
        """Perform convex hull analysis on a surface.
        dir_path: str
        runner: Literal[“vasp”, “ase”]”
        runner_specification: dict
        method: Literal[“write”, “read”]
        """
        pass

    def pes(dir, run, run_spec, method, out):
        """Perform potential energy surface analysis on a surface.
        dir_path: str
        runner: Literal[“vasp”, “ase”]”
        runner_specification: dict
        method: Literal[“write”, “read”]
        """
        pass
