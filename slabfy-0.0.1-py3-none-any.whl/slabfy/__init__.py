import importlib

__all__ = ["core", "analysis", "vasp", "ase", "utils"]


def __getattr__(name):
	if name in __all__:
		return importlib.import_module(f'.{name}', __name__)
	raise AttributeError(f'module {__name__!r} has no attribute {name!r}')


def main(argv=None):
    """Console entrypoint for the slabfy package.

    Delegates to `slabfy.cli.main` which provides a small CLI around `Sculptor`.
    This function is referenced by `pyproject.toml` as the console script entry.
    """
    from .cli import main as _cli_main

    return _cli_main(argv)